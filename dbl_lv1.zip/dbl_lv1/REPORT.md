# Đinh Bộ Lĩnh Lv1 — báo cáo xuất hình

Bộ hình gốc chibi hoạt hình, nhìn phải; bản trái lật từ ảnh phải. Màu da dùng chung cho mặt và tay: `#F2C98F`, `#D9A066`, `#FBE3B8`. Tóc đen búi đỉnh, vải đỏ buộc búi bay về sau, không băng trán. Áo nâu không tay, cổ chéo và viền kem, đai thắt giữa, quần sẫm và xà cạp nhạt.

## Gói hình

- 33 mảnh nhân vật: đầu 32/33/35, thân 5–12 và 14–21, chân 22–31, lộn toàn thân 1–4; thêm kiếm và cung SVG tự vẽ.
- 70 PNG mảnh nền trong: 35 mảnh/vũ khí × hai cỡ. SVG gốc và mặt nạ da kèm theo.
- 360 PNG khung nền trong: 30 khung × 3 biến thể × 2 hướng × 2 cỡ.
- `0_mau/`: ba mảnh mẫu ở hai cỡ, SVG mẫu, ảnh ghép đứng cao chính xác 256px và 128px.
- `sheet_30_khung.png`: 180 ô, gồm ba biến thể ở hai hướng. GIF chạy gồm 5 khung; GIF nhảy gồm 8 khung.
- Neo tại `parts/parts.json`; dữ liệu ghép và hiệu chỉnh từng khung tại `frames/assembly.json`.

Ảnh mảnh có canvas 256/128px. Khung ghép dùng canvas 640/320px để đủ khoảng trống vũ khí; chiều cao nhân vật đứng là 256/128px. Khi gập hoặc xoay, chiều cao bao hình thay đổi tự nhiên. Đầu khoảng 1,3 lần áo; áo gốc cổ→vạt 82px, giữ cùng tỷ lệ ở mọi tư thế, kể cả lộn. Kiếm khoảng 200px toàn chiều dài (0,78 chiều cao người); cung khoảng 256px.

## Phương pháp và giới hạn

Ba mảnh mẫu được dựng bằng hình học vector gốc. Các mảnh sau dùng lại cùng hàm vẽ, hình áo, mặt, bảng màu, chân và tay; không tạo lại từng nhân vật độc lập. Có một lần tạo ý tưởng bằng mô hình ảnh; prompt nguyên văn nằm trong `prompts/00_concept_image_model.txt`. Các file prompt còn lại ghi đúng brief dựng vector của từng mảnh, không phải các lần gọi mô hình ảnh độc lập. Ảnh ý tưởng không được dùng như ảnh mảnh đầu vào.

Bảng tư thế và độ lệch được chuyển thành dữ liệu số. Công thức tọa độ được áp dụng với Z=4 và hệ số 256/131; sau đó đăng ký lại cổ/cằm và hông để phù hợp tỷ lệ thiết kế mới. Vị trí thô, độ dịch sửa và nắm tay thực tế đều được ghi lại. Đây là chuyển động thích nghi cho thiết kế mới, không phải cam kết trùng từng pixel của hình tham khảo. Khi ô vũ khí trong bảng trống, vẫn xuất biến thể có vũ khí và gắn vào nắm tay đã vẽ.

Màu nội thất da trong mặt nạ ngữ nghĩa được kiểm tra đúng ba mã ở cả hai cỡ mảnh. Viền khử răng cưa và ảnh ghép thu nhỏ có màu trung gian do pha nét; không dùng một bộ màu da khác. GIF có nền kem; PNG có nền trong.

Không có ảnh, mã nguồn hay tên game tham khảo trong gói. Chỉ có các số đo khung/độ lệch cần để tái tạo chuyển động. Hai thư mục nguồn không bị sửa.

## Tự soát từng khung

Đã xem ba bảng đủ 30 khung hướng phải, và xem riêng 12 ô lộn có/không vũ khí sau sửa cuối. Hướng trái được kiểm tra bằng so sánh toàn bộ pixel với ảnh phải lật ngang. Kiểm tra tự động kết hợp neo hình học, pixel alpha ở cổ và nắm tay, hai điểm chân và pixel giày, kích thước áo, màu da, cắt biên và tính đối xứng. Khung lộn dùng hai chân của hình vector toàn thân; kiểm tra mắt xác nhận hai giày. Các phép kiểm tra hình học không tự chứng minh toàn bộ chất lượng mỹ thuật.

Bảng dưới tổng hợp cả ba biến thể. Cột vũ khí áp dụng cho kiếm/cung; cột tay yêu cầu có các dáng vung khác nhau trong chuỗi, không yêu cầu hai khung nghỉ 00/01 khác tư thế tay. Một số khung đánh trên không dùng lại đúng mảnh đánh tương ứng.

| Khung | Cổ kín | Áo cùng cỡ | Da cùng màu | Đủ 2 chân | Tay vung theo dáng | Vũ khí trong tay | Không cắt biên | Lật trái đúng |
|---|---|---|---|---|---|---|---|---|
| 00 | Có | Có | Có | Có | Có | Có | Có | Có |
| 01 | Có | Có | Có | Có | Có | Có | Có | Có |
| 02 | Có | Có | Có | Có | Có | Có | Có | Có |
| 03 | Có | Có | Có | Có | Có | Có | Có | Có |
| 04 | Có | Có | Có | Có | Có | Có | Có | Có |
| 05 | Có | Có | Có | Có | Có | Có | Có | Có |
| 06 | Có | Có | Có | Có | Có | Có | Có | Có |
| 07 | Có | Có | Có | Có | Có | Có | Có | Có |
| 08 | Có | Có | Có | Có | Có | Có | Có | Có |
| 09 | Có | Có | Có | Có | Có | Có | Có | Có |
| 10 | Có | Có | Có | Có | Có | Có | Có | Có |
| 11 | Có | Có | Có | Có | Có | Có | Có | Có |
| 12 | Có | Có | Có | Có | Có | Có | Có | Có |
| 13 | Có | Có | Có | Có | Có | Có | Có | Có |
| 14 | Có | Có | Có | Có | Có | Có | Có | Có |
| 15 | Có | Có | Có | Có | Có | Có | Có | Có |
| 16 | Có | Có | Có | Có | Có | Có | Có | Có |
| 17 | Có | Có | Có | Có | Có | Có | Có | Có |
| 18 | Có | Có | Có | Có | Có | Có | Có | Có |
| 19 | Có | Có | Có | Có | Có | Có | Có | Có |
| 20 | Có | Có | Có | Có | Có | Có | Có | Có |
| 21 | Có | Có | Có | Có | Có | Có | Có | Có |
| 22 | Có | Có | Có | Có | Có | Có | Có | Có |
| 23 | Có | Có | Có | Có | Có | Có | Có | Có |
| 24 | Có | Có | Có | Có | Có | Có | Có | Có |
| 25 | Có | Có | Có | Có | Có | Có | Có | Có |
| 26 | Có | Có | Có | Có | Có | Có | Có | Có |
| 27 | Có | Có | Có | Có | Có | Có | Có | Có |
| 28 | Có | Có | Có | Có | Có | Có | Có | Có |
| 29 | Có | Có | Có | Có | Có | Có | Có | Có |

## Nhật ký sửa

| Lượt | Mảnh / khung | Kết quả trước | Sửa | Kết quả cuối |
|---|---|---|---|---|
| 1 | 1, 2, 3, 4; khung [8, 9, 10, 11] | Không: tư thế lộn còn duỗi | Co chân về phía thân; nghiêng đầu/thân; xoay bốn góc từ cùng bộ mẫu. | Có |
| 1 | kiem; khung Các khung có vũ khí; 5 khung ban đầu bị cắt biên | Không: khoảng trống canvas thiếu; kiếm dài hơn tỷ lệ yêu cầu | Vẽ lại tỷ lệ kiếm khoảng 200px; tăng canvas khung lên 640px. | Có; 0 khung cắt biên |
| 2 | 23; khung [0, 1] | Không: ảnh đứng cao 258px thay vì 256px | Dời hai bàn chân lên 2px, giữ nguyên áo và neo hông. | Có; chiều cao bao hình đứng 256px |
| 2 | 1, 2, 3, 4; khung [8, 9, 10, 11] | Không: bản thu tư thế trước có thu nhỏ toàn thân 0.92 | Bỏ thu nhỏ; đưa tâm vào giữa canvas để áo giữ nguyên tỷ lệ 1:1. | Có; áo gốc vẫn 82px |
| technical | Script kiểm tra; khung [] | Lỗi ghi JSON của script kiểm tra do bool NumPy | Chuyển kết quả kiểm tra thành bool Python; chạy lại tất cả kiểm tra. | PASS; không đổi hình vì lỗi này |

Mảnh lộn được vẽ sửa hai lần; chân đứng và kiếm một lần. Không mảnh nào vượt ba lần sửa. Nhật ký có cấu trúc: `tools/rework_log.json`.

## Output nguyên văn các script — lần chạy cuối

### `draw.py`

```text
DRAW: 33 original character parts + 2 original weapon SVGs; RGBA render 1024px.
MASTERS: head 32, torso 5, legs 23. Remaining parts reuse the same vector functions.
No external artwork is loaded by this drawing script.
```

### `normalize.py`

```text
NORMALIZE: 35 parts, transparent RGBA, each 256×256 and 128×128.
Skin semantic pixels at 256px: 28218; palette: #F2C98F, #D9A066, #FBE3B8
Fixed anchors: head chin=(128,112); torso neck=(128,64), hip=(128,131); legs hip=(128,80).
Tunic neck-to-hem: 82 source pixels; head crown-to-chin: 106 pixels; ratio=1.29268.
Skin interiors quantized after each resize; antialiased outlines remain smooth.
Master exports saved in 0_mau; anchors and per-part metadata saved in parts/parts.json.
```

### `assemble.py`

```text
ASSEMBLE: 30 poses × 3 variants × 2 directions × 2 scales = 360 frame PNGs.
Placement formula applied with Z=4, S=256/131; neck/hip constraint corrections are recorded per frame.
Source weapon offsets recorded; final weapon grips follow actual authored fists in all 30 poses.
Frame canvas: 640×640 at character scale 256; 320×320 at character scale 128.
Standing unarmed frame alpha height before display crop: 256px; 0_mau standing exports: exactly 256px / 128px tall.
Saved sheet_30_khung.png (180 cells, both directions), anim_chay.gif (5 frames), anim_nhay.gif (8 frames).
Clipped frames: 0
```

### `validate.py`

```text
VALIDATE: 35 part records, 70 transparent part PNGs, 360 frame PNGs.
Skin palette: 32893 semantic pixels checked at both scales; exact 3-color membership required.
Per-frame checks: neck anchor + opaque neck pixels, fixed tunic height, 2 declared foot anchors + rendered pixels, distinct hand positions, actual grip alpha, clipping, exact mirrored pixels.
Roll cells: curled original full-body vector at 4 rotations, inherited 2-foot geometry; joints are built into the artwork.
Connected-component observations (unarmed, components >20 pixels): []
Frame checklist:
frame neck size skin feet arms grip bounds mirror
00 YES YES YES YES YES YES YES YES
01 YES YES YES YES YES YES YES YES
02 YES YES YES YES YES YES YES YES
03 YES YES YES YES YES YES YES YES
04 YES YES YES YES YES YES YES YES
05 YES YES YES YES YES YES YES YES
06 YES YES YES YES YES YES YES YES
07 YES YES YES YES YES YES YES YES
08 YES YES YES YES YES YES YES YES
09 YES YES YES YES YES YES YES YES
10 YES YES YES YES YES YES YES YES
11 YES YES YES YES YES YES YES YES
12 YES YES YES YES YES YES YES YES
13 YES YES YES YES YES YES YES YES
14 YES YES YES YES YES YES YES YES
15 YES YES YES YES YES YES YES YES
16 YES YES YES YES YES YES YES YES
17 YES YES YES YES YES YES YES YES
18 YES YES YES YES YES YES YES YES
19 YES YES YES YES YES YES YES YES
20 YES YES YES YES YES YES YES YES
21 YES YES YES YES YES YES YES YES
22 YES YES YES YES YES YES YES YES
23 YES YES YES YES YES YES YES YES
24 YES YES YES YES YES YES YES YES
25 YES YES YES YES YES YES YES YES
26 YES YES YES YES YES YES YES YES
27 YES YES YES YES YES YES YES YES
28 YES YES YES YES YES YES YES YES
29 YES YES YES YES YES YES YES YES
FAILURES: 0
```

## Output chẩn đoán các lượt trước — nguyên văn

### `assemble_round1`

```text
ASSEMBLE: 30 poses × 3 variants × 2 directions × 2 scales = 360 frame PNGs.
Placement formula applied with Z=4, S=256/131; neck/hip constraint corrections are recorded per frame.
Source weapon offsets recorded; final weapon grips follow actual authored fists in all 30 poses.
Frame canvas: 512×512 at character scale 256; 256×256 at character scale 128.
Standing unarmed frame alpha height before display crop: 258px; 0_mau standing exports: exactly 256px / 128px tall.
Saved sheet_30_khung.png (180 cells, both directions), anim_chay.gif (5 frames), anim_nhay.gif (8 frames).
Clipped frames: 5
```

### `assemble_round2`

```text
ASSEMBLE: 30 poses × 3 variants × 2 directions × 2 scales = 360 frame PNGs.
Placement formula applied with Z=4, S=256/131; neck/hip constraint corrections are recorded per frame.
Source weapon offsets recorded; final weapon grips follow actual authored fists in all 30 poses.
Frame canvas: 640×640 at character scale 256; 320×320 at character scale 128.
Standing unarmed frame alpha height before display crop: 258px; 0_mau standing exports: exactly 256px / 128px tall.
Saved sheet_30_khung.png (180 cells, both directions), anim_chay.gif (5 frames), anim_nhay.gif (8 frames).
Clipped frames: 0
```

### `validate_round2_internal`

```text
Traceback (most recent call last):
  File "/workspace/dbl_lv1/tools/validate.py", line 85, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/workspace/dbl_lv1/tools/validate.py", line 72, in main
    (ROOT/'tools/validation.json').write_text(json.dumps(result,indent=2))
                                              ^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/__init__.py", line 238, in dumps
    **kw).encode(obj)
          ^^^^^^^^^^^
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/encoder.py", line 202, in encode
    chunks = list(chunks)
             ^^^^^^^^^^^^
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/encoder.py", line 432, in _iterencode
    yield from _iterencode_dict(o, _current_indent_level)
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/encoder.py", line 406, in _iterencode_dict
    yield from chunks
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/encoder.py", line 326, in _iterencode_list
    yield from chunks
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/encoder.py", line 406, in _iterencode_dict
    yield from chunks
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/encoder.py", line 439, in _iterencode
    o = _default(o)
        ^^^^^^^^^^^
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/json/encoder.py", line 180, in default
    raise TypeError(f'Object of type {o.__class__.__name__} '
TypeError: Object of type bool is not JSON serializable
```

## Tái tạo

Xem `tools/README.md`. Chạy lần lượt `draw_parts.py`, `normalize.py`, `assemble.py`, `validate.py`. Python/Pillow/NumPy và Inkscape CLI là đủ; không cần hai thư mục nguồn hay kết nối mạng. Render trung gian `parts/raw/` được tạo lại bởi script vẽ và không đưa vào ZIP. Các kết quả chuẩn hóa, vector, mặt nạ, công cụ và log đều có trong ZIP.

## Output nguyên văn đóng gói

```text
PACKAGE: 571 files; 360 frame PNGs; ZIP CRC PASS; required paths PASS.
```
