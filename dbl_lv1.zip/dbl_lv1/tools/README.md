# Xử lý raster và kiểm tra bộ hình

Nhân vật gồm raster tạo bằng công cụ ảnh. Chỉ hai vũ khí dùng SVG. Mốc bảo toàn là commit `1def335`: sáu thân được phép sửa là 5, 14, 15, 17, 18, 19; mọi đầu, chân, lộn và các thân khác giữ nguyên file PNG. Lớp tay cầm riêng cho biến thể vũ khí được thêm theo lựa chọn của người dùng; tay không dùng mảnh gốc tương ứng.

Yêu cầu: Python 3, Pillow, NumPy, Inkscape CLI để render hai vũ khí.

```sh
python tools/normalize.py --parts 5 14 15 17 18 19
python tools/make_weapons.py
python tools/normalize_grips.py
python tools/assemble.py
python tools/verify_preservation.py
python tools/weapon_audit.py
python tools/validate.py
python tools/package.py
```

`normalize.py` có khóa chọn mảnh để không ghi lại các ảnh được bảo vệ. Nền xanh được key ra alpha; neo cổ/hông và chiều dài áo 82px giữ cố định. Cuối bước chuẩn hóa có đo bắp tay và diện tích mặt nạ da. Theo trả lời của người dùng, ngưỡng ±12% áp cho độ dày trung bình hai bắp tay đo được; diện tích da chỉ báo cáo riêng theo dáng. Số đo từng bên và tọa độ vai–khuỷu đều lưu trong `arm_metrics.json`. Thân 16 có giữa bắp tay trái bị cẳng tay/quấn cổ tay che; kết quả này là N/A, không phải một phép đo đạt.

`make_weapons.py` vẽ trực tiếp kiếm chĩa xuống-trái và cung chéo lên-phải, rồi đưa khung bao về kích thước đã quy đổi. Vũ khí không được xoay lúc ghép. `assemble.py` đặt trực tiếp ô thứ tư của bảng tư thế cộng độ lệch mảnh với Z=4, tỷ lệ 256/131; vẽ vũ khí trên thân, rồi lớp ngón tay trên chuôi. Vũ khí chỉ hiện ở 00–07, 12, 21.

`normalize_grips.py` xử lý các raster lớp tay đã được tạo bằng công cụ ảnh. Các dấu đỏ/tím và chuôi xanh là mốc đăng ký tạm, được loại khỏi PNG xuất. Công cụ đăng ký bằng cổ–vạt, căn vùng tay cầm bằng biến đổi raster trơn không gập ảnh, và lấy pixel ngón tay đã vẽ để ghép lên chuôi. Không tạo hình người bằng SVG hay hình khối. Vùng áo gốc được giữ ở giữa; phần cánh tay được thay riêng trên biến thể có vũ khí, không sửa file mảnh gốc. Frame 01 dùng lại lớp tay của 00 vì tư thế tương đối giống nhau.

`weapon_audit.py` đo góc từ pixel lưỡi kim loại còn nhìn thấy sau lớp ngón tay và trục hai đầu cung. Vị trí được đối chiếu độc lập với bảng số; pixel vũ khí đục trong ảnh ghép được so khớp với đúng asset tại vị trí đó. Có đủ 80 bản ghi: 10 khung × 2 vũ khí × 2 hướng × 2 cỡ.

`verify_preservation.py` so hash các PNG được bảo vệ với baseline. Các bảng so sánh có ảnh hướng dẫn chỉ được xuất trong thư mục tạm bên ngoài gói; chúng không nằm trong ZIP. Không cần nguồn hướng dẫn để chạy lại pipeline từ các raster đầu vào đã lưu.

`parts/256` và `parts/128` là hai mức tỷ lệ nhân vật. Mảnh nhân vật có canvas 256/128px; vũ khí có canvas riêng để chứa cung cao khoảng 258px. Khung ghép dùng canvas 640/320px. Ảnh đứng cắt sát ở `0_mau/` cao 256/128px.
