# Xử lý và kiểm tra bộ hình

Bản này tiếp tục từ `760fdd9`. Giữ nguyên toàn bộ 33 mảnh nhân vật, ảnh gốc, mặt nạ, khung tay không và khung lộn. Chỉ hai vũ khí là SVG. Lớp tay cầm tái sử dụng raster đã tạo bằng công cụ ảnh; không có lần tạo nhân vật mới trong bản này.

Cần Python 3, Pillow, NumPy, SciPy và Inkscape CLI. Chạy trong thư mục bộ hình:

```sh
python tools/make_weapons.py
python tools/normalize_grips.py
python tools/assemble.py
python tools/revision_previews.py
python tools/verify_preservation.py
python tools/weapon_audit.py
python tools/validate.py
python tools/package.py
```

Không chạy lại chuẩn hóa mảnh nhân vật trong lần sửa này. `preservation_baseline_revision3.json` bảo vệ 284 PNG bằng SHA256, gồm toàn bộ mảnh và các khung cần giữ nguyên. Số đo tay đã có được giữ trong `arm_metrics.json`; giữa bắp tay thân 16 bị che nên ghi N/A. Diện tích da là số liệu riêng theo dáng.

Kiếm được nén riêng theo trục lưỡi quanh chuôi, giữ chiều rộng vuông góc với lưỡi. Tổng chiều dài đo bằng phép chiếu toàn bộ pixel alpha >127 lên trục lưỡi, gồm đốc kiếm; mục tiêu 200px/256px. Cung có hai cánh bằng nhau, grip tại giữa chiều dài cung, dây 3.2px. Không xoay vũ khí lúc ghép.

Vị trí dùng bảng số và độ lệch mảnh với hệ số `4*256/131`. Ngoại lệ được yêu cầu: kiếm 12/21 được đưa tới điểm ngực `[151,133]` trong hệ tọa độ thân; REPORT ghi rõ độ dịch so với bảng số. Lớp tay cầm dùng lại nguồn raster `kiem_02` cho hai khung này, giữ tay còn lại từ thân gốc.

Tách lớp tay theo alpha/màu và thành phần da liên thông; giữ nguyên RGB của ảnh tạo, chuẩn hóa da về bộ ba màu đã duyệt. Lớp ngón tay chỉ chứa nắm tay cùng nét viền ảnh gốc, không lấy vòng tròn chứa cả cổ áo. Vùng cổ áo được phục hồi từ mảnh gốc thay vì ghép các mẩu tròn nhỏ. Không vẽ lại hình người bằng mã.

Thứ tự: chân/thân, vũ khí trên thân, ngón tay trên chuôi. Với cung, đầu gốc nằm trên cung để bảo vệ mặt. Khung 08–11 giữ nguyên bốn ảnh lộn riêng. Vũ khí chỉ xuất hiện 00–07,12,21.

`weapon_audit.py` đo góc/bao từ asset raster đầy đủ trước che khuất; kiểm tra riêng pixel vũ khí còn nhìn thấy và pixel đầu trong ảnh ghép. Sai lệch tay–chuôi tính cả làm tròn độc lập hai lớp. Có đủ 80 bản ghi cho 10 khung × 2 vũ khí × 2 hướng × 2 cỡ.

Hai tờ kiểm chỉ có ảnh tự thiết kế: `preview/tay_dong_bo.png` đủ 16 thân tại cùng tỷ lệ; `preview/vu_khi_zoom.png` có 00,03,07,12,21 × kiếm/cung phóng đúng 2×. Mọi ảnh tham khảo bên ngoài đều không thuộc gói.
