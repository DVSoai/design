# Công cụ xử lý raster

Mọi mảnh đầu, thân, chân và lộn là đầu ra của công cụ tạo ảnh, đã lưu trong `parts/raw/`. Ba mẫu được người dùng duyệt nằm trong `0_mau/`. Không có công cụ vẽ lại nhân vật bằng vector hoặc hình khối trong gói.

Yêu cầu: Python 3, Pillow, NumPy; Inkscape CLI chỉ để render hai vũ khí SVG.

Từ thư mục gói, chạy:

```sh
python tools/normalize.py
python tools/make_weapons.py
python tools/assemble.py
python tools/validate.py
python tools/package.py
```

Các script tìm thư mục gốc theo vị trí file, không phụ thuộc thư mục làm việc. Không cần mạng hoặc dữ liệu ảnh tham khảo để xử lý lại các raster đã có.

`normalize.py` chỉ tách phần alpha nền còn sót, cắt vùng ảnh, đổi kích thước đồng đều, lượng tử hóa vùng da và dịch ảnh đến neo. Cổ, cằm, hông và bàn chân được ghi trong `parts/parts.json`. Vị trí nắm tay được tìm trên cụm pixel da có sẵn gần chú thích; không vẽ thêm tay. Mặt nạ màu có lọc nhẹ để tránh nhiễu một pixel. Nét và hình dáng nhân vật đến từ ảnh đầu vào.

`make_weapons.py` là nơi duy nhất tạo SVG: kiếm và cung. `assemble.py` dùng bảng 30 tư thế dạng số, sau đó đăng ký cổ và hông cho thiết kế đã duyệt; vị trí thô và hiệu chỉnh được lưu ở `frames/assembly.json`. Nhân vật được dịch và lật ngang, không xoay bằng mã. Chỉ ảnh vũ khí được xoay khi đặt vào nắm tay. Bốn ảnh lộn được tạo riêng bằng công cụ ảnh.

Vũ khí chỉ có ở 00–07, 12 và 21. Ở 20 khung còn lại, hai biến thể vũ khí giống hệt ảnh tay không theo yêu cầu.

`parts/256` và `parts/128` dùng canvas vuông 256/128px. Khung ghép dùng canvas 640/320px để chứa vũ khí và các tư thế; nhân vật đứng ở mức nguồn cao 256px. Ảnh đứng cắt sát trong `0_mau/` cao chính xác 256/128px.

`tools/image_calls.json` ghi số lần tạo của từng mảnh. Ba mẫu gốc cùng xuất hiện trong một lần tạo atlas trước đó và được duyệt lại; các mảnh biến thể có nhật ký gọi riêng trong `tools/logs/`. Tất cả lần tạo mới đều kèm ba mẫu và ảnh tư thế cùng số. Prompt nguyên văn cho mỗi lần gọi nằm trong `prompts/`; các file 05/23/32 là bản sao nguyên văn của prompt gọi atlas chung, không phải ba lần gọi mới.

Mỗi mảnh nhân vật phải có ít nhất một lần gọi công cụ ảnh. Kiếm và cung là ngoại lệ SVG được cho phép. Không đóng gói ảnh hướng dẫn tư thế bên ngoài.
