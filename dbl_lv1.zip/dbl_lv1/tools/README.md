# Bộ hình Đinh Bộ Lĩnh — thay ảnh trên cấu trúc khung gốc

32 mảnh có hình nhân vật đều được vẽ mới bằng công cụ tạo ảnh: 3 đầu, 16 thân, 9 chân và 4 ảnh lộn. Ô 22 là canvas trong suốt 4×4, không có hình nhân vật để vẽ. Hai vũ khí được tự vẽ SVG.

`parts/native/` giữ nguyên kích thước canvas và khung bao từng mảnh theo bảng hình ban đầu. Các tên ảnh số, gồm 262/283, dùng được để thay ảnh trên cấu trúc khung có sẵn. `parts/256` và `parts/128` dùng chung hệ số 256/131 và 128/131; không ép mọi áo có cùng chiều cao. Đầu–thân–chân khung đứng có bao 83×76, 82×43, 58×31; toàn người 87×131 px, chồng cổ/hông 8/11 px.

Tọa độ ghép dùng trực tiếp bảng số và độ lệch mảnh, không sửa neo, không thêm tay cầm, không dịch vũ khí ở 12/21. Vũ khí ở trước thân theo ảnh ghép được người dùng cung cấp; khi cắt qua đầu, giữ pixel đầu từ ảnh tay không để tránh che mặt. Không khẳng định chuôi trùng nắm tay hay ghi khoảng cách giả bằng 0.

Cần Python 3, Pillow, NumPy, SciPy và Inkscape CLI.

```sh
python tools/make_weapons.py
python tools/finalize_manifest.py
python tools/normalize.py
python tools/assemble.py
python tools/previews.py
python tools/proportion_audit.py
python tools/weapon_audit.py
python tools/validate.py
python tools/write_report.py
python tools/package.py
```

`normalize.py` chỉ tách alpha, loại rìa nền, đưa raster đã tạo vào đúng khung bao số và chuẩn hóa màu da. Không dựng nhân vật bằng hình khối/vector. Các prompt từng lần thử có trong `prompts/`; log gọi công cụ và hash ảnh gốc có trong `tools/logs/` và `tools/image_calls.json`.

`proportion_audit.py` kiểm tra độc lập khung bao của cả 30 tư thế tại cỡ native. `validate.py` kiểm tra nguồn tạo ảnh, kích cỡ, màu da, 360 ảnh khung, quy tắc hiện vũ khí, ảnh lật và ảnh lộn độc lập. Kiểm tra khung bao không đồng nghĩa với trùng đường viền từng pixel; dáng tay/chân và khớp được soát bằng ảnh ghép. Chưa chạy thử trong client thực tế.

Các tờ có ảnh tham khảo nằm ở thư mục tạm ngoài gói. Preview trong gói chỉ có hình Đinh Bộ Lĩnh và số đo.
