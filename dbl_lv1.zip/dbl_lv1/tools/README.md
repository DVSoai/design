# Tái tạo bộ hình

Yêu cầu: Python 3, Pillow, NumPy, Inkscape CLI. Không cần mạng, API hay dữ liệu ngoài gói.

Chạy từ bất kỳ thư mục nào:

```sh
python tools/draw_parts.py
python tools/normalize.py
python tools/assemble.py
python tools/validate.py
```

Nếu đang ở ngoài thư mục gói, thay `tools/` bằng đường dẫn đầy đủ. Các script tự tìm thư mục gốc theo vị trí file.

`draw_parts.py` vẽ vector gốc, dựng biến thể từ cùng hàm hình học và xuất render ×4 để khử răng cưa. `normalize.py` bỏ nền nối với góc nếu có, đăng ký neo, tạo hai cỡ và lượng tử hóa vùng da theo mặt nạ ngữ nghĩa. Đầu neo tại cằm; thân tại cổ và hông; chân tại hông. Mỗi mảnh có SVG chỉnh sửa được.

`assemble.py` dùng bảng 30 tư thế và độ lệch dạng số. Nó áp dụng công thức vị trí rồi hiệu chỉnh điểm tiếp xúc để phù hợp tỷ lệ thiết kế mới. Toàn bộ vị trí thô và dịch chuyển được ghi trong `frames/assembly.json`. Không tuyên bố trùng từng pixel với nhân vật khác. Khung lộn dùng hình toàn thân co chân, xoay từng 90°. Các ô vũ khí trống trong bảng tư thế vẫn được bổ sung vũ khí theo nắm tay đã vẽ.

Thư mục `parts/256` là canvas 256×256; `parts/128` là canvas 128×128. Trong `frames/256`, canvas rộng 640×640 để chứa vũ khí; `frames/128` rộng 320×320. Hai số 256/128 ở đây chỉ tỷ lệ nhân vật, không chỉ kích thước canvas của khung. Ảnh đứng cắt sát trong `0_mau` cao chính xác 256/128 px. Hoạt động nhảy, gập người và xoay làm chiều cao bao hình thay đổi theo tư thế.

`prompts/00_concept_image_model.txt` là prompt nguyên văn của lần tạo ý tưởng bằng mô hình ảnh. Prompt từng mảnh là brief nguyên văn của bước dựng vector theo tham số; không phải 33 lần gọi mô hình ảnh độc lập. Ý tưởng không được dùng làm ảnh mảnh đầu vào. Không có ảnh tham khảo trong gói.

Da trong các mặt nạ ngữ nghĩa được ép về đúng ba mã màu; viền khử răng cưa chứa màu trung gian khi trộn với nét. Ở mức 128, vùng nội thất da vẫn được lượng tử hóa lại. Phép thu nhỏ ảnh ghép phục vụ hiển thị có khử răng cưa.

Sheet có sáu phần theo thứ tự: tay không/phải, tay không/trái, kiếm/phải, kiếm/trái, cung/phải, cung/trái. Mỗi phần ba hàng, mười cột, thứ tự 00–29. GIF dùng nền kem để hiển thị mượt; PNG mảnh và khung có nền trong.
