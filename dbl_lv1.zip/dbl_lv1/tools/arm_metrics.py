#!/usr/bin/env python3
"""Repeatable measurements on the saved skin masks, with explicit landmarks."""
from pathlib import Path
import json,math
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
LANDMARKS={
5:[[[107,113],[94,148]],[[154,120],[168,150]]],
6:[[[109,113],[86,134]],[[150,117],[161,144]]],
7:[[[109,112],[77,132]],[[149,125],[164,145]]],
8:[[[104,114],[71,132]],[[149,126],[158,149]]],
9:[[[110,114],[80,135]],[[151,125],[159,149]]],
10:[[[103,113],[80,132]],[[154,124],[168,151]]],
11:[[[108,115],[78,137]],[[149,121],[163,132]]],
12:[[[108,120],[91,107]],[[152,126],[170,122]]],
14:[[[111,115],[94,137]],[[151,122],[160,145]]],
15:[[[106,113],[96,143]],[[147,119],[162,153]]],
16:[[[110,115],[84,113]],[[151,125],[160,151]]],
17:[[[111,115],[96,141]],[[150,122],[166,140]]],
18:[[[109,113],[80,137]],[[151,123],[172,114]]],
19:[[[113,113],[81,100]],[[150,125],[174,124]]],
20:[[[103,115],[80,136]],[[148,119],[171,92]]],
21:[[[103,117],[82,142]],[[151,117],[170,121]]],
}

def width(mask,a,b):
    a=np.array(a,float);b=np.array(b,float);v=b-a;v=np.array([-v[1],v[0]])/np.linalg.norm(v);values=[]
    for f in [.45,.50,.55]:
        p=a+(b-a)*f;ts=np.arange(-35,35.01,.25);xy=np.rint(p[None,:]+ts[:,None]*v).astype(int);ok=(xy[:,0]>=0)&(xy[:,0]<256)&(xy[:,1]>=0)&(xy[:,1]<256);hits=np.zeros(len(ts),bool);hits[ok]=mask[xy[ok,1],xy[ok,0]]
        indices=np.where(hits & (np.abs(ts)<5))[0]
        if not len(indices):continue
        mid=int(indices[np.argmin(abs(ts[indices]))]);lo=mid;hi=mid
        while lo>0 and hits[lo-1]:lo-=1
        while hi+1<len(hits) and hits[hi+1]:hi+=1
        values.append((hi-lo+1)*.25)
    return float(np.mean(values)) if values else None

def measure():
    rows=[]
    for i,points in LANDMARKS.items():
        m=np.array(Image.open(ROOT/f'parts/masks/{i:02}.png').convert('L'))>127
        widths=[width(m,*p) for p in points];valid=[w for w in widths if w is not None];mean=float(np.mean(valid)) if valid else None
        occluded=i==16
        rows.append({'part':i,'upper_arm_widths_px':widths,'mean_upper_arm_px':None if occluded else mean,'projected_visible_width_mean':mean,'midpoint_occluded':occluded,'measurement_note':'The left upper-arm midpoint is covered by the crossed forearm/wrist wrap; visible skin-strip width is not anatomical biceps diameter.' if occluded else 'Three midpoint cross-sections per arm, averaged.','skin_area_px2':int(m.sum()),'landmarks':points})
    ref=next(r for r in rows if r['part']==8)
    for r in rows:
        r['width_delta_percent']=None if r['mean_upper_arm_px'] is None else (r['mean_upper_arm_px']/ref['mean_upper_arm_px']-1)*100
        r['skin_area_delta_percent']=(r['skin_area_px2']/ref['skin_area_px2']-1)*100
        r['within_12_percent']=None if r['midpoint_occluded'] else r['width_delta_percent'] is not None and abs(r['width_delta_percent'])<=12
    return {'reference':8,'width_method':'Mean of orthogonal contiguous skin-mask sections at 45%, 50%, 55% of each annotated shoulder-to-elbow segment; average visible arms.','area_method':'All white pixels of the saved canonical skin mask at 256 scale; includes neck and hands; identical rule for every torso.','rows':rows}

def main():
    result=measure();(ROOT/'tools/arm_metrics.json').write_text(json.dumps(result,indent=2));print('ARM METRICS: canonical 256 scale; reference torso 08; tolerance ±12% for thickness; area reported per pose per user clarification.')
    for r in result['rows']:
        print(f'{r["part"]:02}: biceps={r["upper_arm_widths_px"]}, mean={r["mean_upper_arm_px"]}, width_delta={r["width_delta_percent"]}, skin_area={r["skin_area_px2"]}, area_delta={r["skin_area_delta_percent"]:.2f}%, '+('NOT_MEASURABLE_OCCLUDED' if r['midpoint_occluded'] else 'PASS' if r['within_12_percent'] else 'FAIL'))
    failed=[r['part'] for r in result['rows'] if r['within_12_percent'] is False]
    if failed:raise SystemExit(f'Biceps thickness outside ±12%: {failed}; image regeneration required.')

if __name__=='__main__':main()
