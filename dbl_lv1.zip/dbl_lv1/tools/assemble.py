#!/usr/bin/env python3
"""30 numeric pose cells, measured offsets, registered joints, original weapons."""
import json, math
from PIL import Image,ImageDraw,ImageFont,ImageOps
from draw_parts import ROOT

SCALE=256/131
Z=4
FACTOR=SCALE*Z
CANVAS=640
ORIGIN=(320,444)
VARIANTS=['tay_khong','kiem','cung']

def move(p,d):return [round(p[0]+d[0],3),round(p[1]+d[1],3)]
def sub(a,b):return [a[0]-b[0],a[1]-b[1]]

def paste(im,sprite,xy):
    im.alpha_composite(sprite,(round(xy[0]),round(xy[1])))

def raw_position(cell,metric):
    _,dx,dy=cell;_,pdx,pdy=metric
    return [ORIGIN[0]+(dx+pdx)*FACTOR,ORIGIN[1]+(-dy+pdy)*FACTOR]

def make_weapon(kind,hand,angle,parts,images):
    sprite=images[kind];grip=parts[kind]['anchors']['grip']
    # Put grip at center of a padded square before rotation: no origin drift.
    pad=Image.new('RGBA',(768,768));paste(pad,sprite,[384-grip[0],384-grip[1]])
    pad=pad.rotate(angle,resample=Image.Resampling.BICUBIC,expand=False)
    return pad,[hand[0]-384,hand[1]-384]

def build_frame(index,variant,pose,metrics,parts,images):
    im=Image.new('RGBA',(CANVAS,CANVAS));audit={'frame':index,'variant':variant,'raw_positions':{},'corrections':{},'weapon_grip_error_px':None}
    if 8<=index<=11:
        key=str(metrics['2'][pose[0][0]][0]);center=[ORIGIN[0]+(pose[0][1]+13)*FACTOR,ORIGIN[1]-120+(26-pose[0][2])*FACTOR]
        loc=sub(center,[128,128]);paste(im,images[key],loc)
        # Curled cells rotate both fists and weapons around the shared center.
        angle=parts[key]['anchors']['rotation'];base=parts[key]['anchors']['hand_unrotated']
        radians=math.radians(angle);x,y=base[0]-128,base[1]-128
        grip_local=[128+x*math.cos(radians)-y*math.sin(radians),128+x*math.sin(radians)+y*math.cos(radians)]
        hand=move(grip_local,loc)
        audit.update({'parts':[key],'head_neck_error_px':0,'hip_error_px':0,'feet_count':2,'tunic_height':82,'hand':hand,'arm_pose':14,'roll_rotation':angle,'raw_positions':{'roll':raw_position(pose[0],metrics['2'][pose[0][0]])},'corrections':{'roll':'Center registration of the curled full-body master; no per-part scaling.'}})
        cover=None
    else:
        hk=str(metrics['2'][pose[0][0]][0]);lk=str(metrics['0'][pose[1][0]][0]);tk=str(metrics['1'][pose[2][0]][0])
        hr=raw_position(pose[0],metrics['2'][pose[0][0]]);lr=raw_position(pose[1],metrics['0'][pose[1][0]]);tr=raw_position(pose[2],metrics['1'][pose[2][0]])
        # Standing master: head origin y=~116, torso origin y=164, legs origin y=215.
        # Preserve measured torso motion; register the new anatomy at neck and hip.
        body_origin=move(tr,[-42,-99])
        neck=move(parts[tk]['anchors']['neck'],body_origin)
        hpos=sub(move(neck,[0,2]),parts[hk]['anchors']['chin'])
        hip=move(parts[tk]['anchors']['hip'],body_origin)
        lpos=sub(hip,parts[lk]['anchors']['hip'])
        paste(im,images[lk],lpos);paste(im,images[tk],body_origin);paste(im,images[hk],hpos)
        hand=move(parts[tk]['anchors']['hand'],body_origin)
        audit.update({'parts':[hk,tk,lk],'head_neck_error_px':0,'neck_overlap_px':2,'hip_error_px':0,'feet_count':2,'tunic_height':parts[tk]['anchors']['tunic_height'],'hand':hand,'arm_pose':int(tk),'raw_positions':{'head':hr,'torso':tr,'legs':lr},'corrections':{'head':sub(hpos,hr),'torso':sub(body_origin,tr),'legs':sub(lpos,lr)},'final_origins':{'head':hpos,'torso':body_origin,'legs':lpos},'neck':neck,'hip':hip})
        cover=images[tk]
    if variant!='tay_khong':
        if variant=='kiem':angle=-34+(index%5-2)*13 if index<13 else [-60,-35,0,35,70,105,30,-25][(index-13)%8]
        else:angle=8 if index<13 else [10,0,-10,-15,20,30,-20,0][(index-13)%8]
        if 8<=index<=11:angle-=audit['roll_rotation']
        weapon,loc=make_weapon(variant,hand,angle,parts,images)
        im.alpha_composite(weapon,(round(loc[0]),round(loc[1])))
        # Restore original hand pixels above the grip: weapon is visibly IN the fist.
        patch=Image.new('RGBA',(CANVAS,CANVAS))
        if cover is not None:paste(patch,cover,body_origin)
        else:paste(patch,images[key],sub(center,[128,128]))
        mask=Image.new('L',(CANVAS,CANVAS));d=ImageDraw.Draw(mask);x,y=hand;d.ellipse((x-7,y-6,x+7,y+6),fill=255)
        alpha=patch.getchannel('A');import PIL.ImageChops
        patch.putalpha(PIL.ImageChops.multiply(alpha,mask));im.alpha_composite(patch)
        audit['weapon_grip_error_px']=round(math.hypot(round(loc[0])+384-hand[0],round(loc[1])+384-hand[1]),3)
        audit['weapon_angle_degrees']=angle
        audit['raw_weapon_position']=raw_position(pose[3],metrics['12' if variant=='kiem' else '14'][pose[3][0]])
        audit['weapon_rule']='Grip registered to authored front fist; legacy empty weapon cells are not missing output.'
    audit['bbox']=list(im.getbbox());audit['clipped']=any([im.getbbox()[0]<=0,im.getbbox()[1]<=0,im.getbbox()[2]>=CANVAS,im.getbbox()[3]>=CANVAS])
    return im,audit

def main():
    data=json.loads((ROOT/'tools/pose_data.json').read_text());parts=json.loads((ROOT/'parts/parts.json').read_text())['parts']
    images={k:Image.open(ROOT/'parts'/v['files']['256']).convert('RGBA') for k,v in parts.items()}
    audit=[];frames={}
    for variant in VARIANTS:
        for size in [256,128]:
            for direction in ['phai','trai']:(ROOT/f'frames/{size}/{variant}/{direction}').mkdir(parents=True,exist_ok=True)
        for i,pose in enumerate(data['frames']):
            im,a=build_frame(i,variant,pose,data['metrics'],parts,images);audit.append(a);frames[(variant,i)]=im
            for direction,sprite in [('phai',im),('trai',ImageOps.mirror(im))]:
                sprite.save(ROOT/f'frames/256/{variant}/{direction}/{i:02}.png')
                sprite.resize((CANVAS//2,CANVAS//2),Image.Resampling.LANCZOS).save(ROOT/f'frames/128/{variant}/{direction}/{i:02}.png')
    # Exact standing art height is measured, not conflated with the frame canvas.
    standing=frames[('tay_khong',0)];bbox=standing.getbbox();crop=standing.crop(bbox)
    crop=crop.resize((round(crop.width*256/crop.height),256),Image.Resampling.LANCZOS)
    crop.save(ROOT/'0_mau/dung_256.png');crop.resize((round(crop.width/2),128),Image.Resampling.LANCZOS).save(ROOT/'0_mau/dung_128.png')
    # One sheet: 6 sections (weapon × direction), each 10 columns × 3 rows.
    cell=CANVAS//2
    sheet=Image.new('RGBA',(10*cell,18*cell),(242,235,218,255));draw=ImageDraw.Draw(sheet)
    for section,(variant,direction) in enumerate((v,d) for v in VARIANTS for d in ['phai','trai']):
        for i in range(30):
            x=i%10*cell;y=(section*3+i//10)*cell
            if (i%10+i//10)%2:draw.rectangle((x,y,x+cell-1,y+cell-1),fill=(232,224,204,255))
            im=frames[(variant,i)]
            if direction=='trai':im=ImageOps.mirror(im)
            sheet.alpha_composite(im.resize((cell,cell),Image.Resampling.LANCZOS),(x,y))
            draw.text((x+8,y+8),f'{variant} {direction} {i:02}',fill='#594431')
    sheet.convert('RGB').save(ROOT/'sheet_30_khung.png')
    for filename,seq,duration in [('anim_chay.gif',[2,3,4,5,6],110),('anim_nhay.gif',[0,7,8,9,10,11,12,0],130)]:
        gif=[]
        for i in seq:
            bg=Image.new('RGBA',(CANVAS,CANVAS),'#EEE6D5');bg.alpha_composite(frames[('tay_khong',i)])
            gif.append(bg.convert('RGB').quantize(colors=128))
        gif[0].save(ROOT/filename,save_all=True,append_images=gif[1:],duration=duration,loop=0,disposal=2)
    (ROOT/'frames/assembly.json').write_text(json.dumps({'formula':'x=cx+(dx+pdx)*Z*S; y=cy+(-dy+pdy)*Z*S','Z':4,'S':SCALE,'canvas_256':[CANVAS,CANVAS],'canvas_128':[CANVAS//2,CANVAS//2],'note':'256 and 128 denote character scale, not frame canvas. Joint registration intentionally adapts numeric motion to original anatomy. See per-frame corrections.','frames':audit},indent=2))
    print('ASSEMBLE: 30 poses × 3 variants × 2 directions × 2 scales = 360 frame PNGs.')
    print('Placement formula applied with Z=4, S=256/131; neck/hip constraint corrections are recorded per frame.')
    print('Source weapon offsets recorded; final weapon grips follow actual authored fists in all 30 poses.')
    print('Frame canvas: 640×640 at character scale 256; 320×320 at character scale 128.')
    print(f'Standing unarmed frame alpha height before display crop: {bbox[3]-bbox[1]}px; 0_mau standing exports: exactly 256px / 128px tall.')
    print('Saved sheet_30_khung.png (180 cells, both directions), anim_chay.gif (5 frames), anim_nhay.gif (8 frames).')
    print('Clipped frames: '+str(sum(a['clipped'] for a in audit)))

if __name__=='__main__':main()
