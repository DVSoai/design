#!/usr/bin/env python3
"""Composite generated raster parts. No anatomy is drawn or reconstructed."""
from pathlib import Path
import json,math
from PIL import Image,ImageOps,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
FACTOR=4*256/131
ORIGIN=(320,444)
SIZE=640
VISIBLE={0,1,2,3,4,5,6,7,12,21}
VARIANTS=['tay_khong','kiem','cung']

def add(p,d):return [p[0]+d[0],p[1]+d[1]]
def minus(p,d):return [p[0]-d[0],p[1]-d[1]]
def place(im,part,origin):im.alpha_composite(part,(round(origin[0]),round(origin[1])))
def raw(cell,metric):return [ORIGIN[0]+(cell[1]+metric[1])*FACTOR,ORIGIN[1]+(-cell[2]+metric[2])*FACTOR]

def build(i,variant,pose,metrics,parts,images,weapons):
    im=Image.new('RGBA',(SIZE,SIZE));audit={'frame':i,'variant':variant,'weapon_visible':variant!='tay_khong' and i in VISIBLE,'raw_positions':{},'corrections':{}}
    if 8<=i<=11:
        key=str(metrics['2'][pose[0][0]][0]);pos=[ORIGIN[0]-128+(pose[0][1]+13)*FACTOR,ORIGIN[1]-250+(26-pose[0][2])*FACTOR]
        place(im,images[key],pos)
        audit.update({'parts':[key],'origins':{'roll':pos},'independent_roll':True,'character_rotation_applied':False,'feet_count':2,'weapon_grip_error':None,'raw_positions':{'roll':raw(pose[0],metrics['2'][pose[0][0]])}})
    else:
        hk=str(metrics['2'][pose[0][0]][0]);tk=str(metrics['1'][pose[2][0]][0]);lk=str(metrics['0'][pose[1][0]][0])
        hr=raw(pose[0],metrics['2'][pose[0][0]]);tr=raw(pose[2],metrics['1'][pose[2][0]]);lr=raw(pose[1],metrics['0'][pose[1][0]])
        tp=add(tr,[-42,-130]);neck=add(tp,parts[tk]['anchors']['neck']);hip=add(tp,parts[tk]['anchors']['hip'])
        hp=minus(add(neck,[0,2]),parts[hk]['anchors']['chin']);lp=minus(hip,parts[lk]['anchors']['hip'])
        hand=add(tp,parts[tk]['anchors']['hand'])
        body=images[tk];finger=None
        if audit['weapon_visible']:
            key=f'{variant}_{0 if i==1 else i:02}'
            meta_path=ROOT/f'parts/grips/{key}.json'
            if not meta_path.exists():raise ValueError(f'Missing approved image-generated grip layer: {key}')
            gripmeta=json.loads(meta_path.read_text());body=Image.open(ROOT/f'parts/grips/256/{key}.png').convert('RGBA');finger=Image.open(ROOT/f'parts/grips/fingers/{key}.png').convert('RGBA')
            origin=raw(pose[3],metrics['12' if variant=='kiem' else '14'][pose[3][0]])
            hand=add(tp,gripmeta['target_grip']);actual_grip=add(origin,weapons[variant]['grip'])
            audit.update({'weapon_grip_error':math.dist(hand,actual_grip),'weapon_position':origin,'weapon_expected_position':origin,'weapon_runtime_rotation':0,'weapon_angle':weapons[variant]['axis_angle_deg'],'reference_angle':weapons[variant]['reference_angle_deg'],'angle_error_deg':weapons[variant]['angle_error_deg'],'weapon_bbox_size':weapons[variant]['bbox_size'],'weapon_target_bbox':weapons[variant]['target_bbox'],'grip_layer':key,'fingers_wrap':gripmeta['fingers_wrap']})
        else:audit['weapon_grip_error']=None
        place(im,images[lk],lp);place(im,body,tp);place(im,images[hk],hp)
        if audit['weapon_visible']:
            # Fixed original-angle asset, literal table placement, ABOVE body.
            place(im,images[variant],origin)
            # These fingers are raster pixels from the image-generation layer.
            place(im,finger,tp)
        audit.update({'parts':[hk,tk,lk],'origins':{'head':hp,'torso':tp,'legs':lp},'neck':neck,'hip':hip,'hand':hand,'feet': [add(lp,f) for f in parts[lk]['anchors']['feet']],'feet_count':2,'tunic_height':parts[tk]['anchors']['tunic_height'],'raw_positions':{'head':hr,'torso':tr,'legs':lr},'corrections':{'head':minus(hp,hr),'torso':minus(tp,tr),'legs':minus(lp,lr)}})
    bbox=im.getbbox();audit['bbox']=list(bbox);audit['clipped']=bbox[0]<=0 or bbox[1]<=0 or bbox[2]>=SIZE or bbox[3]>=SIZE
    return im,audit

def main():
    data=json.loads((ROOT/'tools/pose_data.json').read_text());parts=json.loads((ROOT/'parts/parts.json').read_text())['parts'];weapons=json.loads((ROOT/'parts/weapons/weapons.json').read_text())
    images={k:Image.open(ROOT/'parts'/v['files']['256']).convert('RGBA') for k,v in parts.items()}
    for k in weapons:images[k]=Image.open(ROOT/f'parts/256/{k}.png').convert('RGBA')
    frames={};records=[]
    for variant in VARIANTS:
        for size in [256,128]:
            for direction in ['phai','trai']:(ROOT/f'frames/{size}/{variant}/{direction}').mkdir(parents=True,exist_ok=True)
        for i,pose in enumerate(data['frames']):
            im,a=build(i,variant,pose,data['metrics'],parts,images,weapons);frames[(variant,i)]=im;records.append(a)
            for direction,sprite in [('phai',im),('trai',ImageOps.mirror(im))]:
                sprite.save(ROOT/f'frames/256/{variant}/{direction}/{i:02}.png');sprite.resize((320,320),Image.Resampling.LANCZOS).save(ROOT/f'frames/128/{variant}/{direction}/{i:02}.png')
    standing=frames[('tay_khong',0)];crop=standing.crop(standing.getbbox());height=crop.height
    crop=crop.resize((round(crop.width*256/height),256),Image.Resampling.LANCZOS);crop.save(ROOT/'0_mau/dung_256.png');crop.resize((round(crop.width/2),128),Image.Resampling.LANCZOS).save(ROOT/'0_mau/dung_128.png')
    try:font=ImageFont.truetype('DejaVuSans.ttf',18)
    except OSError:font=ImageFont.load_default()
    cell=320;header=40
    for v in VARIANTS:
        sheet=Image.new('RGB',(6*cell,5*cell+header),'#EEE6D5');d=ImageDraw.Draw(sheet);d.text((12,10),f'{v.upper()} | 30 KHUNG | 00-29 | HUONG PHAI',font=font,fill='#302724')
        for i in range(30):
            x=i%6*cell;y=i//6*cell+header
            if (i%6+i//6)%2:d.rectangle((x,y,x+cell-1,y+cell-1),fill='#E2D8C2')
            im=frames[(v,i)].resize((cell,cell),Image.Resampling.LANCZOS);sheet.paste(im,(x,y),im);d.text((x+10,y+7),f'{i:02}',font=font,fill='#302724')
        sheet.save(ROOT/f'preview/{v}_30.png')
    sheet=Image.new('RGB',(10*cell,18*cell),'#EEE6D5');d=ImageDraw.Draw(sheet)
    for section,(v,direction) in enumerate((v,dr) for v in VARIANTS for dr in ['phai','trai']):
        for i in range(30):
            x=i%10*cell;y=(section*3+i//10)*cell;im=frames[(v,i)]
            if direction=='trai':im=ImageOps.mirror(im)
            im=im.resize((cell,cell),Image.Resampling.LANCZOS);sheet.paste(im,(x,y),im);d.text((x+8,y+8),f'{v} {direction} {i:02}',font=font,fill='#302724')
    sheet.save(ROOT/'sheet_30_khung.png')
    for name,seq in [('anim_chay.gif',[2,3,4,5,6]),('anim_nhay.gif',[0,7,8,9,10,11,12,0])]:
        gif=[]
        for i in seq:
            bg=Image.new('RGBA',(SIZE,SIZE),'#EEE6D5');bg.alpha_composite(frames[('tay_khong',i)]);gif.append(bg.convert('RGB').quantize(colors=128))
        gif[0].save(ROOT/name,save_all=True,append_images=gif[1:],duration=120,loop=0,disposal=2)
    (ROOT/'frames/assembly.json').write_text(json.dumps({'weapon_visible_frames':sorted(VISIBLE),'formula':'x=cx+(dx+pdx)*4*(256/131); y=cy+(-dy+pdy)*4*(256/131)','joint_registration':'Raw pose offsets are followed by neck-base and hip registration for the approved new anatomy.','frame_canvas_256':[640,640],'frame_canvas_128':[320,320],'frames':records},indent=2))
    print('ASSEMBLE: 30 frames × 3 variants × 2 directions × 2 scales = 360 transparent frame PNGs.')
    print('Weapons visible ONLY at frames 0–7, 12, 21; all other armed-variant frames are identical to unarmed.')
    print('Roll frames 8–11 use four independently image-generated full-body sprites; ZERO character rotation applied.')
    print('Runtime weapon rotation: ZERO. Positions come directly from the fourth pose cell plus part offsets.')
    print('Layer order: character, fixed-angle weapon ABOVE torso, image-generated fingers ABOVE grip.')
    print(f'Standing frame alpha height: {height}px; standing display exports: exactly 256px and 128px tall.')
    print('Clipped frame count: '+str(sum(r['clipped'] for r in records)))
    print('Saved both-direction sheet, 3 preview boards, run GIF (5 frames), jump GIF (8 frames).')

if __name__=='__main__':main()
