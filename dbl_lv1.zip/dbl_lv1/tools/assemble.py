#!/usr/bin/env python3
"""Direct numeric sprite substitution, with zero per-piece pose correction."""
from pathlib import Path
import json
from PIL import Image,ImageOps,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
VISIBLE={0,1,2,3,4,5,6,7,12,21};VARIANTS=['tay_khong','kiem','cung']
def font(n):return ImageFont.truetype('DejaVuSans.ttf',n)
def build(n,variant,scale,canvas,data,parts):
 im=Image.new('RGBA',(canvas,canvas));origin=(canvas/2,canvas*.75);record={'frame':n,'variant':variant,'scale':scale,'origins':{},'parts':[],'weapon_visible':variant!='tay_khong' and n in VISIBLE,'corrections':[],'character_rotation_applied':False}
 order=[1,2,0,3] if n in [0,1] else [1,0,2,3]
 for col in order:
  if col==3 and not record['weapon_visible']:continue
  if col!=0 and 8<=n<=11:continue
  group={0:'2',1:'0',2:'1',3:'12' if variant=='kiem' else '14'}[col];cell=data['frames'][n][col];metric=data['metrics'][group][cell[0]];key=str(metric[0]) if col!=3 else variant;pos=[origin[0]+(cell[1]+metric[1])*4*scale,origin[1]+(-cell[2]+metric[2])*4*scale];sprite=parts[key];im.alpha_composite(sprite,tuple(round(t) for t in pos));record['origins'][key]={'position':pos,'raster_position':[round(t) for t in pos],'frame_cell':cell,'part_offset':metric[1:],'correction':[0,0]};record['parts'].append(key)
 # Weapon stays in front of the torso; retain the already composited face
 # wherever a weapon crosses the head, as explicitly requested.
 if record['weapon_visible']:
  bare,_=build(n,'tay_khong',scale,canvas,data,parts);headkey=str(data['metrics']['2'][data['frames'][n][0][0]][0]);headmask=Image.new('L',(canvas,canvas));hp=record['origins'][headkey]['raster_position'];headmask.paste(parts[headkey].getchannel('A'),tuple(hp));im.paste(bare,(0,0),headmask)
 record['bbox']=im.getbbox();record['clipped']=record['bbox'][0]<=0 or record['bbox'][1]<=0 or record['bbox'][2]>=canvas or record['bbox'][3]>=canvas;return im,record

def main():
 data=json.loads((ROOT/'tools/pose_data.json').read_text());meta=json.loads((ROOT/'parts/parts.json').read_text());frames={};records=[]
 for size,scale,canvas in [(256,256/131,640),(128,128/131,320)]:
  images={k:Image.open(ROOT/'parts'/v['files'][str(size)]).convert('RGBA') for k,v in meta['parts'].items()}
  for k in ['kiem','cung']:images[k]=Image.open(ROOT/f'parts/{size}/{k}.png').convert('RGBA')
  for variant in VARIANTS:
   for direction in ['phai','trai']:(ROOT/f'frames/{size}/{variant}/{direction}').mkdir(parents=True,exist_ok=True)
   for n in range(30):
    im,record=build(n,variant,scale,canvas,data,images);record['output_size']=size;records.append(record)
    for direction,sprite in [('phai',im),('trai',ImageOps.mirror(im))]:sprite.save(ROOT/f'frames/{size}/{variant}/{direction}/{n:02}.png')
    if size==256:frames[(variant,n)]=im
 for size in [256,128]:
  im=Image.open(ROOT/f'frames/{size}/tay_khong/phai/00.png');im.crop(im.getbbox()).save(ROOT/f'0_mau/dung_{size}.png')
 cell=320
 for variant in VARIANTS:
  sheet=Image.new('RGB',(6*cell,5*cell+40),'#E9E1D1');d=ImageDraw.Draw(sheet);d.text((12,10),f'{variant} | 30 frames | original rig',font=font(18),fill='#302724')
  for n in range(30):
   x=n%6*cell;y=n//6*cell+40;im=frames[(variant,n)].resize((cell,cell),Image.Resampling.LANCZOS);sheet.paste(im,(x,y),im);d.text((x+10,y+10),f'{n:02}',font=font(18),fill='#302724')
  sheet.save(ROOT/f'preview/{variant}_30.png')
 sheet=Image.new('RGB',(10*cell,18*cell),'#E9E1D1');d=ImageDraw.Draw(sheet)
 for section,(variant,direction) in enumerate((v,dr) for v in VARIANTS for dr in ['phai','trai']):
  for n in range(30):
   im=frames[(variant,n)];im=ImageOps.mirror(im) if direction=='trai' else im;im=im.resize((cell,cell),Image.Resampling.LANCZOS);x=n%10*cell;y=(section*3+n//10)*cell;sheet.paste(im,(x,y),im);d.text((x+8,y+8),f'{variant} {direction} {n:02}',font=font(16),fill='#302724')
 sheet.save(ROOT/'sheet_30_khung.png')
 for name,seq in [('anim_chay.gif',[2,3,4,5,6]),('anim_nhay.gif',[0,7,8,9,10,11,12,0])]:
  gif=[]
  for n in seq:
   im=Image.new('RGBA',(640,640),'#E9E1D1');im.alpha_composite(frames[('tay_khong',n)]);gif.append(im.convert('RGB').quantize(colors=128))
  gif[0].save(ROOT/name,save_all=True,append_images=gif[1:],duration=120,loop=0,disposal=2)
 (ROOT/'frames/assembly.json').write_text(json.dumps({'frames':records,'layer_order_standing':[1,2,0,3],'layer_order_other':[1,0,2,3],'weapon_face_protection':'Original bare-character pixels restored under head alpha only; torso stays behind bow.','formula':'origin + [(dx+pdx)*4,(-dy+pdy)*4] * output_height/131','weapon_frames':sorted(VISIBLE),'extra_grip_layers':0,'joint_corrections':0},indent=2))
 print('ASSEMBLE: 360 PNG = 30 frames x 3 variants x 2 directions x 2 scales.')
 print('Literal numeric table positions: 100%; per-piece joint corrections=0; extra hand layers=0; runtime rotation=0.')
 print('Layer order: character then weapon in FRONT, matching supplied assembled reference. Weapon crossing face is masked behind the original head; no new hands.')
 print('Four separately image-generated rolling sprites, no standing image rotation; empty slot 22 retained.')
 print('Standing alpha heights: '+str([Image.open(ROOT/f'0_mau/dung_{s}.png').height for s in [256,128]]))
 print('Clipped outputs: '+str(sum(r['clipped'] for r in records)))
if __name__=='__main__':main()
