#!/usr/bin/env python3
"""Original parametric vector artwork. No external images or source code needed."""
from pathlib import Path
import json, math, subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
INK = '#302724'
SKIN = ['#F2C98F', '#D9A066', '#FBE3B8']
BROWN = '#8D5C3D'
SHADOW = '#68432F'
LIGHT = '#AD7950'
CREAM = '#EAD6A4'

def path(d, fill, sw=2.4, extra=''):
    return f'<path d="{d}" fill="{fill}" stroke="{INK}" stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round" {extra}/>'

def ellipse(x,y,rx,ry,fill,sw=2,extra=''):
    return f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{fill}" stroke="{INK}" stroke-width="{sw}" {extra}/>'

def line(d,color=INK,sw=1.5):
    return f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"/>'

def skin(d, tone=0, sw=2.4):
    return path(d,SKIN[tone],sw,'data-skin="true"')

def svg(content, size=256):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">{content}</svg>'

def head(pose=32):
    # Master head; the crown tie never crosses the forehead.
    content = path('M100 37 Q75 21 54 36 L36 34 L47 48 Q68 50 94 42 Z','#AE302F')
    content += path('M98 39 Q78 45 69 57 L53 57 L60 47 Q73 31 96 32 Z','#D6493C')
    content += line('M50 39 Q73 32 90 38','#E16A50',2)
    content += ellipse(117,24,19,17,'#262626',2.8)
    content += path('M103 22 Q105 9 119 9 Q128 9 131 21 Q123 16 118 25 Z','#3D3A38',0)
    content += line('M110 13 Q104 20 112 29 M121 11 Q116 21 124 30','#55504B',1.6)
    content += path('M99 34 Q112 25 132 31 L134 38 Q113 33 102 42 Z','#C44236',2.4)
    content += path('M73 71 Q68 47 89 37 Q119 27 149 45 Q166 56 163 82 L159 96 Q150 112 129 112 Q106 113 89 101 Z','#252626',2.8)
    content += skin('M93 65 Q106 49 130 51 Q156 54 161 76 L164 89 Q162 108 143 112 L119 112 Q99 109 94 95 Q81 96 81 82 Q81 73 92 77 Z')
    content += skin('M91 77 Q83 74 83 83 Q83 93 95 94 L99 105 Q106 112 120 112 L111 101 Q97 93 96 79 Z',1,0)
    content += line('M89 81 Q94 78 95 86 Q90 83 91 89','#A46C45',1.3)
    content += path('M76 74 L70 70 L74 57 L66 60 Q70 43 88 39 L83 33 Q103 32 115 39 Q141 32 157 48 L171 49 L163 58 L176 66 L162 65 L169 77 L157 73 Q155 57 145 54 Q142 67 133 74 L136 57 Q121 74 107 78 L115 59 Q104 75 98 87 L91 81 L89 99 L80 91 Z','#262626',2.6)
    content += path('M80 52 Q91 41 106 43 L96 54 Q113 43 129 46 Q113 50 102 62 L106 49 L85 64 Z','#44403C',0)
    content += path('M136 43 Q151 44 157 53 L146 50 L153 59 Q143 53 136 53 Z','#55504B',0)
    if pose == 35:
        content += ellipse(130,86,10,12,'#FFF9EA',1.8)+ellipse(152,85,8,11,'#FFF9EA',1.8)
        content += ellipse(134,87,4.4,7,'#5E3A26',1)+ellipse(155,85,3.6,6,'#5E3A26',1)
        content += ellipse(142,103,4,5,'#754333',1.5)
    else:
        content += path('M117 87 Q118 76 128 76 Q139 78 138 88 Q133 97 124 95 Q118 94 117 87 Z','#FFF9EA',1.7)
        content += path('M145 85 Q145 76 153 76 Q160 77 159 87 Q155 94 149 92 Z','#FFF9EA',1.7)
        content += ellipse(130,85,5.5,8.4,'#67412A',1.2)+ellipse(154,84,4.3,7.7,'#67412A',1)
        content += ellipse(132,85,2.8,6,'#262321',0)+ellipse(155,84,2.4,5.4,'#262321',0)
        content += ellipse(130,81,1.8,2.4,'#FFFFFF',0)+ellipse(154,80,1.4,2,'#FFFFFF',0)
        content += line('M133 103 Q143 107 150 102','#71452F',1.8)
    content += path('M116 72 L118 68 Q129 65 137 72 L136 75 Q126 71 117 75 Z','#302724',0)
    content += path('M145 71 Q153 65 159 69 L160 73 Q151 71 145 75 Z','#302724',0)
    content += skin('M143 90 Q149 93 145 97 L141 97',1,0)
    content += skin('M104 95 Q108 92 113 95 Q113 98 109 99 Q105 99 104 95 Z',2,0)
    if pose == 33:
        content = '<g transform="rotate(3 128 112)">'+content+'</g>'
    return content

def arm(shoulder,elbow,hand,back=False):
    sx,sy=shoulder; ex,ey=elbow; hx,hy=hand
    # Two segment capsules, hand grip stays at the end of the forearm.
    a=line(f'M{sx} {sy} L{ex} {ey} L{hx} {hy}',INK,19)
    a+=f'<path d="M{sx} {sy} L{ex} {ey} L{hx} {hy}" fill="none" stroke="{SKIN[1 if back else 0]}" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" data-skin="true"/>'
    a+=f'<path d="M{sx-2} {sy} L{ex-2} {ey-2}" fill="none" stroke="{SKIN[0 if back else 2]}" stroke-width="4" stroke-linecap="round" data-skin="true"/>'
    dx,dy=hx-ex,hy-ey; length=max(1,math.hypot(dx,dy)); wx=hx-dx/length*12;wy=hy-dy/length*12
    a+=line(f'M{wx-dx/length*3} {wy-dy/length*3} L{wx+dx/length*3} {wy+dy/length*3}',INK,18)
    a+=line(f'M{wx-dx/length*3} {wy-dy/length*3} L{wx+dx/length*3} {wy+dy/length*3}','#573B2C',14)
    px,py=-dy/length*6,dx/length*6
    a+=line(f'M{wx+px} {wy+py} L{wx-px} {wy-py}','#9D7450',1.4)
    a+=ellipse(hx,hy,8.5,8,SKIN[1 if back else 0],2.2,'data-skin="true"')
    a+=skin(f'M{hx-5} {hy-2} Q{hx-2} {hy-6} {hx+3} {hy-4} L{hx+1} {hy-1} Z',0 if back else 2,0)
    a+=line(f'M{hx+2} {hy+2} l-2 -4 M{hx-2} {hy+3} l-2 -3','#A56E47',1)
    return a

# Explicitly different arm silhouettes: rest, five strides, jump, fall, eight strikes.
ARMS={
 5:((93,99),(97,124),(159,98),(163,124)),
 6:((96,83),(114,80),(159,99),(150,123)),
 7:((91,100),(109,105),(151,78),(169,77)),
 8:((105,78),(118,69),(162,96),(181,97)),
 9:((93,99),(79,109),(155,81),(171,76)),
 10:((103,80),(117,73),(161,96),(180,100)),
 11:((98,81),(113,75),(153,96),(168,94)),
 12:((85,57),(73,38),(169,65),(179,48)),
 14:((101,96),(119,96),(148,98),(130,104)),
 15:((96,91),(113,92),(160,98),(166,110)),
 16:((99,80),(109,69),(150,92),(154,106)),
 17:((89,96),(91,112),(154,91),(155,110)),
 18:((84,107),(67,117),(166,68),(181,57)),
 19:((87,70),(72,59),(165,71),(181,60)),
 20:((105,92),(116,99),(158,64),(159,42)),
 21:((98,87),(114,83),(169,92),(190,101)),
}

def torso(pose=5):
    be,bh,fe,fh=ARMS[pose]
    a=arm((107,77),be,bh,True)
    a+=skin('M118 58 L137 58 L140 76 Q128 84 116 74 Z',0)
    a+=skin('M118 58 L125 58 L126 71 L138 73 L140 76 Q128 84 116 74 Z',1,0)
    a+=path('M110 67 L119 65 L130 76 L138 65 L149 72 Q149 91 144 111 L155 144 Q133 152 105 144 L110 113 Q104 90 110 67 Z',BROWN,2.6)
    a+=path('M110 78 L118 84 L115 108 L111 124 L109 143 L120 146 L106 145 L111 112 Z',SHADOW,0)
    a+=path('M135 82 L144 77 L139 105 L130 118 L121 139 L131 129 L142 117 L149 142 L139 145 L133 128 L121 149 L117 143 Z',LIGHT,0)
    a+=path('M111 65 L118 63 L131 75 L137 65 L143 69 L131 91 L119 113 L114 141 L108 143 L114 112 L125 88 Z',CREAM,1.4)
    a+=line('M114 67 L131 82','#FFF0C7',2)
    a+=path('M108 139 Q130 148 153 139 L155 145 Q129 155 105 145 Z',CREAM,1.5)
    a+=line('M139 119 L145 133 M119 128 L116 138','#5E3E2D',1.3)
    a+=path('M109 110 Q128 116 146 109 L148 120 Q130 126 108 120 Z','#51382C',2)
    a+=line('M111 115 Q128 120 144 114','#9A704A',1.8)
    a+=path('M127 117 Q118 108 118 119 Q119 125 128 121 Q134 108 138 116 Q141 122 129 123 L135 140 L128 138 L126 123 L120 135 L116 132 Z','#61412E',1.8)
    a+=ellipse(128,120,4,5,'#7D5638',1.3)
    a+=arm((145,78),fe,fh)
    return a,{'neck':[128,64],'hip':[128,131],'hand':list(fh),'back_hand':list(bh),'tunic_height':82}

LEGS={
 23:((115,118),(113,151),(141,119),(146,151)),
 24:((115,115),(131,145),(140,115),(156,139)),
 25:((107,106),(88,132),(143,114),(172,100)),
 26:((117,117),(103,146),(137,112),(153,128)),
 27:((105,112),(87,133),(144,108),(174,129)),
 28:((114,112),(94,122),(143,118),(162,142)),
 29:((115,110),(134,137),(139,101),(124,119)),
 30:((117,113),(116,150),(141,102),(155,129)),
 31:((109,115),(85,145),(148,114),(170,145)),
 22:((115,109),(106,133),(139,109),(151,133)),
}

def leg(h,knee,foot,back=False):
    hx,hy=h;kx,ky=knee;fx,fy=foot
    a=line(f'M{hx} {hy} Q{hx} {ky-12} {kx} {ky} L{fx} {fy-10}',INK,25)
    a+=line(f'M{hx} {hy} Q{hx} {ky-12} {kx} {ky} L{fx} {fy-10}','#49382D' if back else '#59402F',20)
    a+=line(f'M{hx-3} {hy+3} Q{hx-4} {ky-12} {kx-3} {ky-3}','#785339',6)
    a+=line(f'M{kx} {ky+1} L{fx} {fy-7}',INK,17)
    a+=line(f'M{kx} {ky+1} L{fx} {fy-7}','#AA855A' if back else '#BC9667',13)
    for t in [.25,.6,.9]:
        x=kx+(fx-kx)*t;y=ky+1+(fy-8-ky)*t
        a+=line(f'M{x-5} {y-2} l10 3','#775C40',1.2)
    a+=path(f'M{fx-8} {fy-5} Q{fx-1} {fy-11} {fx+6} {fy-4} Q{fx+19} {fy-4} {fx+17} {fy+4} Q{fx+5} {fy+10} {fx-10} {fy+4} Z','#704B32' if back else '#835A3A',2.4)
    a+=path(f'M{fx-10} {fy+1} Q{fx+3} {fy+6} {fx+17} {fy+1} L{fx+17} {fy+5} Q{fx+3} {fy+10} {fx-10} {fy+5} Z','#B89969',1.2)
    a+=line(f'M{fx-3} {fy-5} Q{fx+3} {fy-6} {fx+8} {fy-2}','#C09665',1.5)
    return a

def legs(pose=23):
    bk,bf,fk,ff=LEGS[pose]
    a=leg((117,85),bk,bf,True)+leg((139,85),fk,ff)
    a+=path('M108 76 Q128 71 149 76 L151 94 Q140 100 129 91 Q119 99 106 94 Z','#59402F',2.2)
    a+=line('M128 82 L129 91','#302724',1.6)
    return a,{'hip':[128,80],'feet':[list(bf),list(ff)]}

def weapon(kind):
    # Source dimensions are relative to a 256px tall character.
    if kind=='kiem':
        c=path('M124 219 L124 37 L128 19 L132 37 L132 219 Z','#BCC7C7',2)
        c+=path('M128 24 L128 214 L132 214 L132 37 Z','#EEF2E5',0)
        c+=line('M126 44 L126 206','#7B9193',1)
        c+=path('M111 215 Q128 211 145 215 L145 221 Q128 218 111 221 Z','#B89959',2)
        c+=path('M124 219 L132 219 L133 246 L123 246 Z','#654431',1.8)
        for y in [224,230,236,242]:c+=line(f'M125 {y} l6 2','#C2A06D',1.2)
        c+=ellipse(128,248,6,4,'#B89959',1.6)
        c='<g transform="translate(128 233) scale(.85) translate(-128 -233)">'+c+'</g>'
        return c,{'grip':[128,233],'length':200,'rotation':-34}
    c=path('M112 0 Q169 46 166 125 Q169 205 112 255 L106 250 Q151 201 151 128 Q152 54 106 6 Z','#825038',2)
    c+=line('M111 8 Q157 57 157 125 Q161 198 111 246','#CAA46B',3)
    c+=line('M110 4 L137 128 L110 252','#DDD0A4',1.5)
    c+=path('M150 114 L166 114 L166 141 L150 141 Z','#4B352A',1.8)
    for y in [119,125,131,137]:c+=line(f'M152 {y} l12 2','#A88150',1.4)
    return c,{'grip':[158,128],'height':256,'rotation':0}

def render(src,dst,width=1024):
    p=subprocess.run(['inkscape',str(src),'--export-type=png',f'--export-filename={dst}',f'--export-width={width}'],capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stderr)

def main():
    for d in ['parts/svg','parts/raw','prompts','0_mau','tools/logs']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    meta={}
    all_parts=[]
    for i in [32,33,35]: all_parts.append((i,'head',head(i),{'chin':[128,112]}))
    for i in ARMS:
        c,a=torso(i);all_parts.append((i,'torso',c,a))
    for i in LEGS:
        c,a=legs(i);all_parts.append((i,'legs',c,a))
    # Four curled full-body cells share the exact same masters and palette.
    h=head(32);t,ta=torso(14);l,la=legs(22)
    # Fold the pelvis back toward the shoulders instead of spinning a straight
    # standing silhouette. All geometry still comes from the three masters.
    neck=(128,112); hip=(128-67/math.sqrt(2),112+67/math.sqrt(2))
    body='<g transform="rotate(45 128 112) translate(0 48)">'+t+'</g>'
    folded_legs=f'<g transform="rotate(140 {hip[0]} {hip[1]}) translate({hip[0]-128} {hip[1]-80})">'+l+'</g>'
    folded_head='<g transform="rotate(35 128 112)">'+h+'</g>'
    whole='<g transform="translate(22 36)">'+folded_legs+body+folded_head+'</g>'
    hand0=(130,152);vx,vy=hand0[0]-128,hand0[1]-112
    roll_hand=[22+(128+(vx-vy)/math.sqrt(2)),36+(112+(vx+vy)/math.sqrt(2))]
    for i,angle in enumerate([0,90,180,270],1):
        c=f'<g transform="rotate({angle} 128 128)">{whole}</g>'
        all_parts.append((i,'roll',c,{'center':[128,128],'rotation':angle,'hand_unrotated':roll_hand,'feet_count':2,'tunic_height':82,'tunic_scale':1}))
    all_parts.sort(key=lambda p:({32:0,5:1,23:2}.get(p[0],3),p[0]))
    for i,kind,c,a in all_parts:
        f=ROOT/f'parts/svg/{i:02}.svg';f.write_text(svg(c))
        render(f,ROOT/f'parts/raw/{i:02}.png')
        meta[str(i)]={'kind':kind,'anchors':a,'master':{'head':32,'torso':5,'legs':23,'roll':[32,5,23]}[kind]}
        desc=(f'Đinh Bộ Lĩnh Lv1, original vector chibi facing right; part {i}, {kind}. '
              'Derive from masters head 32 / torso 5 / legs 23; preserve scale and palette. '
              'Black topknot and tousled hair; red crown tie trailing backward, no forehead band. '
              'Sleeveless brown cross-collar tunic, cream collar and hem, dark central belt knot; '
              'bare arms, dark wrist wraps, dark trousers, light shin wraps, brown cloth shoes. '
              'Skin base #F2C98F, shadow #D9A066, highlight #FBE3B8. Soft even dark outlines; 2–3 tones; not pixel art. '
              f'Exact procedural parameters: {json.dumps(a,ensure_ascii=False)}. '
              'This is a procedural vector drawing brief, not a claim of a separate image-model call.')
        (ROOT/f'prompts/{i:02}.txt').write_text(desc+'\n')
    for kind in ['kiem','cung']:
        c,a=weapon(kind);f=ROOT/f'parts/svg/{kind}.svg';f.write_text(svg(c));render(f,ROOT/f'parts/raw/{kind}.png')
        meta[kind]={'kind':'weapon','anchors':a}
        (ROOT/f'prompts/{kind}.txt').write_text(f'Original {kind} SVG, soft dark outline, simple historical materials. Geometry: {json.dumps(a)}. No copied artwork.\n')
    (ROOT/'tools/drawing_meta.json').write_text(json.dumps(meta,indent=2))
    print(f'DRAW: {len(all_parts)} original character parts + 2 original weapon SVGs; RGBA render 1024px.')
    print('MASTERS: head 32, torso 5, legs 23. Remaining parts reuse the same vector functions.')
    print('No external artwork is loaded by this drawing script.')

if __name__=='__main__':main()
