#!/usr/bin/env python3
"""Record actual image-tool outputs and hashes; never manufacture generation calls."""
from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 calls=json.loads((ROOT/'tools/image_calls.json').read_text())
 for p in (ROOT/'tools/logs').glob('part_*.json'):
  v=json.loads(p.read_text());calls[str(v['part'])]=v
 for k,v in calls.items():
  raw=ROOT/f'parts/raw/{int(k):02}.png'
  if raw.exists():v['raw_sha256']=digest(raw);v.setdefault('references',4)
 calls['22']={'part':22,'image_tool_calls':0,'status':'EMPTY_CONTROL_NO_CHARACTER','reason':'The original slot is a fully transparent 4x4 canvas; preserve it exactly. No character is drawn here.'}
 (ROOT/'tools/image_calls.json').write_text(json.dumps(calls,indent=2))
 for k,name in [(32,'head'),(5,'torso'),(23,'legs')]:shutil.copy2(ROOT/f'parts/raw/{k:02}.png',ROOT/f'0_mau/master_{name}.png')
 # Numeric aliases make the native directory usable as direct image substitutes.
 for label in ['native','256','128']:
  for name,k in [('kiem',262),('cung',283)]:shutil.copy2(ROOT/f'parts/{label}/{name}.png',ROOT/f'parts/{label}/{k}.png')
 print(f'MANIFEST: 32 fresh character images; actual image calls={sum(v["image_tool_calls"] for v in calls.values())}; slot22=empty control, not an ungenerated character.')
 print('Native drop-in names: 01–35 as used by the numeric rig; 262/283 weapon aliases also supplied. Three new raw masters saved.')
if __name__=='__main__':main()
