#!/usr/bin/env python3
"""Original fixed-angle weapon artwork, measured size and direct slot placement."""
from pathlib import Path
import json,subprocess,math
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
S=256/131

def angle(im,kind):
 a=np.asarray(im);rgb=a[:,:,:3].astype(float);m=a[:,:,3]>127
 if kind=='kiem':
  m &= (rgb.max(2)-rgb.min(2)<45)&(rgb.mean(2)>100)
  y,x=np.where(m);_,v=np.linalg.eigh(np.cov(np.column_stack([x,y]).T));vec=v[:,-1];vec=vec if vec[0]<0 else -vec
  return float(np.degrees(np.arctan2(vec[1],vec[0])))
 y,x=np.where(m);top=y.min();bot=y.max();tx=x[y<=top+2].mean();bx=x[y>=bot-2].mean()
 return float(np.degrees(np.arctan2(top-bot,tx-bx)))


def render(art,path,canvas):
 path.write_text(art);tmp=path.with_suffix('.tmp.png')
 subprocess.run(['inkscape',str(path),'--export-type=png',f'--export-filename={tmp}',f'--export-width={canvas[0]*4}'],check=True,capture_output=True)
 im=Image.open(tmp).convert('RGBA').resize(tuple(canvas),Image.Resampling.LANCZOS);tmp.unlink();return im

def bounds(im):
 y,x=np.where(np.asarray(im)[:,:,3]>127);return [int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)]

def axial_length(im,theta):
 y,x=np.where(np.asarray(im)[:,:,3]>127);u=np.array([math.cos(math.radians(theta)),math.sin(math.radians(theta))]);t=np.column_stack([x,y])@u;return float(t.max()-t.min()+1)

def main():
 out=ROOT/'parts/weapons';ref=json.loads((ROOT/'tools/weapon_reference.json').read_text());old=json.loads((out/'weapons.json').read_text());meta={}
 SWORD_TEMPLATE='<svg xmlns="http://www.w3.org/2000/svg" width="104" height="64" viewBox="0 0 104 64"><g stroke="#302724" stroke-linejoin="round" stroke-linecap="round"><path d="M1 61L7 47 70 15 77 26 12 61Z" fill="#8D9A9D" stroke-width="1.5"/><path d="M3 59L12 52 73 20 70 16 8 48Z" fill="#E7EBE6" stroke="none"/><path d="M3 60L14 55 76 23 77 26 12 61Z" fill="#566971" stroke="none"/><path d="M12 52L73 20" fill="none" stroke="#A6B8BA" stroke-width="1.2"/><path d="M69 14L76 26 79 24 72 12Z" fill="#C9A05E" stroke-width="1.3"/><path d="M74 17L96 4Q100 2 101 7L78 21Z" fill="#75513B" stroke-width="1.5"/><path d="M79 13L82 17M84 10L87 14M89 7L92 11M94 5L97 9" stroke="#D4B67A" stroke-width="1"/><path d="M96 3L100 1Q104 2 102 7L99 9Z" fill="#D6AD5D" stroke-width="1.4"/></g></svg>'
 # Map the original broad blade to its existing canvas, then shorten only
 # along the blade axis ABOUT its grip. Perpendicular blade width is retained.
 grip=np.array([163.508302665829,30.22265625]);theta=ref['kiem']['source_angle_deg'];u=np.array([math.cos(math.radians(theta)),math.sin(math.radians(theta))]);base=np.array([[1.942,0,0],[0,1.828,6],[0,0,1.]])
 inner=SWORD_TEMPLATE.split('>',1)[1].rsplit('</svg>',1)[0]
 ratio=.87
 for iteration in range(3):
  A=np.eye(2)+(ratio-1)*np.outer(u,u);T=np.eye(3);T[:2,:2]=A;T[:2,2]=grip-A@grip;M=T@base
  a,b,c,d,e,f=M[0,0],M[1,0],M[0,1],M[1,1],M[0,2],M[1,2]
  art=f'<svg xmlns="http://www.w3.org/2000/svg" width="203" height="125" viewBox="0 0 203 125"><g transform="matrix({a} {b} {c} {d} {e} {f})">{inner}</g></svg>'
  im=render(art,out/'kiem.svg',[203,125]);length=axial_length(im,theta);ratio*=200/length
 bb=bounds(im);aa=angle(im,'kiem')
 meta['kiem']={'grip':grip.tolist(),'canvas':[203,125],'bbox':bb,'bbox_size':[bb[2]-bb[0],bb[3]-bb[1]],'target_bbox':[bb[2]-bb[0],bb[3]-bb[1]],'axis_angle_deg':aa,'reference_angle_deg':theta,'angle_error_deg':abs(aa-theta),'runtime_rotation_deg':0,'axial_length_px':length,'standing_height_px':256,'length_height_ratio':length/256,'perpendicular_width_preserved':True}
 im.save(ROOT/'parts/256/kiem.png');im.resize((102,62),Image.Resampling.LANCZOS).save(ROOT/'parts/128/kiem.png')
 # Symmetry in the bow's own axis: equal arclengths and equal recurved tips.
 theta=ref['cung']['source_angle_deg'];u=np.array([math.cos(math.radians(theta)),math.sin(math.radians(theta))]);n=np.array([-u[1],u[0]])
 ss=np.linspace(-140,140,1001)
 def curve(B):
  t=np.abs(ss)/140;f=-B*t*t+.18*B*np.maximum((t-.86)/.14,0)**2
  return ss[:,None]*u+f[:,None]*n
 lo,hi=0.,180.
 for _ in range(70):
  B=(lo+hi)/2;pts=curve(B);span=np.ptp(pts,axis=0)+14
  if span[0]/span[1]<170/258:lo=B
  else:hi=B
 pts=curve((lo+hi)/2);scale=258/(np.ptp(pts,axis=0)[1]+14);pts*=scale;offset=np.array([23.,6.])+7*scale-pts.min(0);pts+=offset;grip=offset
 path='M'+' L'.join(f'{x:.4f},{y:.4f}' for x,y in pts[::5])
 p0,p1=pts[0],pts[-1];wrap0=grip-u*12*scale;wrap1=grip+u*12*scale
 art=f'<svg xmlns="http://www.w3.org/2000/svg" width="211" height="266" viewBox="0 0 211 266"><g fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M{p0[0]},{p0[1]} L{p1[0]},{p1[1]}" stroke="#A18B60" stroke-width="3.2"/><path d="{path}" stroke="#302724" stroke-width="{14*scale}"/><path d="{path}" stroke="#875638" stroke-width="{9.6*scale}"/><path d="{path}" stroke="#B38A56" stroke-width="{2.1*scale}"/><path d="M{wrap0[0]},{wrap0[1]} L{wrap1[0]},{wrap1[1]}" stroke="#382B24" stroke-width="{15*scale}"/>'
 for s in np.arange(-10,11,4):
  c=grip+s*scale*u;a=c-n*5.2*scale-u*1.2;b=c+n*5.2*scale+u*1.2
  art+=f'<path d="M{a[0]},{a[1]} L{b[0]},{b[1]}" stroke="#C2A378" stroke-width="2.4"/>'
 art+='</g></svg>';im=render(art,out/'cung.svg',[211,266]);bb=bounds(im);aa=angle(im,'cung');half=np.linalg.norm(np.diff(pts[:501],axis=0),axis=1).sum()
 meta['cung']={'grip':grip.tolist(),'canvas':[211,266],'bbox':bb,'bbox_size':[bb[2]-bb[0],bb[3]-bb[1]],'target_bbox':ref['cung']['target_bbox_256'],'axis_angle_deg':aa,'reference_angle_deg':theta,'angle_error_deg':abs(aa-theta),'runtime_rotation_deg':0,'upper_limb_length_px':float(half),'lower_limb_length_px':float(half),'limb_ratio':1.,'grip_arc_fraction':.5,'string_width_px':3.2,'symmetry_axis_deg':theta}
 im.save(ROOT/'parts/256/cung.png');im.resize((106,133),Image.Resampling.LANCZOS).save(ROOT/'parts/128/cung.png')
 (out/'weapons.json').write_text(json.dumps(meta,indent=2))
 for k,m in meta.items():print(f'WEAPON {k}: bbox={m["bbox_size"]}; angle={m["axis_angle_deg"]:.3f}; reference={m["reference_angle_deg"]:.3f}; delta={m["angle_error_deg"]:.3f}; rotation=0')
 print(f'SWORD axial length={length:.3f}px; height=256px; ratio={length/256:.5f}; thickness retained.')
 print(f'BOW equal limbs={half:.3f}px / {half:.3f}px; grip arc fraction=0.5; string=3.2px.')
 if any(m['angle_error_deg']>10 for m in meta.values()):raise SystemExit('Angle error')

if __name__=='__main__':main()
