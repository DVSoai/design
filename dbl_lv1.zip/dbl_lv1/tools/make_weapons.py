#!/usr/bin/env python3
"""Original SVG weapon drawings fitted to unchanged native sprite rectangles."""
from pathlib import Path
import json,subprocess
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]

def main():
 drawings={
 'kiem':'''<svg xmlns="http://www.w3.org/2000/svg" width="104" height="64" viewBox="0 0 104 64"><g stroke="#302724" stroke-linejoin="round" stroke-linecap="round"><path d="M1 61 L4 47 L64 18 L66 25Z" fill="#8E9B9E" stroke-width="1.5"/><path d="M3 57 L6 49 L64 20 L63 18 L4 47Z" fill="#E4EBE6" stroke="none"/><path d="M2 60 L8 53 L65 23 L66 25Z" fill="#586D74" stroke="none"/><path d="M6 49 L64 20" fill="none" stroke="#ACBBBD" stroke-width=".8"/><path d="M63 18 L96 3 Q101 2 102 5 Q102 8 99 10 L66 25Z" fill="#76503B" stroke-width="1.4"/><path d="M67 17 L71 23 M73 14 L77 20 M79 11 L83 17 M85 8 L89 14 M91 6 L95 11" stroke="#C3A374" stroke-width=".8"/><path d="M97 3 Q101 2 102 5 L100 8 L96 7Z" fill="#CEAB66" stroke-width="1"/></g></svg>''',
 'cung':'''<svg xmlns="http://www.w3.org/2000/svg" width="108" height="136" viewBox="0 0 108 136"><g fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M84 7 L17 131" stroke="#AE976C" stroke-width="1.3"/><path d="M84 7 Q78 5 79 12 C97 36 104 65 87 90 C73 112 40 124 18 127 Q14 128 17 131" stroke="#302724" stroke-width="7.2"/><path d="M84 7 Q78 5 79 12 C97 36 104 65 87 90 C73 112 40 124 18 127 Q14 128 17 131" stroke="#86583B" stroke-width="4.8"/><path d="M83 8 C99 38 101 64 86 88 C70 111 40 121 19 127" stroke="#BE9768" stroke-width="1.1"/><path d="M95 65 Q94 79 85 92" stroke="#4B3427" stroke-width="6.4"/><path d="M92 67 L98 69 M91 72 L97 74 M89 77 L95 79 M87 82 L93 84 M84 87 L90 89" stroke="#CAB183" stroke-width="1.2"/></g></svg>'''}
 geo=json.loads((ROOT/'tools/geometry.json').read_text());meta={}
 for kind,art in drawings.items():
  source_id=262 if kind=='kiem' else 283;g=geo[str(source_id)];p=ROOT/f'parts/weapons/{kind}.svg';p.write_text(art);temp=ROOT/f'parts/weapons/.{kind}.png';subprocess.run(['inkscape',str(p),'--export-type=png',f'--export-filename={temp}','--export-width=1040'],capture_output=True,check=True);im=Image.open(temp).convert('RGBA');crop=im.crop(im.getbbox())
  for label,scale in [('native',1),('256',256/131),('128',128/131)]:
   canvas=tuple(round(v*scale) for v in g['canvas']);bb=[round(v*scale) for v in g['bbox']];out=Image.new('RGBA',canvas);out.alpha_composite(crop.resize((bb[2]-bb[0],bb[3]-bb[1]),Image.Resampling.LANCZOS),(bb[0],bb[1]));out.save(ROOT/f'parts/{label}/{kind}.png')
  temp.unlink();meta[kind]={'canvas_native':g['canvas'],'bbox_native':g['bbox'],'runtime_rotation':0,'per_frame_correction':[0,0],'carry_mode':'original numeric placement, weapon in front of torso; no added grip layers'}
  print(f'WEAPON {kind}: native canvas={g["canvas"]}; occupied rectangle={g["bbox"]}; rotation=0; position correction=[0,0]; front layer.')
 (ROOT/'parts/weapons/weapons.json').write_text(json.dumps(meta,indent=2))
if __name__=='__main__':main()
