#!/usr/bin/env python3
"""Original fixed-angle weapon artwork, measured size and direct slot placement."""
from pathlib import Path
import json,subprocess,math
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
S=256/131

def angle(im,kind):
 a=np.asarray(im);rgb=a[:,:,:3].astype(float);m=a[:,:,3]>127
 if kind=='kiem':
  m &= (rgb.max(2)-rgb.min(2)<45)&(rgb.mean(2)>100)
  y,x=np.where(m);_,v=np.linalg.eigh(np.cov(np.column_stack([x,y]).T));vec=v[:,-1];vec=vec if vec[0]<0 else -vec
  return float(np.degrees(np.arctan2(vec[1],vec[0])))
 y,x=np.where(m);top=y.min();bot=y.max();tx=x[y<=top+2].mean();bx=x[y>=bot-2].mean()
 return float(np.degrees(np.arctan2(top-bot,tx-bx)))

def main():
 out=ROOT/'parts/weapons';out.mkdir(exist_ok=True);ref=json.loads((ROOT/'tools/weapon_reference.json').read_text())
 sword='''<svg xmlns="http://www.w3.org/2000/svg" width="104" height="64" viewBox="0 0 104 64"><g stroke="#302724" stroke-linejoin="round" stroke-linecap="round"><path d="M1 61L7 47 70 15 77 26 12 61Z" fill="#8D9A9D" stroke-width="1.5"/><path d="M3 59L12 52 73 20 70 16 8 48Z" fill="#E7EBE6" stroke="none"/><path d="M3 60L14 55 76 23 77 26 12 61Z" fill="#566971" stroke="none"/><path d="M12 52L73 20" fill="none" stroke="#A6B8BA" stroke-width="1.2"/><path d="M69 14L76 26 79 24 72 12Z" fill="#C9A05E" stroke-width="1.3"/><path d="M74 17L96 4Q100 2 101 7L78 21Z" fill="#75513B" stroke-width="1.5"/><path d="M79 13L82 17M84 10L87 14M89 7L92 11M94 5L97 9" stroke="#D4B67A" stroke-width="1"/><path d="M96 3L100 1Q104 2 102 7L99 9Z" fill="#D6AD5D" stroke-width="1.4"/></g></svg>'''
 bow='''<svg xmlns="http://www.w3.org/2000/svg" width="108" height="136" viewBox="0 0 108 136"><path d="M86 7L17 131" stroke="#C8BE9C" stroke-width=".9" fill="none"/><path d="M86 7Q76 2 77 11C80 23 92 32 96 54C107 91 74 115 21 127Q14 128 17 131" stroke="#302724" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M86 7Q76 2 77 11C80 23 92 32 96 54C107 91 74 115 21 127Q14 128 17 131" stroke="#815235" stroke-width="6.2" fill="none" stroke-linecap="round"/><path d="M85 6Q79 5 81 12C86 24 95 38 97 54C106 89 74 111 22 126" stroke="#BF9762" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M98 68Q96 82 85 94" stroke="#4D382B" stroke-width="8.2" fill="none"/><path d="M94 69L101 72M92 75L99 78M89 81L96 84M85 87L92 90" stroke="#C1A175" stroke-width="1.4"/></svg>'''
 meta={}
 for name,art,native_grip in [('kiem',sword,[85,13]),('cung',bow,[93,80])]:
  src=out/f'{name}.svg';src.write_text(art);tmp=out/f'.{name}_render.png'
  p=subprocess.run(['inkscape',str(src),'--export-type=png',f'--export-filename={tmp}','--export-width=864'],capture_output=True,text=True)
  if p.returncode:raise RuntimeError(p.stderr)
  high=Image.open(tmp).convert('RGBA');arr=np.array(high);arr[arr[:,:,3]<18]=0;high=Image.fromarray(arr);bb=high.getbbox();crop=high.crop(bb)
  target=[round(v) for v in ref[name]['target_bbox_256']];canvas=[round(v*S) for v in ref[name]['source_canvas']];offset=[round(v*S) for v in ref[name]['source_bbox'][:2]]
  sprite=crop.resize(tuple(target),Image.Resampling.LANCZOS);im=Image.new('RGBA',tuple(canvas));im.alpha_composite(sprite,tuple(offset));im.save(ROOT/f'parts/256/{name}.png');im.resize((round(canvas[0]/2),round(canvas[1]/2)),Image.Resampling.LANCZOS).save(ROOT/f'parts/128/{name}.png')
  native_canvas=ref[name]['source_canvas'];factor=high.width/native_canvas[0]
  grip=[offset[j]+(native_grip[j]*factor-bb[j])*target[j]/(bb[j+2]-bb[j]) for j in range(2)]
  rgba=np.asarray(im);ys,xs=np.where(rgba[:,:,3]>127);bbox=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)];actual_angle=angle(im,name)
  meta[name]={'grip':grip,'canvas':canvas,'bbox':bbox,'bbox_size':[bbox[2]-bbox[0],bbox[3]-bbox[1]],'target_bbox':ref[name]['target_bbox_256'],'axis_angle_deg':actual_angle,'reference_angle_deg':ref[name]['source_angle_deg'],'angle_error_deg':abs(actual_angle-ref[name]['source_angle_deg']),'runtime_rotation_deg':0,'opaque_offset':offset,'native_design_grip':native_grip}
  tmp.unlink()
 (out/'weapons.json').write_text(json.dumps(meta,indent=2))
 for k,m in meta.items():print(f'WEAPON {k}: bbox={m["bbox_size"]}; target={m["target_bbox"]}; angle={m["axis_angle_deg"]:.3f}; reference={m["reference_angle_deg"]:.3f}; delta={m["angle_error_deg"]:.3f}; runtime_rotation=0')
 if any(m['angle_error_deg']>10 for m in meta.values()):raise SystemExit('Weapon angle exceeds 10 degrees')

if __name__=='__main__':main()
