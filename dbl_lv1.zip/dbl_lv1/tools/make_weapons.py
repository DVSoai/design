#!/usr/bin/env python3
"""Only weapons use SVG. This module contains no character drawing."""
from pathlib import Path
import subprocess,json
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]

def main():
    sword='''<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256"><g transform="translate(128 233) scale(.85) translate(-128 -233)" stroke="#302724" stroke-linejoin="round"><path d="M124 219V37L128 19 132 37V219Z" fill="#BAC5C4" stroke-width="2"/><path d="M128 24V214H132V37Z" fill="#F0F0E2" stroke="none"/><path d="M111 215Q128 211 145 215V221Q128 218 111 221Z" fill="#B89959" stroke-width="2"/><path d="M124 219H132L133 246H123Z" fill="#654431" stroke-width="2"/><path d="M125 224L131 226M125 230L131 232M125 236L131 238M125 242L131 244" stroke="#C2A06D" stroke-width="1.3"/><ellipse cx="128" cy="248" rx="6" ry="4" fill="#B89959" stroke-width="1.5"/></g></svg>'''
    bow='''<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256"><g stroke="#302724" stroke-linejoin="round"><path d="M112 1Q169 46 166 125Q169 205 112 254L106 249Q151 201 151 128Q152 54 106 7Z" fill="#825038" stroke-width="2"/><path d="M111 8Q157 57 157 125Q161 198 111 246" fill="none" stroke="#CAA46B" stroke-width="3"/><path d="M110 5L137 128 110 251" fill="none" stroke="#DDD0A4" stroke-width="1.5"/><path d="M150 114H166V141H150Z" fill="#4B352A" stroke-width="2"/><path d="M152 119L164 121M152 125L164 127M152 131L164 133M152 137L164 139" stroke="#A88150" stroke-width="1.4"/></g></svg>'''
    out=ROOT/'parts/weapons';out.mkdir(exist_ok=True)
    for name,data in [('kiem',sword),('cung',bow)]:
        src=out/f'{name}.svg';src.write_text(data)
        dest=ROOT/f'parts/256/{name}.png'
        p=subprocess.run(['inkscape',str(src),'--export-type=png',f'--export-filename={dest}','--export-width=256'],capture_output=True,text=True)
        if p.returncode:raise RuntimeError(p.stderr)
        Image.open(dest).resize((128,128),Image.Resampling.LANCZOS).save(ROOT/f'parts/128/{name}.png')
    (out/'weapons.json').write_text(json.dumps({'kiem':{'grip':[128,233],'length_about':200},'cung':{'grip':[158,128],'height_about':256}},indent=2))
    print('WEAPONS: 2 original SVG weapons, rendered at both scales. No character SVGs exist.')

if __name__=='__main__':main()
