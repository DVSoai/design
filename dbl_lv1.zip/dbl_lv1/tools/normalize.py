#!/usr/bin/env python3
"""Fit newly image-generated rasters into unchanged numeric sprite rectangles."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image
from scipy import ndimage
ROOT=Path(__file__).resolve().parents[1]
PALETTE=np.array([[242,201,143],[217,160,102],[251,227,184]],dtype=np.uint8)

def skin_mask(im):
 a=np.asarray(im);r,g,b=[a[:,:,i].astype(int) for i in range(3)]
 return (r>205)&(g>132)&(b>65)&(r-g>=22)&(g-b>=24)&(a[:,:,3]>160)

def quantize(im,mask):
 a=np.array(im);rgb=a[:,:,:3].astype(float);distance=((rgb[:,:,None,:]-PALETTE[None,None,:,:])**2).sum(3);a[:,:,:3][mask]=PALETTE[np.argmin(distance,axis=2)[mask]];return Image.fromarray(a)

def clean(im):
 a=np.array(im.convert('RGBA'));a[a[:,:,3]<16]=0;a[:,:,3][a[:,:,3]>245]=255;labels,n=ndimage.label(a[:,:,3]>0);sizes=np.bincount(labels.ravel());remove=sizes<max(8,int(np.count_nonzero(a[:,:,3])*.00005));remove[0]=False;a[remove[labels]]=0
 out=Image.fromarray(a);bbox=out.getbbox()
 if not bbox:raise ValueError('Generated character is empty')
 return out.crop(bbox),bbox

def normalize(ids=None):
 geo=json.loads((ROOT/'tools/geometry.json').read_text());previous=json.loads((ROOT/'parts/parts.json').read_text()) if (ROOT/'parts/parts.json').exists() else {'parts':{}}
 selected=ids or [int(p.stem) for p in (ROOT/'parts/raw').glob('*.png')]
 if ids is None:selected.append(22)
 for k in sorted(set(selected)):
  g=geo[str(k)];crop=None;rawbox=None
  if not g['empty']:
   crop,rawbox=clean(Image.open(ROOT/f'parts/raw/{k:02}.png'));sm=skin_mask(crop) if k not in range(23,32) else np.zeros((crop.height,crop.width),bool);crop=quantize(crop,sm)
  else:sm=None
  rec={'canvas_native':g['canvas'],'occupied_bbox_native':g['bbox'],'raw_crop_bbox':rawbox,'files':{},'kind':'empty_control' if k==22 else 'roll' if k<5 else 'torso' if k<22 else 'legs' if k<32 else 'head','assembly_correction_px':[0,0],'image_tool_required':k!=22}
  for label,scale in [('native',1.),('256',256/131),('128',128/131)]:
   dims=tuple(round(v*scale) for v in g['canvas']);im=Image.new('RGBA',dims);mask=Image.new('L',dims)
   if crop:
    bb=[round(v*scale) for v in g['bbox']];wh=(bb[2]-bb[0],bb[3]-bb[1]);sprite=crop.resize(wh,Image.Resampling.LANCZOS);m=Image.fromarray((sm*255).astype(np.uint8)).resize(wh,Image.Resampling.NEAREST);sprite=quantize(sprite,(np.asarray(m)>127)&(np.asarray(sprite)[:,:,3]>0));im.alpha_composite(sprite,(bb[0],bb[1]));mask.paste(m,(bb[0],bb[1]))
   im.save(ROOT/f'parts/{label}/{k:02}.png');rec['files'][label]=f'{label}/{k:02}.png'
   if label=='256':mask.save(ROOT/f'parts/masks/{k:02}.png')
  previous['parts'][str(k)]=rec
  print(f'PART {k:02}: native_canvas={g["canvas"]}; native_bbox={g["bbox"]}; raw_crop={rawbox}; correction=[0,0]; '+('EMPTY_CONTROL' if k==22 else 'NEW_IMAGE_RASTER'))
 previous.update(scale_256=256/131,scale_128=128/131,normalization='Fit generated raster to exact original numeric canvas/occupied rectangle; no common torso height, joint shifting, extra hands or anatomy drawing.')
 (ROOT/'parts/parts.json').write_text(json.dumps(previous,indent=2))
 for k in [5,23,32]:
  for size in [256,128]:
   p=ROOT/f'parts/{size}/{k:02}.png'
   if p.exists():(ROOT/f'0_mau/{k:02}_{size}.png').write_bytes(p.read_bytes())
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--parts',nargs='*',type=int);a=p.parse_args();normalize(a.parts)
