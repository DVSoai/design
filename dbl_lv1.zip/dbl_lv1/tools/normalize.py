#!/usr/bin/env python3
"""Remove matte if present, register fixed anchors, quantize semantic skin masks."""
from pathlib import Path
import json, copy, xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
from draw_parts import ROOT, render, SKIN

def remove_background(im):
    """Only flood transparent/corner-connected flat matte; never remove white eyes."""
    a=np.array(im.convert('RGBA'))
    if a[:,:,3].min()==0:return Image.fromarray(a)
    corner=a[0,0,:3].astype(int)
    match=(np.abs(a[:,:,:3].astype(int)-corner).max(axis=2)<8)
    seen=np.zeros(match.shape,bool); stack=[(0,0),(a.shape[1]-1,0),(0,a.shape[0]-1),(a.shape[1]-1,a.shape[0]-1)]
    while stack:
        x,y=stack.pop()
        if not(0<=x<a.shape[1] and 0<=y<a.shape[0]) or seen[y,x] or not match[y,x]:continue
        seen[y,x]=True;stack.extend([(x+1,y),(x-1,y),(x,y+1),(x,y-1)])
    a[seen,3]=0
    return Image.fromarray(a)

def skin_mask(src,dst):
    tree=ET.parse(src)
    for e in tree.iter():
        if e.tag.rsplit('}',1)[-1] in ['path','ellipse','circle','rect','polygon']:
            is_skin=e.attrib.get('data-skin')=='true'
            if e.attrib.get('fill','none')!='none':e.set('fill','#FFFFFF' if is_skin else '#000000')
            if e.attrib.get('stroke','none')!='none':e.set('stroke','#FFFFFF' if is_skin and e.attrib.get('fill')=='none' else '#000000')
    f=dst.with_suffix('.svg');tree.write(f,encoding='unicode');render(f,dst);f.unlink()

def quantize_skin(im,mask):
    a=np.array(im);m=np.array(mask.convert('L'))>127
    palette=np.array([[int(c[i:i+2],16) for i in [1,3,5]] for c in SKIN],dtype=np.int32)
    m &= a[:,:,3]>0
    pixels=a[:,:,:3][m].astype(np.int32)
    if len(pixels):a[:,:,:3][m]=palette[((pixels[:,None,:]-palette[None,:,:])**2).sum(2).argmin(1)]
    # Transparent pixels never retain matte RGB.
    a[a[:,:,3]==0,:3]=0
    return Image.fromarray(a),int(m.sum())

def main():
    meta=json.loads((ROOT/'tools/drawing_meta.json').read_text());result={'version':1,'canvas':{'256':[256,256],'128':[128,128]},'skin_palette':SKIN,'parts':{}}
    for d in ['parts/256','parts/128','parts/masks']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    total=0
    for key,m in meta.items():
        stem=f'{int(key):02}' if key.isdigit() else key
        src=ROOT/f'parts/svg/{stem}.svg'; raw=ROOT/f'parts/raw/{stem}.png'
        mask_path=ROOT/f'parts/masks/{stem}.png';skin_mask(src,mask_path)
        im=remove_background(Image.open(raw)).resize((256,256),Image.Resampling.LANCZOS)
        mask=Image.open(mask_path).resize((256,256),Image.Resampling.LANCZOS)
        im,n=quantize_skin(im,mask);total+=n
        # All input vectors are authored on a canonical canvas. A translated input
        # may declare its anchor in drawing_meta and is registered here.
        target={'head':{'chin':[128,112]},'torso':{'neck':[128,64],'hip':[128,131]},'legs':{'hip':[128,80]},'roll':{'center':[128,128]}}.get(m['kind'],{})
        base_anchor=next(iter(target),None)
        if base_anchor:
            old=m['anchors'][base_anchor];new=target[base_anchor];dx,dy=round(new[0]-old[0]),round(new[1]-old[1])
        else:dx=dy=0
        shifted=Image.new('RGBA',(256,256));shifted.alpha_composite(im,(dx,dy));im=shifted
        mask256=Image.new('L',(256,256));mask256.paste(mask.convert('L'),(dx,dy));mask256.save(mask_path)
        im.save(ROOT/f'parts/256/{stem}.png')
        small=im.resize((128,128),Image.Resampling.LANCZOS);sm=mask256.resize((128,128),Image.Resampling.LANCZOS)
        small,_=quantize_skin(small,sm);small.save(ROOT/f'parts/128/{stem}.png')
        bbox=list(im.getbbox())
        anchors=copy.deepcopy(m['anchors'])
        for k,v in anchors.items():
            if isinstance(v,list) and len(v)==2 and isinstance(v[0],(int,float)):anchors[k]=[v[0]+dx,v[1]+dy]
        def half(value):
            return [half(v) for v in value] if isinstance(value,list) else round(value/2,3)
        anchors128={k:(half(v) if isinstance(v,list) or k in ['tunic_height','length','height'] else v) for k,v in anchors.items()}
        result['parts'][key]={**m,'anchors':anchors,'anchors_128':anchors128,'bbox_256':bbox,'registration_delta':[dx,dy],'skin_pixels':n,'files':{'256':f'256/{stem}.png','128':f'128/{stem}.png','svg':f'svg/{stem}.svg'}}
    for i in [32,5,23]:
        for size in [256,128]:
            stem=f'{i:02}';Image.open(ROOT/f'parts/{size}/{stem}.png').save(ROOT/f'0_mau/{stem}_{size}.png')
        (ROOT/f'0_mau/{i:02}.svg').write_text((ROOT/f'parts/svg/{i:02}.svg').read_text())
    (ROOT/'parts/parts.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(f'NORMALIZE: {len(meta)} parts, transparent RGBA, each 256×256 and 128×128.')
    print(f'Skin semantic pixels at 256px: {total}; palette: '+', '.join(SKIN))
    print('Fixed anchors: head chin=(128,112); torso neck=(128,64), hip=(128,131); legs hip=(128,80).')
    print('Tunic neck-to-hem: 82 source pixels; head crown-to-chin: 106 pixels; ratio=1.29268.')
    print('Skin interiors quantized after each resize; antialiased outlines remain smooth.')
    print('Master exports saved in 0_mau; anchors and per-part metadata saved in parts/parts.json.')

if __name__=='__main__':main()
