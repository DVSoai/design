#!/usr/bin/env python3
"""Raster-only cleanup, scale and anchor registration; never draws anatomy."""
from pathlib import Path
import argparse
import json
import numpy as np
from PIL import Image,ImageFilter

ROOT=Path(__file__).resolve().parents[1]
PALETTE=np.array([[242,201,143],[217,160,102],[251,227,184]],dtype=np.int32)

def clean(im):
    a=np.array(im.convert('RGBA'))
    green=(a[:,:,1]>120)&(a[:,:,1].astype(float)>a[:,:,0].astype(float)*1.35)&(a[:,:,1].astype(float)>a[:,:,2].astype(float)*1.35)
    if green[0,0] or green[-1,-1] or green.mean()>.25:
        a[green]=0
    # Generated background is truly alpha-matted; remove residual near-zero alpha.
    a[a[:,:,3]<18]=0
    a[:,:,3]=np.where(a[:,:,3]>245,255,a[:,:,3])
    im=Image.fromarray(a);bbox=im.getbbox()
    if bbox is None:raise ValueError('Empty generated sprite')
    return im.crop(bbox)

def skin_mask(im,kind):
    a=np.asarray(im).astype(np.int32);r,g,b=a[:,:,0],a[:,:,1],a[:,:,2]
    m=(r>175)&(g>90)&((r-g)>28)&(g>r*.47)&(b<g*.91)&(a[:,:,3]>200)
    # Red ribbon, cream trim and dark cloth remain outside this color family.
    if kind=='legs':m[:]=False
    return Image.fromarray((m.astype(np.uint8)*255),'L')

def quantize(im,mask):
    a=np.array(im);m=np.asarray(mask)>127;m &= a[:,:,3]>0
    smooth=np.asarray(im.filter(ImageFilter.MedianFilter(3)))
    p=smooth[:,:,:3][m].astype(np.int32)
    if len(p):a[:,:,:3][m]=PALETTE[((p[:,None,:]-PALETTE[None,:,:])**2).sum(2).argmin(1)]
    a[a[:,:,3]==0,:3]=0
    return Image.fromarray(a)

def anchor_from_fraction(uv,size):return [uv[0]*size[0],uv[1]*size[1]]

def snap_hand(im,uv):
    """Locate an existing isolated skin island near an annotated fist/palm."""
    ratio=min(1,320/max(im.size));m=skin_mask(im,'torso').resize((max(1,round(im.width*ratio)),max(1,round(im.height*ratio))),Image.Resampling.NEAREST)
    a=np.asarray(m)>127;seen=np.zeros(a.shape,bool);target=[uv[0]*a.shape[1],uv[1]*a.shape[0]];candidates=[]
    for yy,xx in zip(*np.where(a)):
        if seen[yy,xx]:continue
        stack=[(int(xx),int(yy))];seen[yy,xx]=True;points=[]
        while stack:
            x,y=stack.pop();points.append((x,y))
            for nx,ny in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
                if 0<=nx<a.shape[1] and 0<=ny<a.shape[0] and a[ny,nx] and not seen[ny,nx]:seen[ny,nx]=True;stack.append((nx,ny))
        if len(points)<12 or len(points)>a.size*.08:continue
        p=np.array(points);lo=p.min(0);hi=p.max(0);center=(lo+hi)/2
        if max(hi-lo)>max(a.shape)*.36:continue
        distance=float(np.linalg.norm(center-target))
        candidates.append((distance,center))
    if not candidates:return anchor_from_fraction(uv,im.size)
    distance,center=min(candidates,key=lambda x:x[0])
    if distance>max(a.shape)*.18:return anchor_from_fraction(uv,im.size)
    return [float(center[0]/a.shape[1]*im.width),float(center[1]/a.shape[0]*im.height)]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--parts',nargs='*');args=parser.parse_args()
    annotations=json.loads((ROOT/'tools/annotations.json').read_text());calls=json.loads((ROOT/'tools/image_calls.json').read_text())
    result=json.loads((ROOT/'parts/parts.json').read_text()) if args.parts else {'skin_palette':['#F2C98F','#D9A066','#FBE3B8'],'canvas_256':[256,256],'canvas_128':[128,128],'parts':{}}
    for d in ['parts/256','parts/128','parts/masks']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    for key,ann in annotations.items():
        if args.parts and key not in args.parts:continue
        stem=f'{int(key):02}';kind=ann['kind'];im=clean(Image.open(ROOT/f'parts/raw/{stem}.png'));w,h=im.size
        if kind=='head':
            scale=114/h;reference=anchor_from_fraction(ann.get('chin',[.60,.94]),(w,h));target=[128,116]
            anchors={'chin':target,'neck_base':[128+(ann.get('neck_base',[.60,1])[0]*w-reference[0])*scale,116+(ann.get('neck_base',[.60,1])[1]*h-reference[1])*scale]}
        elif kind=='torso':
            reference=anchor_from_fraction(ann['neck'],(w,h));hem=anchor_from_fraction(ann['hem'],(w,h));shirt_length=((hem[0]-reference[0])**2+(hem[1]-reference[1])**2)**.5
            scale=82/shirt_length;target=[128,104]
            anchors={'neck':target,'hip':[128,170],'tunic_height':82}
            for field in ['hand','back_hand']:
                point=snap_hand(im,ann[field]);anchors[field]=[target[j]+(point[j]-reference[j])*scale for j in range(2)]
        elif kind=='legs':
            reference=anchor_from_fraction(ann.get('hip',[.5,.02]),(w,h));scale=ann.get('scale_length',83)/h;target=[128,70];anchors={'hip':target,'feet_count':2}
            anchors['feet']=[[target[j]+(p[j]*(w,h)[j]-reference[j])*scale for j in range(2)] for p in ann['feet']]
        else:
            scale=224/max(w,h);reference=[w/2,h/2];target=[128,128]
            anchors={'center':target,'feet_count':2,'independently_generated':True}
        size=[max(1,round(w*scale)),max(1,round(h*scale))];sprite=im.resize(size,Image.Resampling.LANCZOS)
        mask=skin_mask(im,kind).resize(size,Image.Resampling.LANCZOS).point(lambda v:255 if v>127 else 0)
        mask=mask.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MedianFilter(3));sprite=quantize(sprite,mask)
        offset=[round(target[j]-reference[j]*scale) for j in range(2)]
        if offset[0]<0 or offset[1]<0 or offset[0]+size[0]>256 or offset[1]+size[1]>256:raise ValueError(f'Part {key} clips canonical canvas: {offset}, {size}; adjust registration, never synthesize anatomy.')
        canvas=Image.new('RGBA',(256,256));canvas.alpha_composite(sprite,tuple(offset));mask_canvas=Image.new('L',(256,256));mask_canvas.paste(mask,tuple(offset))
        canvas.save(ROOT/f'parts/256/{stem}.png');mask_canvas.save(ROOT/f'parts/masks/{stem}.png')
        small=canvas.resize((128,128),Image.Resampling.LANCZOS);smallmask=mask_canvas.resize((128,128),Image.Resampling.NEAREST);small=quantize(small,smallmask);small.save(ROOT/f'parts/128/{stem}.png')
        def half(v):return [half(x) for x in v] if isinstance(v,list) else v/2
        anchors128={k:(half(v) if isinstance(v,list) or k=='tunic_height' else v) for k,v in anchors.items()}
        result['parts'][key]={'kind':kind,'image_tool_calls':calls[key]['image_tool_calls'],'anchors':anchors,'anchors_128':anchors128,'scale':scale,'offset':offset,'raw_crop_size':[w,h],'bbox':list(canvas.getbbox()),'files':{'256':f'256/{stem}.png','128':f'128/{stem}.png'}}
        if key in ['32','5','23']:
            canvas.save(ROOT/f'0_mau/{stem}_256.png');small.save(ROOT/f'0_mau/{stem}_128.png')
    (ROOT/'parts/parts.json').write_text(json.dumps(result,indent=2))
    print(f'NORMALIZE: {args.parts or "all"}; {len(result["parts"])} total character records; 256/128px transparent raster exports.')
    print('Only alpha cleanup, uniform resampling, color quantization, and anchor translation used; no character geometry drawn.')
    print('Fixed anchors: chin=(128,116); neck=(128,104); torso hip=(128,170); leg hip=(128,70).')
    print('Torso neck-to-hem length standardized to 82px; 3-color skin masks saved; weapons handled separately.')
    # Thickness is a readiness gate for measurable biceps; visible skin area
    # is reported per pose according to the user's revised measurement rule.
    import arm_metrics
    arm_metrics.main()

if __name__=='__main__':main()
