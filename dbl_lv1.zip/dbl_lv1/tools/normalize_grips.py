#!/usr/bin/env python3
"""Register image-generated hand layers; all character pixels come from rasters."""
from pathlib import Path
import json,math
import numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageOps
from normalize import ROOT,clean,skin_mask,quantize

def markers(im):
    a=np.asarray(im);r,g,b=[a[:,:,i].astype(float) for i in range(3)]
    masks={'neck':(r>180)&(g<80)&(b<100),'hem':(r>170)&(b>170)&(g<100),'grip':(b>150)&(r<100)&(b>g*1.2)}
    centers={}
    for k,m in masks.items():
        y,x=np.where(m)
        if len(x)<20:raise ValueError(f'Missing generated {k} marker')
        centers[k]=np.array([x.mean(),y.mean()])
    p=np.column_stack(np.where(masks['grip'])[::-1]);c=p.mean(0);_,v=np.linalg.eigh(np.cov(p.T));axis=v[:,-1];normal=np.array([-axis[1],axis[0]]);t=(p-c)@axis;lo=math.floor(t.min());hi=math.ceil(t.max());hist=np.bincount(np.clip(np.rint(t-lo).astype(int),0,hi-lo),minlength=hi-lo+1);zero=hist==0;gaps=[];start=None
    for i,z in enumerate(zero):
        if z and start is None:start=i
        if start is not None and (not z or i==len(zero)-1):
            end=i if not z else i+1
            if start>len(zero)*.1 and end<len(zero)*.9:gaps.append((end-start,(start+end-1)/2+lo))
            start=None
    mid=max(gaps,key=lambda x:x[0])[1] if gaps else (t.min()+t.max())/2
    centers['grip']=c+axis*mid+normal*np.median((p-c)@normal)
    blue_y,blue_x=np.where(masks['grip']);pgrid_y,pgrid_x=np.mgrid[0:im.height,0:im.width];proj=(pgrid_x-c[0])*axis[0]+(pgrid_y-c[1])*axis[1];perp=(pgrid_x-c[0])*normal[0]+(pgrid_y-c[1])*normal[1];span=max(hi-lo,1);band=max(4,float(np.quantile(abs((p-c)@normal),.99))+4)
    masks['handle_caps']=((proj>=lo-span*.22)&(proj<lo-1)|(proj>hi+1)&(proj<=hi+span*.22))&(abs(perp)<band)
    return centers,masks

def remap(im,x,y):
    a=np.asarray(im).astype(float)/255;alpha=a[:,:,3:4];a[:,:,:3]*=alpha;out=np.zeros((256,256,4));x0=np.floor(x).astype(int);y0=np.floor(y).astype(int);fx=x-x0;fy=y-y0
    for dx,dy,w in [(0,0,(1-fx)*(1-fy)),(1,0,fx*(1-fy)),(0,1,(1-fx)*fy),(1,1,fx*fy)]:
        xx=x0+dx;yy=y0+dy;ok=(xx>=0)&(xx<256)&(yy>=0)&(yy<256);out[ok]+=a[yy[ok],xx[ok]]*w[ok,None]
    out[:,:,:3]=np.divide(out[:,:,:3],out[:,:,3:4],out=np.zeros_like(out[:,:,:3]),where=out[:,:,3:4]>1e-8)
    return Image.fromarray(np.clip(out*255,0,255).astype(np.uint8))

def register(im,config):
    points,masks=markers(im);v=points['hem']-points['neck'];scale=82/np.linalg.norm(v);theta=math.pi/2-math.atan2(v[1],v[0]);A=scale*np.array([[math.cos(theta),-math.sin(theta)],[math.sin(theta),math.cos(theta)]]);offset=np.array([128,104])-A@points['neck'];M=np.eye(3);M[:2,:2]=A;M[:2,2]=offset;inv=np.linalg.inv(M)
    a=np.array(im.convert('RGBA'));r,g,b=[a[:,:,i].astype(float) for i in range(3)];green=(g>120)&(g>r*1.35)&(g>b*1.35);remove=green|masks['neck']|masks['hem']|masks['grip']|masks['handle_caps'];remove=Image.fromarray((remove*255).astype(np.uint8)).filter(ImageFilter.MaxFilter(3));a[np.asarray(remove)>127]=0;im=Image.fromarray(a)
    uniform=im.transform((256,256),Image.Transform.AFFINE,tuple(inv[:2,:].ravel()),Image.Resampling.BICUBIC)
    current=A@points['grip']+offset;target=np.array(config['target_grip']);side='left' if target[0]<128 else 'right';mirrored=(current[0]<128)!=(target[0]<128)
    if mirrored:
        reflected=ImageOps.mirror(uniform);shifted=Image.new('RGBA',(256,256));shifted.alpha_composite(reflected,(1,0));uniform=shifted;current[0]=256-current[0]
    delta=target-current;sigma=max(18,float(np.linalg.norm(delta)))
    y,x=np.mgrid[0:256,0:256];distance=(x-target[0])**2+(y-target[1])**2;weight=np.exp(-distance/(2*sigma*sigma))
    warped=remap(uniform,x-weight*delta[0],y-weight*delta[1]);m=skin_mask(warped,'torso');warped=quantize(warped,m)
    # At the grip, weight=1 and its derivative=0: exact placement without
    # squeezing fingers. sigma>=|delta| bounds the inverse-map Jacobian away
    # from zero, including fist poses that lie very close to the shoulder.
    return warped,side,{'scale':float(scale),'initial_grip':current.tolist(),'target_grip':target.tolist(),'grip_displacement':delta.tolist(),'candidate_mirrored':bool(mirrored),'gaussian_sigma':sigma,'inverse_jacobian_lower_bound':1-math.exp(-.5)*float(np.linalg.norm(delta))/sigma,'grip_registration_error_px':0,'registration':'Neck/hem similarity plus smooth non-folding raster grip registration; original character parts are not transformed.'}

def make_layer(key,cfg,parts):
    candidate=Image.open(ROOT/f'parts/grips/raw/{key}.png').convert('RGBA');registered,side,meta=register(candidate,cfg);original=Image.open(ROOT/f'parts/256/{int(cfg["torso"]):02}.png').convert('RGBA');anchors=parts[cfg['torso']]['anchors'];oldhand=anchors['back_hand' if side=='left' else 'hand'];target=cfg['target_grip']
    roi=Image.new('L',(256,256));d=ImageDraw.Draw(roi)
    if side=='right':box=(min(137,target[0]-22,oldhand[0]-20),min(96,target[1]-22,oldhand[1]-20),255,max(195,target[1]+23,oldhand[1]+20))
    else:box=(0,min(96,target[1]-22,oldhand[1]-20),max(119,target[0]+22,oldhand[0]+20),max(195,target[1]+23,oldhand[1]+20))
    d.rectangle(box,fill=255)
    cloth=Image.new('L',(256,256));ImageDraw.Draw(cloth).polygon([(110,107),(145,108),(148,132),(144,153),(157,187),(99,188),(109,152),(108,130)],fill=255)
    old_disk=Image.new('L',(256,256));ImageDraw.Draw(old_disk).ellipse((oldhand[0]-17,oldhand[1]-17,oldhand[0]+17,oldhand[1]+17),fill=255)
    rr=np.asarray(roi)>127;keep=np.asarray(cloth)>127;replace=rr&(~keep|(np.asarray(old_disk)>127));edited=original.copy();edited.paste(registered,(0,0),Image.fromarray((replace*255).astype(np.uint8)))
    newskin=skin_mask(registered,'torso').filter(ImageFilter.MaxFilter(5));fist=Image.new('L',(256,256));ImageDraw.Draw(fist).ellipse((target[0]-20,target[1]-20,target[0]+20,target[1]+20),fill=255)
    addmask=rr&((np.asarray(newskin)>127)|(np.asarray(fist)>127));overlay=registered.copy();alpha=np.asarray(overlay.getchannel('A')).copy();alpha[~addmask]=0;overlay.putalpha(Image.fromarray(alpha));edited.alpha_composite(overlay)
    # Restore marker locations from untouched original cloth/neck pixels.
    for center in [[128,104],[128,186]]:
        patch=Image.new('L',(256,256));ImageDraw.Draw(patch).ellipse((center[0]-4,center[1]-4,center[0]+4,center[1]+4),fill=255);edited.paste(original,(0,0),patch)
    fingers=registered.copy();alpha=np.asarray(fingers.getchannel('A')).copy();y,x=np.mgrid[0:256,0:256];disk=((x-target[0])**2+(y-target[1])**2)<=11**2;alpha[~disk]=0;fingers.putalpha(Image.fromarray(alpha))
    angle=math.radians(json.loads((ROOT/'parts/weapons/weapons.json').read_text())[cfg['kind']]['axis_angle_deg']);normal=np.array([-math.sin(angle),math.cos(angle)]);a=np.asarray(fingers);coverage=[]
    for sign in [-1,1]:
        hits=[]
        for radius in np.arange(2,10,.5):
            xx,yy=np.rint(np.array(target)+normal*sign*radius).astype(int)
            if 0<=xx<256 and 0<=yy<256:hits.append(a[yy,xx,3]>150)
        coverage.append(bool(any(hits)))
    wrap=all(coverage);meta.update(key=key,torso=cfg['torso'],side=side,fingers_wrap=wrap,coverage_sides=coverage,image_tool_calls=json.loads((ROOT/f'tools/logs/grip_{key}_calls.json').read_text())['image_tool_calls'])
    edited.save(ROOT/f'parts/grips/256/{key}.png');edited.resize((128,128),Image.Resampling.LANCZOS).save(ROOT/f'parts/grips/128/{key}.png');fingers.save(ROOT/f'parts/grips/fingers/{key}.png');(ROOT/f'parts/grips/{key}.json').write_text(json.dumps(meta,indent=2));return meta

def main():
    for d in ['parts/grips/256','parts/grips/128','parts/grips/fingers']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    cfg=json.loads((ROOT/'tools/grip_config.json').read_text());parts=json.loads((ROOT/'parts/parts.json').read_text())['parts'];results=[]
    for key,c in cfg.items():
        m=make_layer(key,c,parts);results.append(m);print(f'GRIP {key}: side={m["side"]}; fingers_wrap={m["fingers_wrap"]}; raster_displacement={m["grip_displacement"]}; image_calls={m["image_tool_calls"]}')
    (ROOT/'tools/grip_registration.json').write_text(json.dumps(results,indent=2));print('GRIP LAYERS: original unarmed character pieces left unchanged; frame 01 reuses frame 00 relative pose. Colored markers removed.')

if __name__=='__main__':main()
