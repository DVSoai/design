#!/usr/bin/env python3
"""Package only this original asset folder; omit disposable renders and caches."""
from pathlib import Path
import zipfile,json
ROOT=Path(__file__).resolve().parents[1]

def main():
    validation=json.loads((ROOT/'tools/validation.json').read_text())
    if validation['failures']:raise SystemExit('Refuse to package failed validation.')
    output=ROOT.parent/'dbl_lv1.zip'
    files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and 'parts/raw' not in p.relative_to(ROOT).as_posix() and '__pycache__' not in p.parts and p.suffix!='.pyc']
    if any(p.is_symlink() for p in files):raise SystemExit('Unexpected symlink in package.')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in files:archive.write(p,Path('dbl_lv1')/p.relative_to(ROOT))
    with zipfile.ZipFile(output) as archive:
        bad=archive.testzip()
        if bad:raise SystemExit(f'ZIP CRC failure: {bad}')
        names=archive.namelist()
        for item in ['REPORT.md','sheet_30_khung.png','anim_chay.gif','anim_nhay.gif','parts/parts.json','tools/normalize.py','tools/assemble.py']:
            if 'dbl_lv1/'+item not in names:raise SystemExit('Missing required file: '+item)
        frames=[n for n in names if '/frames/' in n and n.endswith('.png')]
        if len(frames)!=360:raise SystemExit('Wrong frame count in ZIP.')
    print(f'PACKAGE: {len(files)} files; {len(frames)} frame PNGs; ZIP CRC PASS; required paths PASS.')

if __name__=='__main__':main()
