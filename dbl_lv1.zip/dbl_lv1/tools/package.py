#!/usr/bin/env python3
"""Package new original artwork only, after successful validation."""
from pathlib import Path
import json,zipfile
ROOT=Path(__file__).resolve().parents[1]
def main():
 v=json.loads((ROOT/'tools/validation.json').read_text())
 if v['failures']:raise SystemExit('Refuse to package failed validation')
 files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'];out=ROOT.parent/'dbl_lv1.zip'
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in files:z.write(p,Path('dbl_lv1')/p.relative_to(ROOT))
 with zipfile.ZipFile(out) as z:
  if z.testzip():raise SystemExit('ZIP CRC failure')
  names=z.namelist();frames=[n for n in names if '/frames/' in n and n.endswith('.png')]
  if len(frames)!=360:raise SystemExit('Wrong PNG frame count')
  for p in ['REPORT.md','preview/ty_le_goc.png','preview/parts_33.png','preview/tay_dong_bo.png','preview/vu_khi_zoom.png','parts/native/32.png','parts/native/262.png','parts/native/283.png']:
   if 'dbl_lv1/'+p not in names:raise SystemExit('Missing '+p)
 print(f'PACKAGE: {len(files)} files; 360 frame PNGs; 32 newly generated character sources + 1 empty rig slot; native/256/128 parts; ZIP CRC PASS.')
 print('Only own original character/weapon artwork included; all external pose comparison pictures remain outside the package.')
if __name__=='__main__':main()
