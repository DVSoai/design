#!/usr/bin/env python3
"""Archive verified raster artwork and its processing tools."""
from pathlib import Path
import zipfile,json
ROOT=Path(__file__).resolve().parents[1]

def main():
    v=json.loads((ROOT/'tools/validation.json').read_text())
    if v['failures']:raise SystemExit('Refuse to package failed validation')
    files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
    if any(p.is_symlink() for p in files):raise SystemExit('Unexpected symlink')
    output=ROOT.parent/'dbl_lv1.zip'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:z.write(p,Path('dbl_lv1')/p.relative_to(ROOT))
    with zipfile.ZipFile(output) as z:
        if z.testzip() is not None:raise SystemExit('ZIP CRC failure')
        names=z.namelist();frames=[n for n in names if '/frames/' in n and n.endswith('.png')]
        if len(frames)!=360:raise SystemExit('Wrong frame count')
        svgs=[n for n in names if n.endswith('.svg')]
        if len(svgs)!=2 or any('/parts/weapons/' not in n for n in svgs):raise SystemExit('Non-weapon SVG in package')
        for f in ['REPORT.md','parts/parts.json','tools/image_calls.json','sheet_30_khung.png','anim_chay.gif','anim_nhay.gif','preview/tay_dong_bo.png','preview/vu_khi_zoom.png']:
            if 'dbl_lv1/'+f not in names:raise SystemExit('Missing '+f)
    print(f'PACKAGE: {len(files)} files; 360 frame PNGs; 33 main character rasters; 18 image-generated grip sources; 2 weapon SVGs; ZIP CRC PASS.')
    print('Reference-image comparison boards excluded. One occluded biceps midpoint (torso 16) remains explicitly N/A in the report.')

if __name__=='__main__':main()
