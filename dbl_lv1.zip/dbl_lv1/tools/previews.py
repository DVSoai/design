#!/usr/bin/env python3
"""Own-art preview boards at shared scales; numeric geometry labels only."""
import json
from PIL import Image,ImageDraw,ImageFont
from normalize import ROOT
from assemble import build

def font(n):return ImageFont.truetype('DejaVuSans.ttf',n)
def main():
 meta=json.loads((ROOT/'parts/parts.json').read_text());ids=sorted(map(int,meta['parts']));cell=270;sheet=Image.new('RGB',(6*cell,6*cell),'#E9E1D1');d=ImageDraw.Draw(sheet)
 for i,k in enumerate(ids):
  im=Image.open(ROOT/f'parts/native/{k:02}.png').convert('RGBA');im=im.resize((im.width*2,im.height*2),Image.Resampling.LANCZOS);x=i%6*cell;y=i//6*cell;sheet.paste(im,(x+(cell-im.width)//2,y+12),im);g=meta['parts'][str(k)];d.text((x+8,y+240),f'{k:02} | {g["canvas_native"][0]}x{g["canvas_native"][1]} native',font=font(15),fill='#302724')
 sheet.save(ROOT/'preview/parts_33.png')
 torso=list(range(5,13))+list(range(14,22));sheet=Image.new('RGB',(1200,1000),'#E9E1D1');d=ImageDraw.Draw(sheet)
 for i,k in enumerate(torso):
  im=Image.open(ROOT/f'parts/native/{k:02}.png').convert('RGBA');im=im.resize((im.width*2,im.height*2),Image.Resampling.LANCZOS);x=i%4*300;y=i//4*250;sheet.paste(im,(x+(300-im.width)//2,y+20),im);g=meta['parts'][str(k)];d.text((x+12,y+170),f'THAN {k:02}: {g["canvas_native"][0]}x{g["canvas_native"][1]} px',font=font(17),fill='#302724');d.text((x+12,y+198),'Cung ti le 2x | khong ep co ao',font=font(14),fill='#302724')
 sheet.save(ROOT/'preview/tay_dong_bo.png')
 selected=[0,3,7,12,21];records=json.loads((ROOT/'frames/assembly.json').read_text())['frames'];b=[v['bbox'] for v in records if v['output_size']==256 and v['frame'] in selected];box=[min(t[0] for t in b)-8,min(t[1] for t in b)-8,max(t[2] for t in b)+8,max(t[3] for t in b)+8];w=(box[2]-box[0])*2;h=(box[3]-box[1])*2;sheet=Image.new('RGB',(w*5,(h+40)*2),'#E9E1D1');d=ImageDraw.Draw(sheet)
 for row,v in enumerate(['kiem','cung']):
  for col,n in enumerate(selected):
   im=Image.open(ROOT/f'frames/256/{v}/phai/{n:02}.png').crop(box).resize((w,h),Image.Resampling.NEAREST);x=col*w;y=row*(h+40);sheet.paste(im,(x,y+40),im);d.text((x+10,y+8),f'{v.upper()} {n:02} | 2x',font=font(20),fill='#302724')
 sheet.save(ROOT/'preview/vu_khi_zoom.png')
 # Geometry proof board uses ONLY the new artwork and numeric reference sizes.
 images={k:Image.open(ROOT/'parts'/v['files']['native']).convert('RGBA') for k,v in meta['parts'].items()};data=json.loads((ROOT/'tools/pose_data.json').read_text());im,r=build(0,'tay_khong',1,320,data,images);crop=im.crop(im.getbbox());sheet=Image.new('RGB',(1050,650),'#E9E1D1');d=ImageDraw.Draw(sheet);large=crop.resize((crop.width*4,crop.height*4),Image.Resampling.NEAREST);sheet.paste(large,(20,65),large)
 for i,t in enumerate(['DINH BO LINH - TY LE RIG GOC','Dau: 83 x 76 px','Than gom tay: 82 x 43 px','Chan: 58 x 31 px','Toan nguoi: 87 x 131 px','Dau / toan nguoi: 58.02%','Dau / than: 1.767 lan (khung bao)','Chong dau-than: 8 px; than-chan: 11 px','Cac manh dung nguyen toa do bang khung','Xuat 256/128 bang cung mot he so','Khong them tay; khong dich khop de bu.']):d.text((430,35+i*47),t,font=font(20),fill='#302724')
 sheet.save(ROOT/'preview/ty_le_goc.png')
 # Keep familiar preview filenames while replacing every depicted character.
 roll=Image.new('RGB',(1080,300),'#E9E1D1');dr=ImageDraw.Draw(roll)
 for i,k in enumerate([1,2,3,4]):
  im=Image.open(ROOT/f'parts/native/{k:02}.png').convert('RGBA');im=im.resize((im.width*2,im.height*2),Image.Resampling.LANCZOS);roll.paste(im,(i*270+20,30),im);dr.text((i*270+12,7),f'LO N {k:02} / FRAME {k+7:02}',font=font(17),fill='#302724')
 roll.save(ROOT/'preview/lon_4.png')
 samples=Image.new('RGB',(1500,650),'#E9E1D1');ds=ImageDraw.Draw(samples)
 for i,k in enumerate([32,5,23]):
  im=Image.open(ROOT/f'parts/native/{k:02}.png').convert('RGBA');im=im.resize((im.width*4,im.height*4),Image.Resampling.LANCZOS);samples.paste(im,(i*360+15,70),im);ds.text((i*360+15,25),f'MAU MOI {k:02}',font=font(22),fill='#302724')
 stand=Image.open(ROOT/'0_mau/dung_256.png').convert('RGBA');stand=stand.resize((stand.width*2,stand.height*2),Image.Resampling.LANCZOS);samples.paste(stand,(1110,70),stand);ds.text((1110,25),'GHEP DUNG 00',font=font(22),fill='#302724');samples.save(ROOT/'preview/mau_da_duyet.png')
 print('PREVIEWS: 33 slots at shared 2x native scale; all 16 torsos; 10 weapon zoom panels at 2x; original-rig proportions illustrated with own artwork only; four-roll and fresh-master previews also replaced.')
if __name__=='__main__':main()
