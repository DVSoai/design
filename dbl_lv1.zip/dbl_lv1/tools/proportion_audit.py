#!/usr/bin/env python3
"""Measure the direct-replacement rig from numeric rectangles, not reference pixels."""
import json,math
from PIL import Image
from normalize import ROOT
from assemble import build

def main():
 g=json.loads((ROOT/'tools/geometry.json').read_text());data=json.loads((ROOT/'tools/pose_data.json').read_text());meta=json.loads((ROOT/'parts/parts.json').read_text());images={k:Image.open(ROOT/'parts'/v['files']['native']).convert('RGBA') for k,v in meta['parts'].items()};rows=[];fail=[]
 for n in range(30):
  im,record=build(n,'tay_khong',1,320,data,images);boxes=[]
  for key,m in record['origins'].items():
   b=g[key]['bbox'];xy=m['raster_position'];boxes.append([xy[0]+b[0],xy[1]+b[1],xy[0]+b[2],xy[1]+b[3]])
  expected=[min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes)];actual=list(im.getbbox());delta=[actual[j]-expected[j] for j in range(4)]
  row={'frame':n,'native_expected_bbox':expected,'native_actual_bbox':actual,'native_bbox_edge_delta':delta,'native_size':[actual[2]-actual[0],actual[3]-actual[1]],'rig_position_corrections':0};rows.append(row)
  if max(abs(v) for v in delta)>1:fail.append(f'Frame {n}: native bounds differ by >1 pixel')
 standing=rows[0];head_h=g['32']['bbox'][3]-g['32']['bbox'][1];torso_h=g['5']['bbox'][3]-g['5']['bbox'][1]
 result={'standing_native_size':standing['native_size'],'head_height_native':head_h,'torso_with_arms_height_native':torso_h,'head_whole_height_ratio':head_h/standing['native_size'][1],'head_torso_bbox_ratio':head_h/torso_h,'head_torso_overlap_native':8,'torso_legs_overlap_native':11,'rows':rows,'failures':fail}
 (ROOT/'tools/proportion_audit.json').write_text(json.dumps(result,indent=2))
 print(f'PROPORTIONS: standing native={standing["native_size"]}; head=83x76; torso including arms=82x43; legs=58x31.')
 print(f'Head/whole height={result["head_whole_height_ratio"]:.6f}; head/torso bbox height={result["head_torso_bbox_ratio"]:.6f}; overlaps=8/11 native px.')
 print('frame | native width x height | bbox-edge deviation [L,T,R,B]')
 for row in rows:print(f'{row["frame"]:02} | {row["native_size"]} | {row["native_bbox_edge_delta"]}')
 print('PROPORTION FAILURES: '+str(len(fail)))
 if fail:raise SystemExit('\n'.join(fail))
if __name__=='__main__':main()
