#!/usr/bin/env python3
"""Shared-scale audit sheets containing only original output artwork."""
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
def font(n):return ImageFont.truetype('DejaVuSans.ttf',n)
def main():
 rows=json.loads((ROOT/'tools/arm_metrics.json').read_text())['rows'];ids=list(range(5,13))+list(range(14,22));by={r['part']:r for r in rows}
 sheet=Image.new('RGB',(1280,1520),'#EEE6D5');d=ImageDraw.Draw(sheet)
 # Every part is shown at exactly 2x with the SAME crop; no per-part fitting.
 bboxes=[Image.open(ROOT/f'parts/256/{k:02}.png').getbbox() for k in ids]
 box=(min(b[0] for b in bboxes)-6,min(b[1] for b in bboxes)-6,max(b[2] for b in bboxes)+6,max(b[3] for b in bboxes)+6)
 common_size=tuple(round((box[j+2]-box[j])*1.6) for j in range(2))
 for i,k in enumerate(ids):
  x=i%4*320;y=i//4*380
  im=Image.open(ROOT/f'parts/256/{k:02}.png').convert('RGBA').crop(box).resize(common_size,Image.Resampling.LANCZOS);sheet.paste(im,(x+20,y+28),im)
  r=by[k];mean='N/A' if r['mean_upper_arm_px'] is None else f'{r["mean_upper_arm_px"]:.2f}'
  d.text((x+12,y+5),f'THAN {k:02} | chung ti le 1.6x',font=font(15),fill='#302724')
  d.text((x+12,y+285),f'Bap tay TB: {mean} px',font=font(15),fill='#302724')
  d.text((x+12,y+307),'Hai ben: '+' / '.join(f'{a:.2f}' for a in r['upper_arm_widths_px'])+' px',font=font(14),fill='#302724')
  delta='N/A: giua tay bi che' if r['midpoint_occluded'] else f'Lech chuan 8: {r["width_delta_percent"]:+.2f}%'
  d.text((x+12,y+329),delta,font=font(14),fill='#302724');d.text((x+12,y+351),f'Dien tich da: {r["skin_area_px2"]} px2',font=font(14),fill='#302724')
 sheet.save(ROOT/'preview/tay_dong_bo.png')
 # Union crop, shared 2x zoom, with explicit frame numbers and weapon names.
 selected=[0,3,7,12,21];records=json.loads((ROOT/'frames/assembly.json').read_text())['frames'];b=[r['bbox'] for r in records if r['variant'] in ['kiem','cung'] and r['frame'] in selected];crop=(min(v[0] for v in b)-8,min(v[1] for v in b)-8,max(v[2] for v in b)+8,max(v[3] for v in b)+8);w=(crop[2]-crop[0])*2;h=(crop[3]-crop[1])*2
 sheet=Image.new('RGB',(w*5,(h+40)*2),'#EEE6D5');d=ImageDraw.Draw(sheet)
 for row,k in enumerate(['kiem','cung']):
  for col,n in enumerate(selected):
   im=Image.open(ROOT/f'frames/256/{k}/phai/{n:02}.png').convert('RGBA').crop(crop).resize((w,h),Image.Resampling.NEAREST);x=col*w;y=row*(h+40);sheet.paste(im,(x,y+40),im);d.text((x+12,y+8),f'{k.upper()} {n:02} | 2x',font=font(22),fill='#302724')
 sheet.save(ROOT/'preview/vu_khi_zoom.png')
 print('PREVIEW: tay_dong_bo.png = all 16 torsos 5–12,14–21; common crop / 1.6x scale; per-side thickness, mean, delta and skin area.')
 print('PREVIEW: vu_khi_zoom.png = frames 00,03,07,12,21 × sword/bow; common crop / exactly 2x scale.')
if __name__=='__main__':main()
