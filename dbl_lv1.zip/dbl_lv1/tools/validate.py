#!/usr/bin/env python3
"""Validate real pixels and manifest relationships; produce a per-frame checklist."""
import json, math, hashlib
from collections import deque
import numpy as np
from PIL import Image,ImageOps
from draw_parts import ROOT,ARMS,LEGS

def significant_components(im):
    a=np.asarray(im.getchannel('A'))>180;seen=np.zeros(a.shape,bool);sizes=[]
    for y,x in zip(*np.where(a)):
        if seen[y,x]:continue
        q=[(x,y)];seen[y,x]=True;n=0
        while q:
            xx,yy=q.pop();n+=1
            for nx,ny in [(xx-1,yy),(xx+1,yy),(xx,yy-1),(xx,yy+1)]:
                if 0<=nx<a.shape[1] and 0<=ny<a.shape[0] and a[ny,nx] and not seen[ny,nx]:seen[ny,nx]=True;q.append((nx,ny))
        if n>20:sizes.append(n)
    return sorted(sizes,reverse=True)

def main():
    parts=json.loads((ROOT/'parts/parts.json').read_text());assembly=json.loads((ROOT/'frames/assembly.json').read_text());palette={tuple(int(c[i:i+2],16) for i in [1,3,5]) for c in parts['skin_palette']}
    failures=[];skin_count=0
    for key,p in parts['parts'].items():
        stem=f'{int(key):02}' if key.isdigit() else key
        mask=Image.open(ROOT/f'parts/masks/{stem}.png').convert('L')
        for size in [256,128]:
            im=Image.open(ROOT/'parts'/p['files'][str(size)]);a=np.array(im)
            if im.mode!='RGBA' or im.size!=(size,size) or a[:,:,3].min()!=0:failures.append(f'Bad part format/transparency: {stem}/{size}')
            m=np.asarray(mask.resize((size,size),Image.Resampling.LANCZOS))>180;m &= a[:,:,3]>0
            colors={tuple(v) for v in a[:,:,:3][m]};skin_count+=int(m.sum())
            if not colors.issubset(palette):failures.append(f'Skin palette failure: {stem}/{size}: {len(colors-palette)} colors')
    rows=[];component_warnings=[]
    for index in range(30):
        cells=[f for f in assembly['frames'] if f['frame']==index];checks={'neck':True,'size':True,'skin':not any('Skin' in s for s in failures),'feet':True,'arms':True,'grip':True,'bounds':True,'mirror':True}
        for f in cells:
            im=Image.open(ROOT/f'frames/256/{f["variant"]}/phai/{index:02}.png').convert('RGBA')
            left=Image.open(ROOT/f'frames/256/{f["variant"]}/trai/{index:02}.png').convert('RGBA')
            checks['mirror'] &= ImageOps.mirror(im).tobytes()==left.tobytes()
            checks['bounds'] &= not f['clipped']
            checks['size'] &= f['tunic_height']==82
            if len(f['parts'])==3:
                hk,tk,lk=f['parts'];o=f['final_origins'];hp=parts['parts'][hk]['anchors']['chin'];np_=parts['parts'][tk]['anchors']['neck']
                chin=[o['head'][j]+hp[j] for j in range(2)];neck=[o['torso'][j]+np_[j] for j in range(2)]
                checks['neck'] &= abs(chin[0]-neck[0])<.01 and abs(chin[1]-neck[1]-2)<.01
                x,y=map(round,neck);alpha=np.asarray(im.getchannel('A'));checks['neck'] &= bool(np.all(alpha[y-2:y+3,x-2:x+3]>180))
                foot=parts['parts'][lk]['anchors']['feet'];checks['feet'] &= math.dist(foot[0],foot[1])>14
                for fp in foot:
                    x,y=[round(o['legs'][j]+fp[j]) for j in range(2)]
                    checks['feet'] &= bool(np.asarray(im.getchannel('A'))[y-3:y+4,x-3:x+4].max()>200)
                checks['arms'] &= f['arm_pose'] in ARMS and ARMS[f['arm_pose']][1]!=ARMS[f['arm_pose']][3]
            else:
                checks['feet'] &= parts['parts'][f['parts'][0]]['anchors']['feet_count']==2
            if f['variant']!='tay_khong':
                checks['grip'] &= f['weapon_grip_error_px']<=.71
                x,y=map(round,f['hand']);checks['grip'] &= np.asarray(im.getchannel('A'))[y-3:y+4,x-3:x+4].min()>180
            if f['variant']=='tay_khong':
                comps=significant_components(im)
                if len(comps)>1:component_warnings.append({'frame':index,'component_sizes':comps})
        checks={k:bool(v) for k,v in checks.items()}
        rows.append({'frame':index,**checks})
        for k,v in checks.items():
            if not v:failures.append(f'Frame {index:02}: {k}')
    pngs=list((ROOT/'frames').glob('*/*/*/*.png'))
    if len(pngs)!=360:failures.append(f'Frame count {len(pngs)} != 360')
    for name,minimum in [('anim_chay.gif',5),('anim_nhay.gif',8)]:
        with Image.open(ROOT/name) as im:
            if im.n_frames!=minimum:failures.append(f'{name}: unexpected frame count {im.n_frames}')
    for size in [256,128]:
        with Image.open(ROOT/f'0_mau/dung_{size}.png') as im:
            if im.height!=size:failures.append(f'Standing export height != {size}')
    result={'rows':rows,'failures':failures,'component_observations':component_warnings,'skin_semantic_pixels_checked':skin_count,'manual_visual_review':'See REPORT.md; automated relationships do not replace image review.'}
    (ROOT/'tools/validation.json').write_text(json.dumps(result,indent=2))
    print(f'VALIDATE: {len(parts["parts"])} part records, 70 transparent part PNGs, {len(pngs)} frame PNGs.')
    print(f'Skin palette: {skin_count} semantic pixels checked at both scales; exact 3-color membership required.')
    print('Per-frame checks: neck anchor + opaque neck pixels, fixed tunic height, 2 declared foot anchors + rendered pixels, distinct hand positions, actual grip alpha, clipping, exact mirrored pixels.')
    print('Roll cells: curled original full-body vector at 4 rotations, inherited 2-foot geometry; joints are built into the artwork.')
    print(f'Connected-component observations (unarmed, components >20 pixels): {json.dumps(component_warnings)}')
    print('Frame checklist:')
    print('frame neck size skin feet arms grip bounds mirror')
    for r in rows:print(f'{r["frame"]:02} '+ ' '.join('YES' if r[k] else 'NO' for k in ['neck','size','skin','feet','arms','grip','bounds','mirror']))
    print(f'FAILURES: {len(failures)}')
    for f in failures:print(f)
    if failures:raise SystemExit(1)

if __name__=='__main__':main()
