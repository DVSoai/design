#!/usr/bin/env python3
"""Check provenance, real raster pixels, attachment points and visibility rules."""
from pathlib import Path
import json,hashlib,math
import numpy as np
from PIL import Image,ImageOps
from normalize import ROOT,PALETTE
VISIBLE={0,1,2,3,4,5,6,7,12,21}

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def opaque_near(im,p,radius=2):
    x,y=map(round,p);a=np.asarray(im.getchannel('A'));region=a[max(0,y-radius):y+radius+1,max(0,x-radius):x+radius+1]
    return region.size>0 and region.max()>200

def main():
    calls=json.loads((ROOT/'tools/image_calls.json').read_text());partfile=json.loads((ROOT/'parts/parts.json').read_text());parts=partfile['parts'];a=json.loads((ROOT/'frames/assembly.json').read_text())
    expected=set(map(str,[1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,35]));failures=[];provenance=[]
    if set(parts)!=expected:failures.append('Wrong character part membership')
    skin_ok={}
    for key,p in parts.items():
        raw=ROOT/f'parts/raw/{int(key):02}.png';count=calls[key]['image_tool_calls'];provenance.append({'part':int(key),'image_tool_calls':count,'raw_sha256':digest(raw)})
        if count<1:failures.append(f'Part {key}: ZERO image tool calls, NOT ACCEPTABLE')
        if calls[key].get('current_revision_calls'):
            log=json.loads((ROOT/f'tools/logs/revision2_part_{int(key):02}.json').read_text());source=Path(calls[key]['current_revision_output'])
            if count!=calls[key]['previous_image_tool_calls']+log['revision_calls'] or log['attempts'][-1]['references']!=2:failures.append(f'Part {key}: revision call accounting mismatch')
            if source.exists() and digest(raw)!=digest(source):failures.append(f'Part {key}: revised raw is not direct image output')
        elif key in ['32','5','23']:
            master=calls[key]['master'];source=ROOT/f'0_mau/master_{master}.png'
            if digest(raw)!=digest(source):failures.append(f'Approved master {key} was changed before normalization')
        else:
            log=json.loads((ROOT/f'tools/logs/part_{int(key):02}_calls.json').read_text())
            if log['image_tool_calls']!=count or log['attempts'][-1]['reference_count']!=4:failures.append(f'Part {key}: call/reference accounting mismatch')
            source=Path(log['attempts'][-1]['output_path'])
            # The generated original may not be available after downloading the
            # package. A persisted hash provides offline integrity verification.
            if source.exists() and digest(raw)!=digest(source):failures.append(f'Part {key}: raw is not the direct image-tool output')
        mask=Image.open(ROOT/f'parts/masks/{int(key):02}.png').convert('L');skin_ok[key]=True
        for size in [256,128]:
            im=Image.open(ROOT/f'parts/{size}/{int(key):02}.png');arr=np.asarray(im)
            if im.mode!='RGBA' or im.size!=(size,size) or arr[:,:,3].min()!=0:failures.append(f'Part {key}/{size}: format/alpha failure')
            m=np.asarray(mask.resize((size,size),Image.Resampling.NEAREST))>127;m &= arr[:,:,3]>0
            colors={tuple(v) for v in arr[:,:,:3][m]}
            if not colors.issubset(set(map(tuple,PALETTE.tolist()))):failures.append(f'Part {key}/{size}: skin palette failure');skin_ok[key]=False
    svgs=[p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*.svg')]
    if sorted(svgs)!=['parts/weapons/cung.svg','parts/weapons/kiem.svg']:failures.append('A non-weapon SVG exists')
    if len({digest(ROOT/f'parts/256/{i:02}.png') for i in range(6,11)})!=5:failures.append('Running arm silhouettes are not distinct')
    rows=[]
    for i in range(30):
        checks={'neck':True,'size':True,'skin':True,'feet':True,'arms':True,'grip':True,'visibility':True,'bounds':True,'mirror':True,'image_tool':True}
        bare=Image.open(ROOT/f'frames/256/tay_khong/phai/{i:02}.png').convert('RGBA')
        for f in [v for v in a['frames'] if v['frame']==i]:
            v=f['variant'];im=Image.open(ROOT/f'frames/256/{v}/phai/{i:02}.png').convert('RGBA');left=Image.open(ROOT/f'frames/256/{v}/trai/{i:02}.png').convert('RGBA')
            checks['bounds'] &= not f['clipped'];checks['mirror'] &= ImageOps.mirror(im).tobytes()==left.tobytes()
            checks['image_tool'] &= all(calls[k]['image_tool_calls']>0 for k in f['parts']);checks['skin'] &= all(skin_ok[k] for k in f['parts'])
            should=v!='tay_khong' and i in VISIBLE;checks['visibility'] &= f['weapon_visible']==should
            if v!='tay_khong':
                different=np.count_nonzero(np.any(np.asarray(im)!=np.asarray(bare),axis=2))
                checks['visibility'] &= (different>100 if should else different==0)
            if len(f['parts'])==3:
                hk,tk,lk=f['parts'];o=f['origins'];chin=[o['head'][j]+parts[hk]['anchors']['chin'][j] for j in range(2)];neck=[o['torso'][j]+parts[tk]['anchors']['neck'][j] for j in range(2)]
                checks['neck'] &= abs(chin[0]-neck[0])<.01 and abs(chin[1]-neck[1]-2)<.01 and opaque_near(im,neck)
                checks['size'] &= parts[tk]['anchors']['tunic_height']==82
                feet=f['feet'];checks['feet'] &= len(feet)==2 and math.dist(*feet)>8 and all(opaque_near(im,p) for p in feet)
                checks['arms'] &= math.dist(parts[tk]['anchors']['hand'],parts[tk]['anchors']['back_hand'])>8
                if should:
                    meta=json.loads((ROOT/f'parts/grips/{f["grip_layer"]}.json').read_text());body=Image.open(ROOT/f'parts/grips/256/{f["grip_layer"]}.png').convert('RGBA');checks['grip'] &= opaque_near(body,meta['target_grip'],radius=4) and meta['fingers_wrap'] and f['weapon_grip_error']<=1.5
            else:
                checks['feet'] &= f['feet_count']==2;checks['neck'] &= f['independent_roll'] and not f['character_rotation_applied']
        checks={k:bool(v) for k,v in checks.items()};rows.append({'frame':i,**checks})
        for k,v in checks.items():
            if not v:failures.append(f'Frame {i:02}: {k}')
    frames=list((ROOT/'frames').glob('*/*/*/*.png'))
    if len(frames)!=360:failures.append(f'Wrong frame count: {len(frames)}')
    roll_hashes={digest(ROOT/f'parts/raw/{i:02}.png') for i in [1,2,3,4]}
    if len(roll_hashes)!=4:failures.append('Roll raw files not distinct')
    for name,count in [('anim_chay.gif',5),('anim_nhay.gif',8)]:
        with Image.open(ROOT/name) as im:
            if im.n_frames!=count:failures.append(f'GIF count failure: {name}')
    metrics=json.loads((ROOT/'tools/arm_metrics.json').read_text());by_part={str(r['part']):r for r in metrics['rows']};unmeasured=[]
    for m in metrics['rows']:
        if m['midpoint_occluded']:unmeasured.append(m['part'])
        elif not m['within_12_percent']:failures.append(f'Torso {m["part"]}: biceps thickness outside ±12%')
    for row in rows:
        frame=next(f for f in a['frames'] if f['frame']==row['frame'] and f['variant']=='tay_khong')
        m=by_part.get(frame['parts'][1]) if len(frame['parts'])==3 else None
        row['arm_measurement']=m
    for p in (ROOT/'tools/logs').glob('grip_*_calls.json'):
        j=json.loads(p.read_text());raw=ROOT/f'parts/grips/raw/{j["key"]}.png';source=Path(j['output_path'])
        if source.exists() and digest(raw)!=digest(source):failures.append(f'Grip {j["key"]}: raw output mismatch')
        if j['image_tool_calls']<1:failures.append(f'Grip {j["key"]}: zero image calls')
    preservation=json.loads((ROOT/'tools/preservation_result.json').read_text())
    if preservation['unauthorized_changes']:failures.append('Protected baseline assets changed')
    audit=json.loads((ROOT/'tools/weapon_audit.json').read_text())
    if audit['failures']:failures.extend(audit['failures'])
    core_calls=sum(c.get('current_revision_calls',0) for c in calls.values());grip_calls=sum(json.loads(p.read_text())['image_tool_calls'] for p in (ROOT/'tools/logs').glob('grip_*_calls.json'))
    result={'failures':failures,'rows':rows,'provenance':provenance,'character_svg_count':0 if len(svgs)==2 else len(svgs)-2,'current_revision_core_image_calls':core_calls,'current_revision_grip_image_calls':grip_calls,'arm_midpoints_not_measurable':unmeasured,'reference_rule':'Current torso edits: torso 5 or 8 plus same-number pose; grip edits: original style sample plus own placement guide.'}
    (ROOT/'tools/validation.json').write_text(json.dumps(result,indent=2))
    print(f'VALIDATE: {len(parts)} image-generated character parts; ZERO parts with 0 image-tool calls.')
    print(f'Current revision image-tool invocations: torso={core_calls}, additional grip layers={grip_calls}.')
    print('Character SVG count: 0. Weapon SVG count: 2. Four roll source images have different SHA256 hashes.')
    print(f'Frame PNG count: {len(frames)}; both directions and scales present. GIF frame counts: 5 / 8.')
    print('Weapon visibility: only 00–07, 12, 21; forbidden frames compared byte-for-byte to unarmed pixels.')
    print('frame neck size skin feet arms grip visibility bounds mirror image_tool | biceps_mean_px skin_area_px2 arm_size_result')
    keys=['neck','size','skin','feet','arms','grip','visibility','bounds','mirror','image_tool']
    for row in rows:
        m=row['arm_measurement'];measure='ROLL_PRESERVED' if m is None else f'{m["mean_upper_arm_px"]} {m["skin_area_px2"]} '+('NOT_MEASURABLE_OCCLUDED' if m['midpoint_occluded'] else 'PASS' if m['within_12_percent'] else 'FAIL')
        print(f'{row["frame"]:02} '+' '.join('YES' if row[k] else 'NO' for k in keys)+' | '+measure)
    print(f'ARM MIDPOINT NOT MEASURABLE: {unmeasured} (covered by forearm/wrist wrap; preserved original, not a passing thickness result).')
    print('FAILURES: '+str(len(failures)))
    for f in failures:print(f)
    if failures:raise SystemExit(1)

if __name__=='__main__':main()
