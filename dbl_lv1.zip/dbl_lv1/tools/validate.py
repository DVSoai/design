#!/usr/bin/env python3
"""Check exact rig geometry separately from the new illustration's visual poses."""
from pathlib import Path
import json,hashlib,math
import numpy as np
from PIL import Image,ImageOps
from normalize import ROOT,PALETTE

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 geo=json.loads((ROOT/'tools/geometry.json').read_text());parts=json.loads((ROOT/'parts/parts.json').read_text())['parts'];calls=json.loads((ROOT/'tools/image_calls.json').read_text());data=json.loads((ROOT/'tools/pose_data.json').read_text());assembly=json.loads((ROOT/'frames/assembly.json').read_text());fail=[];partrows=[]
 expected=[1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,35]
 if set(parts)!=set(map(str,expected)):fail.append('Character part membership')
 for k in expected:
  g=geo[str(k)];raw=ROOT/f'parts/raw/{k:02}.png';call=calls.get(str(k),{});native=Image.open(ROOT/f'parts/native/{k:02}.png');bbox=native.getbbox();same=bool(list(native.size)==g['canvas'] and (list(bbox) if bbox else None)==g['bbox']);count=call.get('image_tool_calls',0)
  if not same:fail.append(f'Part {k}: native geometry mismatch {native.size} {bbox}')
  if k!=22:
   if count<1:fail.append(f'Part {k}: missing new image tool invocation')
   if not raw.exists() or sha(raw)!=call.get('raw_sha256'):fail.append(f'Part {k}: raw generation hash mismatch')
   source=Path(call.get('output_path','/missing'))
   if source.is_file() and sha(source)!=sha(raw):fail.append(f'Part {k}: raw is not direct generated source')
  elif bbox is not None:fail.append('Empty control 22 is not transparent')
  for size in [256,128]:
   im=Image.open(ROOT/f'parts/{size}/{k:02}.png');expected_size=tuple(round(v*size/131) for v in g['canvas'])
   if im.mode!='RGBA' or im.size!=expected_size:fail.append(f'Part {k}/{size}: dimensions or format')
  mask=np.asarray(Image.open(ROOT/f'parts/masks/{k:02}.png'))>127;a=np.asarray(Image.open(ROOT/f'parts/256/{k:02}.png'));mask &= a[:,:,3]>0;colors={tuple(x) for x in a[:,:,:3][mask]}
  if not colors.issubset(set(map(tuple,PALETTE.tolist()))):fail.append(f'Part {k}: skin palette')
  partrows.append({'part':k,'canvas':g['canvas'],'occupied_bbox':g['bbox'],'native_geometry_exact':same,'new_image_calls':count,'empty_control':k==22})
 for r in assembly['frames']:
  n=r['frame'];v=r['variant'];size=r['output_size'];scale=size/131;canvas=640 if size==256 else 320;origin=[canvas/2,canvas*.75]
  for key,m in r['origins'].items():
   c=m['frame_cell'];off=m['part_offset'];expectedpos=[origin[0]+(c[1]+off[0])*4*scale,origin[1]+(-c[2]+off[1])*4*scale]
   if max(abs(m['position'][j]-expectedpos[j]) for j in range(2))>1e-7 or m['correction']!=[0,0]:fail.append(f'Frame {n}/{v}/{size}: altered rig offset')
  if r['clipped']:fail.append(f'Frame {n}/{v}/{size}: clipped')
  right=Image.open(ROOT/f'frames/{size}/{v}/phai/{n:02}.png').convert('RGBA');left=Image.open(ROOT/f'frames/{size}/{v}/trai/{n:02}.png').convert('RGBA')
  if ImageOps.mirror(right).tobytes()!=left.tobytes():fail.append(f'Frame {n}/{v}/{size}: mirror')
  visible=v!='tay_khong' and n in assembly['weapon_frames']
  if visible!=r['weapon_visible']:fail.append(f'Frame {n}: weapon visibility')
  if not visible and v!='tay_khong':
   bare=Image.open(ROOT/f'frames/{size}/tay_khong/phai/{n:02}.png').convert('RGBA')
   if bare.tobytes()!=right.tobytes():fail.append(f'Frame {n}: forbidden weapon pixels')
  if 8<=n<=11 and (len(r['parts'])!=1 or r['parts'][0]!=str(n-7) or r['character_rotation_applied']):fail.append(f'Roll {n}: incorrect independently generated image')
 frames=list((ROOT/'frames').glob('*/*/*/*.png'))
 if len(frames)!=360:fail.append(f'Frame PNG count {len(frames)}')
 svgs=sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*.svg'))
 if svgs!=['parts/weapons/cung.svg','parts/weapons/kiem.svg']:fail.append('Non-weapon SVG')
 if len({sha(ROOT/f'parts/raw/{k:02}.png') for k in [1,2,3,4]})!=4:fail.append('Four roll sources not independent')
 for name in ['proportion_audit.json','weapon_audit.json']:
  evidence=json.loads((ROOT/'tools'/name).read_text())
  if evidence['failures']:fail.extend([name+': '+str(e) for e in evidence['failures']])
 result={'failures':fail,'parts':partrows,'frame_pngs':len(frames),'new_character_parts':32,'empty_control_slots':1,'total_new_image_calls':sum(v['image_tool_calls'] for v in calls.values()),'extra_hands':0,'rig_position_corrections':0,'validation_limit':'Exact canvas sizes, occupied rectangles, numeric rig positions, layers, mirrors and provenance are machine checked. Pose anatomy, foot count and joint appearance are reviewed visually; matching a rectangle does not prove pixel-identical silhouette.'}
 (ROOT/'tools/validation.json').write_text(json.dumps(result,indent=2))
 print('VALIDATE: 32 newly image-generated character parts + one truly empty control slot 22.')
 print('All 33 native canvases and occupied rectangles match numeric source geometry exactly.')
 print(f'Generation invocations recorded: {result["total_new_image_calls"]}; character vector/SVG count=0; weapon SVG count=2.')
 print('360 transparent frame PNGs; literal rig positions; zero per-part assembly correction; zero extra hand layers; left mirrors verified.')
 print('Weapon-free frame variants match unarmed pixels; independent roll sources verified; no clipped output.')
 print('VISUAL LIMIT: exact bounding rectangles are not proof of identical anatomical silhouettes. See visual review table and comparison log.')
 print('FAILURES: '+str(len(fail)))
 for e in fail:print(e)
 if fail:raise SystemExit(1)
if __name__=='__main__':main()
