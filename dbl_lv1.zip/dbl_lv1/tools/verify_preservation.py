#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]

def main():
    base=json.loads((ROOT/'tools/preservation_baseline.json').read_text());changed=[];checked=0
    for relative,digest in base['character_pngs'].items():
        if int(Path(relative).stem) in base['authorized_replacements']:continue
        checked+=1
        if hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()!=digest:changed.append(relative)
    for relative,digest in base['roll_frames'].items():
        checked+=1
        if hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()!=digest:changed.append(relative)
    print(f'PRESERVATION: {checked} protected PNG files compared to baseline; unauthorized pixel/file changes={len(changed)}.')
    print('Only torso parts 5,14,15,17,18,19 are authorized replacements. All heads, legs, rolls, other torsos and all roll frame exports remain byte-identical.')
    (ROOT/'tools/preservation_result.json').write_text(json.dumps({'checked':checked,'unauthorized_changes':changed},indent=2))
    if changed:raise SystemExit('\n'.join(changed))

if __name__=='__main__':main()
