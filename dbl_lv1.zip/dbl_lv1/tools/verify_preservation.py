#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]

def main():
    base=json.loads((ROOT/'tools/preservation_baseline_revision3.json').read_text());changed=[];checked=0
    for relative,digest in base.items():
        checked+=1
        if hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()!=digest:changed.append(relative)
    print(f'PRESERVATION: {checked} protected PNG files compared to baseline; unauthorized pixel/file changes={len(changed)}.')
    print('Baseline 760fdd9: ALL 33 character parts (raw, masks, 256/128), ALL unarmed exports and ALL roll exports remain byte-identical.')
    (ROOT/'tools/preservation_result.json').write_text(json.dumps({'checked':checked,'unauthorized_changes':changed},indent=2))
    if changed:raise SystemExit('\n'.join(changed))

if __name__=='__main__':main()
