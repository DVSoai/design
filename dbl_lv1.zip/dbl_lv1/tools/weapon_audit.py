#!/usr/bin/env python3
"""Audit rendered weapon geometry, raster registration and head occlusion."""
import json,math
import numpy as np
from PIL import Image,ImageOps
from normalize import ROOT
from make_weapons import angle,axial_length

def wrapped(v):return (v+180)%360-180
def difference(a,b):return abs(wrapped(a-b))
def main():
 # Verify equal limb lengths and central grip directly from the exported SVG.
 import xml.etree.ElementTree as ET,re
 svg=ET.parse(ROOT/'parts/weapons/cung.svg').getroot()
 paths=[p.attrib.get('d','') for p in svg.iter() if p.tag.endswith('path')]
 curve=max(paths,key=len);nums=list(map(float,re.findall(r'-?\d+(?:\.\d+)?',curve)));points=np.array(nums).reshape(-1,2);mid=len(points)//2
 upper=float(np.linalg.norm(np.diff(points[:mid+1],axis=0),axis=1).sum());lower=float(np.linalg.norm(np.diff(points[mid:],axis=0),axis=1).sum())
 bow_meta=json.loads((ROOT/'parts/weapons/weapons.json').read_text())['cung'];central_error=float(np.linalg.norm(points[mid]-bow_meta['grip']))
 if abs(upper-lower)>.02 or central_error>.01:raise SystemExit('Bow symmetry/central grip check failed')
 print(f'BOW SVG AUDIT: limbs={upper:.4f}/{lower:.4f}px; difference={abs(upper-lower):.5f}px; grip-midpoint error={central_error:.5f}px; string=3.2px.')
 records=json.loads((ROOT/'frames/assembly.json').read_text())['frames'];assets=json.loads((ROOT/'parts/weapons/weapons.json').read_text());poses=json.loads((ROOT/'tools/pose_data.json').read_text());rows=[];failures=[]
 for f in records:
  if not f['weapon_visible']:continue
  k=f['variant'];sprite=Image.open(ROOT/f'parts/256/{k}.png').convert('RGBA');layer=Image.new('RGBA',(640,640));pos=f['weapon_position'];xy=tuple(round(t) for t in pos);layer.alpha_composite(sprite,xy)
  tp=f['origins']['torso'];tpr=np.rint(tp);finger=Image.open(ROOT/f'parts/grips/fingers/{f["grip_layer"]}.png');fingers=Image.new('RGBA',(640,640));fingers.alpha_composite(finger,tuple(tpr.astype(int)))
  cell=poses['frames'][f['frame']][3];part=poses['metrics']['12' if k=='kiem' else '14'][cell[0]];literal=[320+(cell[1]+part[1])*4*256/131,444+(-cell[2]+part[2])*4*256/131];expected=literal[:]
  if k=='kiem' and f['frame'] in [12,21]:expected=[tp[j]+[151,133][j]-assets[k]['grip'][j] for j in range(2)]
  frame=np.asarray(Image.open(ROOT/f'frames/256/{k}/phai/{f["frame"]:02}.png').convert('RGBA'));arr=np.asarray(layer);support=(arr[:,:,3]==255)&(np.asarray(fingers.getchannel('A'))==0)
  head=Image.new('RGBA',(640,640));head.alpha_composite(Image.open(ROOT/f'parts/256/{int(f["parts"][0]):02}.png').convert('RGBA'),tuple(round(t) for t in f['origins']['head']));ha=np.asarray(head);face_match=None
  if k=='cung':
   support &= ha[:,:,3]==0;hm=ha[:,:,3]==255;face_match=float(np.mean(np.all(frame[:,:,:3][hm]==ha[:,:,:3][hm],axis=1)))
  match=float(np.mean(np.all(frame[:,:,:3][support]==arr[:,:,:3][support],axis=1)))
  meta=json.loads((ROOT/f'parts/grips/{f["grip_layer"]}.json').read_text());hand=tpr+meta['target_grip'];hilt=np.array(xy)+assets[k]['grip'];raster_error=float(np.linalg.norm(hand-hilt));position_error=float(np.linalg.norm(np.array(pos)-expected));chest_shift=(np.array(pos)-literal).tolist()
  for dr in ['phai','trai']:
   reference=assets[k]['reference_angle_deg'] if dr=='phai' else wrapped(180-assets[k]['reference_angle_deg'])
   for size in [256,128]:
    divisor=256/size;im=Image.open(ROOT/f'parts/{size}/{k}.png').convert('RGBA');show=im if dr=='phai' else ImageOps.mirror(im);a=angle(show,k)
    if k=='kiem' and dr=='trai':a=wrapped(a+180)
    y,x=np.where(np.asarray(im)[:,:,3]>127);bbox=[int(x.max()-x.min()+1),int(y.max()-y.min()+1)];target=[v/divisor for v in assets[k]['target_bbox']];length=axial_length(im,assets[k]['reference_angle_deg']) if k=='kiem' else None;ratio=length/(256/divisor) if length else None
    ok=difference(a,reference)<=10 and f['fingers_wrap'] and f['weapon_runtime_rotation']==0 and position_error<1e-7 and match>.999 and raster_error<=1.5 and meta['collar_preserved_exact']
    if k=='cung':ok &= max(abs(bbox[j]-target[j]) for j in range(2))<=1.5 and face_match==1. and assets[k]['limb_ratio']==1 and assets[k]['string_width_px']>=2
    else:ok &= abs(length-200/divisor)<=2/divisor
    row={'frame':f['frame'],'weapon':k,'direction':dr,'scale':size,'angle_deg':round(a,4),'reference_angle_deg':round(reference,4),'angle_error_deg':round(difference(a,reference),4),'bbox':bbox,'target_bbox':target,'sword_axial_length_px':length,'sword_length_height_ratio':ratio,'fingers_wrap':f['fingers_wrap'],'grip_registration_error':f['weapon_grip_error']/divisor,'raster_hand_hilt_error_px':raster_error/divisor,'position':pos,'literal_table_position':literal,'chest_adjustment_px':chest_shift,'position_error_px':position_error,'opaque_asset_pixel_match':match,'head_pixel_match':face_match,'collar_preserved_exact':meta['collar_preserved_exact'],'pass':bool(ok)}
    rows.append(row)
    if not ok:failures.append(f'{k} {f["frame"]:02} {dr} {size}')
 for i in [0,1]:
  f=next(f for f in records if f['variant']=='cung' and f['frame']==i);feet=Image.open(ROOT/f'frames/256/tay_khong/phai/{i:02}.png').getbbox()[3];bottom=round(f['weapon_position'][1])+assets['cung']['bbox'][3];print(f'STANDING {i:02}: bow_bottom={bottom}; feet_bottom={feet}; PASS={bottom<=feet}')
  if bottom>feet:failures.append(f'Bow below standing feet {i}')
 result={'rows':rows,'failures':failures,'measurement':'Angles/bboxes measured from complete raster weapon assets before finger/head occlusion; visible opaque weapon pixels matched to final render. Head pixels checked independently. Hand/hilt error includes independently rounded layer origins. Sword total length is projection of all opaque pixels along reference blade axis, including pommel.','angle_convention':'x right, y down; sword hilt toward tip; bow lower tip toward upper tip; clockwise degrees from +x.'}
 (ROOT/'tools/weapon_audit.json').write_text(json.dumps(result,indent=2))
 print(f'WEAPON AUDIT: {len(rows)} checks; complete asset geometry + final rendered pixels.')
 for r in rows:
  if r['direction']=='phai' and r['scale']==256:print(f'{r["weapon"]} {r["frame"]:02}: angle={r["angle_deg"]:.3f}; reference={r["reference_angle_deg"]:.3f}; bbox={r["bbox"]}; axial_length={r["sword_axial_length_px"]}; ratio={r["sword_length_height_ratio"]}; hand-hilt={r["raster_hand_hilt_error_px"]:.3f}px; wrap={r["fingers_wrap"]}; collar={r["collar_preserved_exact"]}; head_match={r["head_pixel_match"]}; shift={r["chest_adjustment_px"]}; PASS={r["pass"]}')
 print('WEAPON AUDIT FAILURES: '+str(len(failures)))
 if failures:raise SystemExit('\n'.join(failures))
if __name__=='__main__':main()
