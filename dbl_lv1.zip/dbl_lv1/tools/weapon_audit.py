#!/usr/bin/env python3
"""Measure fixed weapon geometry and verify front-layer composition."""
import json,math
import numpy as np
from PIL import Image,ImageOps
from normalize import ROOT

def axis(im,kind):
 a=np.asarray(im);rgb=a[:,:,:3].astype(float);m=a[:,:,3]>127
 if kind=='kiem':
  m &= (rgb.max(2)-rgb.min(2)<45)&(rgb.mean(2)>100);y,x=np.where(m);_,v=np.linalg.eigh(np.cov(np.column_stack([x,y]).T));u=v[:,-1];u=u if u[0]<0 else -u
  return float(np.degrees(np.arctan2(u[1],u[0])))
 y,x=np.where(m);top=y.min();bot=y.max();return float(np.degrees(np.arctan2(top-bot,x[y<=top+2].mean()-x[y>=bot-2].mean())))
def wrap(a):return (a+180)%360-180

def main():
 asm=json.loads((ROOT/'frames/assembly.json').read_text());data=json.loads((ROOT/'tools/pose_data.json').read_text());geo=json.loads((ROOT/'tools/geometry.json').read_text());rows=[];fail=[];refs={'kiem':152.18166232073006,'cung':-63.18183483147667}
 for f in asm['frames']:
  if not f['weapon_visible']:continue
  k=f['variant'];size=f['output_size'];scale=size/131;canvas=640 if size==256 else 320;cell=data['frames'][f['frame']][3];metric=data['metrics']['12' if k=='kiem' else '14'][cell[0]];expected=[canvas/2+(cell[1]+metric[1])*4*scale,canvas*.75+(-cell[2]+metric[2])*4*scale];pos=f['origins'][k]['position'];error=math.dist(pos,expected)
  asset=Image.open(ROOT/f'parts/{size}/{k}.png').convert('RGBA');source_id='262' if k=='kiem' else '283';target=[round(v*scale) for v in geo[source_id]['bbox']];bbox=list(asset.getbbox());shape_ok=bbox==target
  right=Image.open(ROOT/f'frames/{size}/{k}/phai/{f["frame"]:02}.png').convert('RGBA');bare=Image.open(ROOT/f'frames/{size}/tay_khong/phai/{f["frame"]:02}.png').convert('RGBA');headkey=str(data['metrics']['2'][data['frames'][f['frame']][0][0]][0]);head=Image.open(ROOT/f'parts/{size}/{int(headkey):02}.png').convert('RGBA');mask=Image.new('L',(canvas,canvas));mask.paste(head.getchannel('A'),tuple(f['origins'][headkey]['raster_position']));ma=np.asarray(mask);a=np.asarray(right);b=np.asarray(bare);opaque_head=ma==255;face_ok=bool(np.all(a[opaque_head]==b[opaque_head]))
  layer=Image.new('RGBA',(canvas,canvas));layer.alpha_composite(asset,tuple(f['origins'][k]['raster_position']));p=np.asarray(layer);support=(p[:,:,3]==255)&(ma==0);pixel_match=float(np.mean(np.all(a[:,:,:3][support]==p[:,:,:3][support],axis=1)))
  for direction in ['phai','trai']:
   im=asset if direction=='phai' else ImageOps.mirror(asset);theta=axis(im,k)
   if k=='kiem' and direction=='trai':theta=wrap(theta+180)
   ref=refs[k] if direction=='phai' else wrap(180-refs[k]);delta=abs(wrap(theta-ref));ok=shape_ok and error<1e-7 and face_ok and pixel_match>.999 and delta<=10
   row={'frame':f['frame'],'weapon':k,'direction':direction,'size':size,'bbox':bbox,'bbox_size':[bbox[2]-bbox[0],bbox[3]-bbox[1]],'angle_deg':theta,'reference_angle_deg':ref,'angle_error_deg':delta,'position_error_px':error,'opaque_weapon_pixel_match':pixel_match,'face_preserved':face_ok,'hand_hilt_error_px':None,'hand_metric_status':'N/A: unchanged image slot, no added grip or hand registration','pass':ok};rows.append(row)
   if not ok:fail.append(f'{k}/{f["frame"]}/{size}/{direction}')
 result={'rows':rows,'failures':fail,'extra_grip_layers':0,'position_corrections':0,'measurement':'Weapon angle from complete raster before occlusion; actual visible opaque weapon pixels checked in final frame. Face pixels retained from unarmed frame. Hand-hilt coincidence is not asserted.'};(ROOT/'tools/weapon_audit.json').write_text(json.dumps(result,indent=2))
 print(f'WEAPON AUDIT: {len(rows)} frame/variant/direction/scale checks; fixed original numeric positions and rectangles.')
 for r in rows:
  if r['size']==256 and r['direction']=='phai':print(f'{r["weapon"]} {r["frame"]:02}: angle={r["angle_deg"]:.3f}; ref={r["reference_angle_deg"]:.3f}; delta={r["angle_error_deg"]:.3f}; bbox={r["bbox_size"]}; position_error={r["position_error_px"]:.6f}; face={r["face_preserved"]}; visible_pixel_match={r["opaque_weapon_pixel_match"]:.6f}; pass={r["pass"]}')
 print('Hand-hilt error: N/A; no extra grip layers and no invented zero-distance claim.')
 print('WEAPON AUDIT FAILURES: '+str(len(fail)))
 if fail:raise SystemExit('\n'.join(fail))
if __name__=='__main__':main()
