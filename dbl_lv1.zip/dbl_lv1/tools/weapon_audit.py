#!/usr/bin/env python3
"""Measure rendered weapon pixels against stored numeric reference measurements."""
import json,math
import numpy as np
from PIL import Image,ImageOps
from normalize import ROOT
from make_weapons import angle

def wrapped(v):return (v+180)%360-180
def difference(a,b):return abs(wrapped(a-b))

def main():
    records=json.loads((ROOT/'frames/assembly.json').read_text())['frames'];assets=json.loads((ROOT/'parts/weapons/weapons.json').read_text());pose_data=json.loads((ROOT/'tools/pose_data.json').read_text());rows=[];failures=[]
    for f in records:
        if not f['weapon_visible']:continue
        k=f['variant'];sprite=Image.open(ROOT/f'parts/256/{k}.png').convert('RGBA');layer=Image.new('RGBA',(640,640));xy=tuple(round(t) for t in f['weapon_position']);layer.alpha_composite(sprite,xy)
        fingers=Image.new('RGBA',(640,640));finger=Image.open(ROOT/f'parts/grips/fingers/{f["grip_layer"]}.png');fingers.alpha_composite(finger,tuple(round(t) for t in f['origins']['torso']))
        cell=pose_data['frames'][f['frame']][3];part=pose_data['metrics']['12' if k=='kiem' else '14'][cell[0]];literal_expected=[320+(cell[1]+part[1])*4*(256/131),444+(-cell[2]+part[2])*4*(256/131)]
        actual_frame=np.asarray(Image.open(ROOT/f'frames/256/{k}/phai/{f["frame"]:02}.png').convert('RGBA'));asset_pixels=np.asarray(layer);visible_support=(asset_pixels[:,:,3]==255)&(np.asarray(fingers.getchannel('A'))==0);pixel_match=float(np.mean(np.all(actual_frame[:,:,:3][visible_support]==asset_pixels[:,:,:3][visible_support],axis=1)))
        arr=np.array(layer);arr[np.asarray(fingers.getchannel('A'))>127,3]=0;visible=Image.fromarray(arr)
        for direction in ['phai','trai']:
            measured=angle(visible if direction=='phai' else ImageOps.mirror(visible),k)
            if k=='kiem' and direction=='trai':measured=wrapped(measured+180)
            reference=assets[k]['reference_angle_deg'] if direction=='phai' else wrapped(180-assets[k]['reference_angle_deg']);delta=difference(measured,reference)
            for size in [256,128]:
                divisor=256/size;small_asset=np.asarray(Image.open(ROOT/f'parts/{size}/{k}.png').convert('RGBA'));sy,sx=np.where(small_asset[:,:,3]>127);bbox=[int(sx.max()-sx.min()+1),int(sy.max()-sy.min()+1)];target=[round(v/divisor,3) for v in assets[k]['target_bbox']]
                rendered=visible if size==256 else visible.resize((320,320),Image.Resampling.LANCZOS)
                scale_angle=angle(rendered if direction=='phai' else ImageOps.mirror(rendered),k)
                if k=='kiem' and direction=='trai':scale_angle=wrapped(scale_angle+180)
                scale_delta=difference(scale_angle,reference)
                row={'frame':f['frame'],'weapon':k,'direction':direction,'scale':size,'angle_deg':round(scale_angle,4),'reference_angle_deg':round(reference,4),'angle_error_deg':round(scale_delta,4),'fingers_wrap':f['fingers_wrap'],'bbox':bbox,'target_bbox':target,'position':f['weapon_position'],'literal_expected_position':literal_expected,'opaque_asset_pixel_match':pixel_match,'runtime_rotation_deg':f['weapon_runtime_rotation'],'grip_registration_error':f['weapon_grip_error']}
                row['pass']=scale_delta<=10 and f['fingers_wrap'] and f['weapon_runtime_rotation']==0 and f['weapon_position']==literal_expected and pixel_match>.999 and max(abs(bbox[j]-target[j]) for j in range(2))<=1.5 and f['weapon_grip_error']<=1.5
                if not row['pass']:failures.append(f'{k} frame {f["frame"]:02} {direction} {size}')
                rows.append(row)
    for i in [0,1]:
        f=next(f for f in records if f['variant']=='cung' and f['frame']==i);bare=Image.open(ROOT/f'frames/256/tay_khong/phai/{i:02}.png');feet_bottom=bare.getbbox()[3];bow_bottom=round(f['weapon_position'][1])+assets['cung']['bbox'][3]
        if bow_bottom>feet_bottom:failures.append(f'Bow below feet in standing frame {i:02}')
        print(f'STANDING {i:02}: bow_bottom={bow_bottom}; feet_bottom={feet_bottom}; '+('PASS' if bow_bottom<=feet_bottom else 'FAIL'))
    result={'rows':rows,'failures':failures,'angle_convention':'Image x right / y down; sword axis from hilt toward tip; bow axis from lower tip toward upper tip; degrees clockwise from +x.','measurement':'PCA of visible metallic blade pixels after finger occlusion; bow endpoints from visible alpha. Reference images are not included.'}
    (ROOT/'tools/weapon_audit.json').write_text(json.dumps(result,indent=2));print('WEAPON AUDIT: 10 frames × 2 weapons × 2 directions × 2 scales = '+str(len(rows))+' checks.')
    for r in rows:
        if r['direction']=='phai' and r['scale']==256:print(f'{r["weapon"]} {r["frame"]:02}: angle={r["angle_deg"]:.3f}; ref={r["reference_angle_deg"]:.3f}; delta={r["angle_error_deg"]:.3f}; wrap={r["fingers_wrap"]}; bbox={r["bbox"]}; target={r["target_bbox"]}; '+('PASS' if r['pass'] else 'FAIL'))
    print('WEAPON AUDIT FAILURES: '+str(len(failures)))
    if failures:raise SystemExit('\n'.join(failures))

if __name__=='__main__':main()
