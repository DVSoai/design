#!/usr/bin/env python3
"""Current measurements, generation accounting, visual review and verbatim logs."""
import json
from normalize import ROOT

def main():
 calls=json.loads((ROOT/'tools/image_calls.json').read_text());parts=json.loads((ROOT/'parts/parts.json').read_text())['parts'];p=json.loads((ROOT/'tools/proportion_audit.json').read_text());v=json.loads((ROOT/'tools/validation.json').read_text());w=json.loads((ROOT/'tools/weapon_audit.json').read_text());text=[]
 def para(s):text.append(s+'\n')
 para('# Đinh Bộ Lĩnh Lv1 — vẽ mới toàn bộ, dùng cấu trúc khung gốc')
 para('Theo yêu cầu mới, toàn bộ mảnh có hình nhân vật đã được tạo mới bằng công cụ ảnh; không giữ lại đầu/thân/chân/lộn từ bản trước. Giữ kích thước canvas, khung bao, số ảnh, bảng tư thế và độ lệch mảnh của cấu trúc gốc. Chỉ thay diện mạo, tóc, mặt và trang phục. Không dựng hình người bằng SVG/vector/code; hai vũ khí dùng SVG tự vẽ.')
 para(f'Có **32 mảnh nhân vật mới**, qua **{sum(x["image_tool_calls"] for x in calls.values())} lần gọi công cụ tạo ảnh**: 3 đầu, 16 thân, 9 chân và 4 dáng lộn. Mảnh 22 là ô điều khiển trong suốt 4×4, không có nhân vật để vẽ; ghi N/A thay vì tạo thêm chân làm sai cấu trúc. `tools/freshness.json` xác nhận 32 ảnh raw đều khác bản trước, không tái sử dụng ảnh nhân vật cũ.')
 para('## Đã xem và đo những gì')
 para('Đã mở trực tiếp ảnh mảnh gốc, phóng lớn để xem dáng, và ghép các mảnh tham khảo bằng bảng số để so với hình mới ở cùng tỷ lệ. Sau đó đối chiếu thêm tờ mảnh/tờ ghép người dùng gửi. **Chưa chạy client để chụp màn hình thực tế.** Các tờ đối chiếu có hình bên ngoài chỉ nằm trong thư mục tạm, không đưa vào gói hoặc repo kết quả.')
 para('Kích thước khung đứng, đo phần có alpha: đầu **83×76**, thân gồm tay **82×43**, chân **58×31**, toàn người **87×131 px**. Đầu chiếm **58.02%** chiều cao, cao **1.767 lần khung bao thân gồm tay**. Chồng đầu–thân **8px**, thân–chân **11px**: `76+43+31−8−11=131`. Không dùng lại tỷ lệ tự đặt 1.3 hoặc ép mọi áo về một chiều cao chung.')
 para('`parts/native/` giữ đúng cỡ gốc của từng ảnh, dùng được như ảnh thay thế theo số; có cả tên vũ khí 262/283. Hai bản 256/128 dùng chung hệ số 256/131 và 128/131. Khung đứng xuất cao đúng 256/128px; các tư thế khác giữ biến thiên chiều cao của bảng gốc, không kéo tất cả về 256px.')
 para('## Ghép và vũ khí')
 para('Ghép trực tiếp `x=cx+(dx+pdx)×4×S`, `y=cy+(−dy+pdy)×4×S`. **Không dịch khớp**, không thêm tay cầm, không xoay vũ khí và không bù riêng khung 12/21. Lật toàn khung để có hướng trái. Bốn mảnh lộn là bốn ảnh được tạo riêng, không xoay ảnh đứng.')
 para('Vũ khí nằm **trước thân** theo tờ ghép người dùng cung cấp. Để giữ mặt không bị che, phần vũ khí qua vùng đầu lấy lại pixel nhân vật tay không dưới mặt nạ đầu; không thay tọa độ vũ khí hay vẽ thêm người. Ở các khung được phép, kiếm/cung giữ nguyên slot và khung bao gốc. Ngoài 00–07,12,21, hai biến thể có vũ khí giống tay không từng pixel.')
 para('Kiếm native: canvas **104×64**, bao **102×60px**; cung native: canvas **108×136**, bao **87×132px**. Tỷ lệ rộng bao kiếm/chiều cao người là `102/131=0.7786`; đây không phải chiều dài chéo theo trục. Không tráo hai phép đo này. Không ép tay vào chuôi để tạo một cấu trúc cầm khác mẫu; sai lệch tay–chuôi ghi **N/A**, không ghi khoảng cách giả bằng 0.')
 para('## Phạm vi kiểm chứng')
 para('Script xác minh chính xác **canvas, khung bao từng mảnh, khung bao toàn bộ 30 tư thế ở cỡ native, tọa độ số, ảnh lật, nguồn tạo ảnh và quy tắc vũ khí**. Khung bao giống nhau không chứng minh đường viền cơ thể trùng từng pixel: đây là ảnh vẽ mới, không phải đổi màu trực tiếp ảnh gốc. Dáng tay/chân và khớp được so bằng ảnh ghép; chưa xác nhận trong client thực tế.')
 para('Đã xem toàn bộ 30 khung tay không, bốn mảnh lộn, và tờ phóng vũ khí 00,03,07,12,21 × kiếm/cung. Không thấy hở cổ/hông hoặc mất giày trong các ảnh đã soát. Tỷ lệ áo/tay của mỗi tư thế theo mảnh riêng; không dùng lại thao tác ép mọi tư thế về thân 8 của bản trước.')
 para('## Số lần tạo ảnh từng mảnh')
 text+=['| Mảnh | Canvas native | Bao phần có hình native | Lần gọi công cụ ảnh |\n','|---|---|---|---:|\n']
 for k in sorted(parts,key=int):
  m=parts[k];c=calls[k];box='N/A — trống' if m['occupied_bbox_native'] is None else str(m['occupied_bbox_native']);count=str(c['image_tool_calls']) if k!='22' else 'N/A — ô trống'
  text.append(f'| {int(k):02} | {m["canvas_native"]} | {box} | {count} |\n')
 para('Thân 5: ba lần tạo, hai lần đầu bàn tay quá nhỏ; chọn lần ba. Thân 9: hai lần, bỏ bản lộ thêm tay sau. Thân 16: hai lần, bỏ bản tự dựng thêm thân đầy đủ, chọn mảnh tay/áo bị che như mẫu. Các mảnh còn lại một lần. Prompt nguyên văn từng lần thử có trong `prompts/` và log mỗi mảnh; raw là file trực tiếp từ công cụ, có SHA256.')
 para('## Đối chiếu 30 khung')
 text+=['| Khung | Bao toàn người native (px) | Lệch mép [trái,trên,phải,dưới] | Cổ/hông đã so | Hai giày đã so | Vũ khí đúng slot |\n','|---|---|---|---|---|---|\n']
 for r in p['rows']:
  n=r['frame'];note='Lộn riêng' if 8<=n<=11 else 'Có';text.append(f'| {n:02} | {r["native_size"]} | {r["native_bbox_edge_delta"]} | {note} | Có | Có |\n')
 para('Bốn giá trị lệch mép lần lượt là trái, trên, phải, dưới; toàn bộ bằng 0px. Số này là kiểm tra hình học, không được diễn giải là đường nét ảnh mới giống hệt ảnh cũ.')
 para('## Vũ khí từng khung')
 text+=['| Khung | Loại | Góc 256 (°) | Góc hướng dẫn (°) | Lệch góc (°) | Bao 256 (px) | Lệch vị trí số (px) | Mặt giữ nguyên |\n','|---|---|---:|---:|---:|---|---:|---|\n']
 for r in w['rows']:
  if r['direction']=='phai' and r['size']==256:text.append(f'| {r["frame"]:02} | {r["weapon"]} | {r["angle_deg"]:.3f} | {r["reference_angle_deg"]:.3f} | {r["angle_error_deg"]:.3f} | {r["bbox_size"]} | {r["position_error_px"]:.6f} | '+('Có' if r['face_preserved'] else 'Không')+' |\n')
 para(f'`tools/weapon_audit.json` có đủ {len(w["rows"])} phép kiểm cho cả hai hướng và hai cỡ. Kiểm tra pixel vũ khí đục còn nhìn thấy so với đúng asset ở vị trí đó; không chỉ dựa vào tọa độ ghi trong báo cáo. Tổng lỗi máy kiểm: {len(v["failures"])}.')
 para('## Preview và gói tải')
 para('`preview/ty_le_goc.png`: hình mới kèm tỷ lệ đã đo. `preview/parts_33.png`: đủ 33 slot, gồm ô trống 22. `preview/tay_dong_bo.png`: đủ 16 thân tại cùng hệ số phóng. `preview/vu_khi_zoom.png`: 10 ô vũ khí phóng 2×. Có ba tờ 30 khung, tờ tổng hợp hai hướng và GIF chạy/nhảy. Tất cả preview trong gói chỉ chứa hình tự thiết kế.')
 para('## Output nguyên văn các script')
 for name in ['weapons','manifest','normalize','assemble','previews','proportions','weapon_audit','validate','package']:
  path=ROOT/f'tools/logs/{name}.txt'
  if path.exists():para('### '+path.name);text.append('```text\n'+path.read_text().rstrip()+'\n```\n\n')
 (ROOT/'REPORT.md').write_text(''.join(text));print('REPORT: actual generation calls, geometry versus visual limits, 30 frame rows, weapon audit and verbatim logs saved.')
if __name__=='__main__':main()
