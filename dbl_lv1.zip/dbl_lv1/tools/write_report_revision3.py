#!/usr/bin/env python3
"""Write current evidence and verbatim processing logs into the review report."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
def main():
 w=json.loads((ROOT/'parts/weapons/weapons.json').read_text());audit=json.loads((ROOT/'tools/weapon_audit.json').read_text());v=json.loads((ROOT/'tools/validation.json').read_text());arms=json.loads((ROOT/'tools/arm_metrics.json').read_text());pres=json.loads((ROOT/'tools/preservation_result.json').read_text());calls=json.loads((ROOT/'tools/image_calls.json').read_text())
 out=['# Đinh Bộ Lĩnh Lv1 — cung đối xứng, kiếm 200px và mép cổ áo',
 'Mốc đầu vào: `760fdd9b849acaa3999bdf2f3df0f254f2830ba3`. Không dùng Git để lấy nguồn hay đổi phiên bản trong quá trình sửa; Git chỉ dùng để đẩy kết quả. Chỉ đọc hai thư mục nguồn đã được chỉ định để tham khảo hình và bảng số. Gói không chứa ảnh, mã hoặc tên sản phẩm tham khảo.',
 f'**Bảo toàn: {pres["checked"]} PNG đối chiếu SHA256, {len(pres["unauthorized_changes"])} thay đổi.** Toàn bộ 33 mảnh nhân vật (raw, mặt nạ, hai cỡ: 132 file), 120 khung tay không và 32 khung lộn của các biến thể còn lại giữ nguyên từng byte. Màu, nét, tỷ lệ và bốn kiểu lộn không vẽ lại. Các PNG lộn của tay không đã nằm trong nhóm 120, không đếm trùng.',
 '## Vũ khí và cách ghép',
 f'- Kiếm: chiều dài toàn bộ theo trục, gồm đốc, **{w["kiem"]["axial_length_px"]:.3f}px**, chia chiều cao chuẩn 256px = **{w["kiem"]["length_height_ratio"]:.5f}**. Bao alpha >127: **{w["kiem"]["bbox_size"][0]}×{w["kiem"]["bbox_size"][1]}px**. Nén theo trục quanh chuôi, giữ độ rộng vuông góc lưỡi; lưỡi vẫn to bản. Không nhầm chiều rộng bao với chiều dài chéo của kiếm.',
 f'- Cung: bao **{w["cung"]["bbox_size"][0]}×{w["cung"]["bbox_size"][1]}px**, chuẩn quy đổi 170.015×257.954px. Hai cánh cong đều có chiều dài bằng nhau **{w["cung"]["upper_limb_length_px"]:.3f}px/cánh**, tay cầm tại đúng giữa cung; hai đầu uốn ngược nhẹ. Dây màu kem đậm, dày **3.2px** ở cỡ 256. Script kiểm tra lại độc lập độ dài hai cánh và điểm giữa từ đường nét SVG xuất.',
 '- Tọa độ cơ sở: `x=cx+(dx+pdx)*4*256/131`, `y=cy+(-dy+pdy)*4*256/131`, gốc khung `(320,444)`. Khung 12 dùng ô vũ khí `[1,-9,49]`; khung 21 dùng `[1,-10,46]`. Độ lệch hai loại vũ khí lần lượt `[-4,27]` và `[-10,9]`. Không xoay vũ khí khi ghép.',
 '- Ngoại lệ theo yêu cầu mới: kiếm 12/21 và nắm tay được đưa lên ngực, tại `[151,133]` trong tọa độ thân (phải cổ 23px, dưới cổ 29px). Khung 12 dịch **(-62.325,-66.307)px**, khung 21 dịch **(-62.325,-74.123)px** so với vị trí bảng số. Không ghi nhầm hai khung này là giữ nguyên tọa độ gốc. Tay còn lại giơ lên được giữ từ thân gốc.',
 '- Thứ tự: chân/thân → vũ khí → ngón tay. Với cung, lớp đầu gốc được đặt trên cung; toàn bộ pixel đầu đục đối chiếu chính xác với ảnh gốc ở mọi khung có cung, nên cánh cung/dây không phủ lên mặt. Cung đứng 00/01 có đáy y=427/419, chân y=452/444.',
 '- Vũ khí chỉ hiện 00–07,12,21. Có đủ 30 khung × 3 biến thể × 2 hướng × 2 cỡ = **360 PNG**; các khung không được mang vũ khí đối chiếu pixel với tay không.',
 '## Mép cổ áo và lớp tay cầm',
 'Không sửa mảnh thân gốc. Tách lại alpha các lớp tay cầm đã tạo bằng công cụ ảnh: loại dấu màu, chuôi tạm và mẩu áo lọt vào lớp tay; lấy vùng da nắm tay liên thông cùng viền mực thay cho mặt nạ tròn chứa cả cổ áo. Vùng cổ áo được phục hồi trực tiếp từ raster gốc, tránh ghép các đốm tròn nhỏ tạo răng cưa. Script xác nhận các pixel vùng cổ được bảo vệ khớp chính xác. Đã xem tờ phóng to các khung 00,03,07,12,21 cho cả kiếm và cung.',
 'Kiếm 12/21 tái sử dụng ảnh tay cầm đã tạo `kiem_02`, đăng ký ở ngực; các lớp còn lại dùng ảnh tay cầm đã có cùng khóa. Không tạo hình người bằng SVG, vector hoặc hình khối. Các biến đổi/mặt nạ chỉ xử lý raster ảnh đã tạo, không vẽ RGB cơ thể mới.',
 '## Số đo từng khung có vũ khí',
 'Góc tính từ +x, y hướng xuống: kiếm từ chuôi về mũi; cung từ đầu dưới lên đầu trên. Góc/bao được đo trên **asset đầy đủ trước che khuất**, rồi kiểm tra riêng pixel vũ khí còn nhìn thấy trong ảnh ghép và pixel đầu. Không đo sai trục vì đầu che mất một phần cung. Bao dùng alpha >127. Sai lệch tay–chuôi tính cả làm tròn độc lập gốc hai lớp; cỡ 128 ghi theo hệ tọa độ thu nhỏ. Tỷ lệ kiếm dùng chiều cao chuẩn 256/128px, không dùng chiều cao bao cả vũ khí hay dáng đang nhảy.',
 f'Có **{len(audit["rows"])} phép kiểm**, {len(audit["failures"])} lỗi. Bảng dưới ghi cả hai cỡ cho từng hướng. Đầy đủ tọa độ, độ dịch và tỷ lệ khớp pixel nằm ở `tools/weapon_audit.json`.',
 '| Khung | Loại | Hướng | Góc 256 / 128 (°) | Góc hướng dẫn (°) | Bao 256 / 128 (px) | Dài kiếm / cao người 256 / 128 | Lệch tay–chuôi 256 / 128 (px) | Tay bọc chuôi |',
 '|---|---|---|---:|---:|---|---:|---:|---|']
 for k in ['kiem','cung']:
  for frame in [0,1,2,3,4,5,6,7,12,21]:
   for dr in ['phai','trai']:
    pair=[next(r for r in audit['rows'] if r['frame']==frame and r['weapon']==k and r['direction']==dr and r['scale']==scale) for scale in [256,128]];a,b=pair
    box=lambda r:'×'.join(map(str,r['bbox']));ratio='—' if k=='cung' else f'{a["sword_length_height_ratio"]:.4f} / {b["sword_length_height_ratio"]:.4f}'
    out.append(f'| {frame:02} | {k} | {dr} | {a["angle_deg"]:.3f} / {b["angle_deg"]:.3f} | {a["reference_angle_deg"]:.3f} | {box(a)} / {box(b)} | {ratio} | {a["raster_hand_hilt_error_px"]:.3f} / {b["raster_hand_hilt_error_px"]:.3f} | '+('Có' if a['fingers_wrap'] and b['fingers_wrap'] else 'Không')+' |')
 out+=['## Tờ kiểm 16 thân',
 '`preview/tay_dong_bo.png`: đủ thân **5–12,14–21**, dùng cùng vùng cắt và tỷ lệ 1.6×, không phóng từng thân theo kích thước riêng. Không cắt mất tay cao của thân 12/20. Số dưới ảnh là số đo ở cỡ nguồn 256px; diện tích da ghi theo dáng. `preview/vu_khi_zoom.png`: 00,03,07,12,21 × kiếm/cung, cùng vùng cắt, phóng đúng 2×.',
 'Các số đo tay được giữ nguyên từ bản đầu vào. Ngưỡng ±12% áp cho độ dày trung bình hai bắp tay đo được theo lựa chọn đã chốt; diện tích da không dùng để loại dáng. **Thân 16 có giữa bắp tay bị che: N/A, không coi là phép đo đạt.** Đây là giới hạn đã có, không vẽ lại mảnh được yêu cầu giữ nguyên.',
 '| Thân | Hai bên (px) | Trung bình (px) | Lệch thân 8 (%) | Diện tích da (px²) | Kết quả |','|---|---:|---:|---:|---:|---|']
 for r in arms['rows']:
  sides=' / '.join(f'{n:.2f}' for n in r['upper_arm_widths_px']);mean='N/A' if r['mean_upper_arm_px'] is None else f'{r["mean_upper_arm_px"]:.2f}';delta='N/A' if r['midpoint_occluded'] else f'{r["width_delta_percent"]:+.2f}';result='N/A — che khuất' if r['midpoint_occluded'] else 'Đạt' if r['within_12_percent'] else 'Không đạt'
  out.append(f'| {r["part"]} | {sides} | {mean} | {delta} | {r["skin_area_px2"]} | {result} |')
 out+=['## Tự soát 30 khung',
 'Có/Không theo kiểm tra pixel/neo và phép đo đã mô tả; cột tay ghi số đo, riêng khung lộn giữ nguyên và thân 16 ghi N/A. Bảng này không thay thế tờ phóng to để duyệt hình.',
 '| Khung | Đầu–cổ | Cỡ áo | Da | Hai chân | Dáng tay | Tay cầm | Hiện vũ khí | Tay cùng cỡ: TB px / diện tích px² |',
 '|---|---|---|---|---|---|---|---|---|']
 for r in v['rows']:
  vals=['Có' if r[k] else 'Không' for k in ['neck','size','skin','feet','arms','grip','visibility']];m=r['arm_measurement'];measure='Lộn giữ nguyên' if m is None else ('N/A (che khuất)' if m['midpoint_occluded'] else f'{m["mean_upper_arm_px"]:.2f}')+f' / {m["skin_area_px2"]}'
  out.append(f'| {r["frame"]:02} | '+' | '.join(vals)+f' | {measure} |')
 out+=['## Nguồn tạo ảnh và số lần gọi',
 '**Lần sửa hiện tại: 0 lần gọi tạo ảnh mới**, vì yêu cầu giữ nguyên mọi mảnh nhân vật và tay đã đồng bộ. Mọi mảnh đều có nguồn ảnh và lịch sử gọi công cụ từ các bản trước; không có mảnh nhân vật dựng bằng mã. Có 18 nguồn tay cầm đã tạo trước đó, không tạo lại; việc tái sử dụng donor được ghi trong JSON mỗi lớp. Các prompt nguyên văn và log tạo ảnh trước đây vẫn giữ trong `prompts/` và `tools/logs/`.',
 '| Mảnh | Tổng lần tạo ảnh đã ghi nhận | Lần sửa hiện tại |','|---|---:|---:|']
 for k in sorted(calls,key=int):out.append(f'| {int(k):02} | {calls[k]["image_tool_calls"]} | 0 — giữ nguyên |')
 out+=['## Output nguyên văn các script trong lần sửa này',
 'Các log cũ giữ làm lịch sử; các log có tiền tố `revision3_` dưới đây là kết quả hiện tại.']
 for name in ['weapons','grips','assemble','previews','preservation','audit','validate']:
  p=ROOT/f'tools/logs/revision3_{name}.txt';out+=['### '+p.name,'```text',p.read_text().rstrip(),'```']
 package=ROOT/'tools/logs/revision3_package.txt'
 if package.exists():out+=['### '+package.name,'```text',package.read_text().rstrip(),'```']
 report='\n\n'.join(out)+'\n'
 report=re.sub(r'(?m)(^\|[^\n]*\|)\n\n(?=\|)',r'\1\n',report)
 report=report.replace('```text\n\n','```text\n').replace('\n\n```','\n```')
 (ROOT/'REPORT.md').write_text(report)
 print('REPORT: current geometry, 40 paired-scale weapon rows, 16 torso measurements, 30 frame checks, inherited image-call provenance and verbatim revision3 logs.')
if __name__=='__main__':main()
